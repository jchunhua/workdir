#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x9e03639, "module_layout" },
	{ 0x7762b634, "platform_bus_type" },
	{ 0x7485e15e, "unregister_chrdev_region" },
	{ 0x8da03dec, "cdev_del" },
	{ 0x6bc3fbc0, "__unregister_chrdev" },
	{ 0xf205380c, "driver_unregister" },
	{ 0x268d37db, "platform_device_unregister" },
	{ 0xfed8b69, "device_create" },
	{ 0x76b141b6, "__class_create" },
	{ 0x72e0ef2, "platform_device_register" },
	{ 0xe5f32ca1, "driver_register" },
	{ 0x9a83cbe2, "cdev_add" },
	{ 0xf4396568, "cdev_init" },
	{ 0x29537c9e, "alloc_chrdev_region" },
	{ 0x867f7d04, "kmalloc_caches" },
	{ 0xa31e44ba, "edma_free_channel" },
	{ 0x3635439, "edma_stop" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0x83d70683, "edma_start" },
	{ 0x61e1850a, "edma_write_slot" },
	{ 0x85737519, "edma_read_slot" },
	{ 0xf1e0b260, "edma_set_transfer_params" },
	{ 0xcaddbd7e, "edma_set_dest_index" },
	{ 0xf7271948, "edma_set_src_index" },
	{ 0x9276ce28, "edma_set_dest" },
	{ 0x9bda4bb4, "edma_set_src" },
	{ 0xfefb6077, "edma_alloc_channel" },
	{ 0x37a0cba, "kfree" },
	{ 0xfa2a45e, "__memzero" },
	{ 0xfbc74f64, "__copy_from_user" },
	{ 0xe8929aa8, "kmem_cache_alloc" },
	{ 0xea147363, "printk" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";

