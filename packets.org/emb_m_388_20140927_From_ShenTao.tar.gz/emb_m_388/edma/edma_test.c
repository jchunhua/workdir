/*
 * Copyright (C) 2008 Texas Instruments Inc
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option)any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

/*
 * file   edma_test.c
 * brief  EDMA3 Test Application
 *
 *   This file contains EDMA3 Test code.
 *
 *   NOTE: THIS FILE IS PROVIDED ONLY FOR INITIAL DEMO RELEASE AND MAY BE
 *         REMOVED AFTER THE DEMO OR THE CONTENTS OF THIS FILE ARE SUBJECT
 *         TO CHANGE.
 *
 *   @author	Anuj Aggarwal
 *   @version	0.1 -
 *		Created on 30/09/05
 *		Assumption: Channel and ParamEntry has 1 to 1 mapping
 *		0.2 - Sudhakar Rajashekhara
 *		06/04/2009 - Modified to use new EDMA APIs
 */

#include <linux/module.h>
#include <linux/init.h>
#include <linux/errno.h>
#include <linux/types.h>
#include <linux/interrupt.h>
#include <asm/io.h>
#include <linux/moduleparam.h>
#include <linux/sysctl.h>
#include <linux/mm.h>
#include <linux/dma-mapping.h>

#include <mach/memory.h>
#include <mach/hardware.h>
#include <mach/irqs.h>
#include <asm/hardware/edma.h>

#include <linux/slab.h>         /*     kmalloc() */
#include <linux/fs.h>           /*     everything... */
#include <linux/errno.h>        /*     error codes     */
#include <linux/types.h>        /*     size_t */
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/delay.h>
#include <linux/platform_device.h>
#include <asm/uaccess.h>
#include "edma_test.h"

//#undef EDMA3_DEBUG
#define EDMA3_DEBUG
/*#define EDMA3_DEBUG*/

#ifdef EDMA3_DEBUG
#define DMA_PRINTK(ARGS...)  printk(KERN_INFO "<%s>: ",__FUNCTION__);printk(ARGS)
#define DMA_FN_IN printk(KERN_INFO "[%s]: start\n", __FUNCTION__)
#define DMA_FN_OUT printk(KERN_INFO "[%s]: end\n",__FUNCTION__)
#else
#define DMA_PRINTK( x... )
#define DMA_FN_IN
#define DMA_FN_OUT
#endif

#define STATIC_SHIFT                3
#define TCINTEN_SHIFT               20
#define ITCINTEN_SHIFT              21
#define TCCHEN_SHIFT                22
#define ITCCHEN_SHIFT               23

#define DRIVER_NAME     "edma_test"

//static DEFINE_SPINLOCK(edma_lock);

//static volatile int irqraised1 = 0;

static struct class *edma_test_class;
static struct cdev c_dev;
static dev_t dev;
static struct device *edma_test_device;

static void callback1(unsigned lch, u16 ch_status, void *data)
{
	switch(ch_status) {
	case DMA_COMPLETE:
		((struct edma_buf*)data)->irqraised = 1;
		//printk("#####%d\n", ((struct edma_buf*)data)->irqraised);
		//irqraised1 = 1;		
		/*DMA_PRINTK ("\n From Callback 1: Channel %d status is: %u\n",
				lch, ch_status);*/
		break;
	case DMA_CC_ERROR:
                ((struct edma_buf*)data)->irqraised = -1;
		//irqraised1 = -1;
		DMA_PRINTK ("\nFrom Callback 1: DMA_CC_ERROR occured "
				"on Channel %d\n", lch);
		break;
	default:
		break;
	}
}

static int edma_test_open(struct inode *inode, struct file *filp)
{
        return 0;
}

static ssize_t edma_test_write(struct file *file, const char __user *buffer,
                              size_t count, loff_t *ppos)
{
        struct edma_buf *buf = NULL;
        int result = 0;
        unsigned int dma_ch = 0;
        unsigned int BRCnt = 0;
        unsigned int srcbidx = 0;
        unsigned int desbidx = 0;
        unsigned int srccidx = 0;
        unsigned int descidx = 0;
        struct edmacc_param param_set;
	enum sync_dimension sync_mode;

        //spin_lock(&edma_lock);

        buf = kmalloc(sizeof(struct edma_buf), GFP_KERNEL);
        if (!buf) {
		printk("edma_test_write: failed for buf\n");
                return -ENOMEM;
	}

        if (copy_from_user(buf, (struct edma_buf *)buffer, sizeof(struct edma_buf))) {
                kfree(buf);
                printk("edma_test_write: failed for copy_from_user\n");
                return -EFAULT;
        }

        //DMA_PRINTK ("edma_test_write: acnt=%d bcnt=%d ccnt=%d\n", buf->acnt, buf->bcnt, buf->ccnt);
        //DMA_PRINTK ("edma_test_write: dmaphyssrc=%x dmaphysdest=%x\n", buf->dmaphyssrc, buf->dmaphysdest);

        /* Set B count reload as B count. */
        //BRCnt = buf->bcnt;
        BRCnt = buf->BRCnt;

        /* Setting up the SRC/DES Index */
        //srcbidx = buf->acnt;
        //desbidx = buf->acnt;
        srcbidx = buf->srcbidx;
        desbidx = buf->desbidx;

        /* A Sync Transfer Mode */
        //srccidx = buf->acnt;
        //descidx = buf->acnt;
        srccidx = buf->srccidx;
        descidx = buf->descidx;
 
	sync_mode = buf->sync_mode;

        result = edma_alloc_channel (EDMA_CHANNEL_ANY, callback1, buf, EVENTQ_1);

        if (result < 0) {
                DMA_PRINTK ("\nedma3_memtomemcpytest_dma::edma_alloc_channel failed for dma_ch, error:%d\n", result);
                return result;
        }

        dma_ch = result;
        edma_set_src (dma_ch, (unsigned long)(buf->dmaphyssrc), INCR, W8BIT);
        edma_set_dest (dma_ch, (unsigned long)(buf->dmaphysdest), INCR, W8BIT);
        edma_set_src_index (dma_ch, srcbidx, srccidx);
        edma_set_dest_index (dma_ch, desbidx, descidx);
        /* A Sync Transfer Mode */
        edma_set_transfer_params (dma_ch, buf->acnt, buf->bcnt, buf->ccnt, BRCnt, sync_mode);

        /* Enable the Interrupts on Channel 1 */
        edma_read_slot (dma_ch, &param_set);
        //param_set.opt |= (1 << ITCINTEN_SHIFT);
        param_set.opt |= (1 << TCINTEN_SHIFT);
        param_set.opt |= EDMA_TCC(EDMA_CHAN_SLOT(dma_ch));
        edma_write_slot (dma_ch, &param_set);

	result = edma_start(dma_ch);
        if (result != 0) {
        	DMA_PRINTK ("edma3_memtomemcpytest_dma: davinci_start_dma failed \n");
    	}

        buf->irqraised = 0;
	//irqraised1 = 0;

        //spin_unlock(&edma_lock);

     	/* Wait for the Completion ISR. */
    	while (buf->irqraised == 0u)
	{
		udelay(100);
	}

     	/* Check the status of the completed transfer */
   	if (buf->irqraised < 0) {
     		/* Some error occured, break from the FOR loop. */
        	DMA_PRINTK ("edma3_memtomemcpytest_dma: Event Miss Occured!!!\n");
   	}

   	edma_stop(dma_ch);
    	edma_free_channel(dma_ch);
	kfree(buf);

        return 0;
}

/* XXX: copy from user space to kernel space */
static int edma_test_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
        return 0;
}

static int edma_test_release(struct inode *inode, struct file *filp)
{
        return 0;
}

static struct file_operations edma_test_fops = {
        .owner = THIS_MODULE,
        .open = edma_test_open,
        .write = edma_test_write,
        .release = edma_test_release,
        .unlocked_ioctl = edma_test_ioctl,
};

static void edma_test_platform_release(struct device *device)
{
        /* This is called when the reference count goes to zero */
}
static int __init edma_test_probe(struct device *device)
{
        edma_test_device = device;
        return 0;
}
static int edma_test_remove(struct device *device)
{
        return 0;
}

static struct platform_device edma_test_plat_device = {
        .name = "edma_test",
        .id = -1,
        .dev = {
                .release = edma_test_platform_release
        }
};

static struct device_driver edma_test_driver = {
        .name = "edma_test",
        .bus = &platform_bus_type,
        .probe = edma_test_probe,
        .remove = edma_test_remove,
};

static int __init edma_test_init(void)
{
        int ret;

        ret = alloc_chrdev_region(&dev, 0, 1, DRIVER_NAME);
        if (ret < 0) {
                printk(KERN_ERR"\nedma_test: Module intialization failed.\
                        could not register character device");
                return -ENODEV;
        }

        /* Initialize of character device */
        cdev_init(&c_dev, &edma_test_fops);
        c_dev.owner = THIS_MODULE;
        c_dev.ops = &edma_test_fops;

        /* add character device */
        ret = cdev_add(&c_dev, dev, 1);
        if (ret < 0) {
                printk(KERN_ERR"\nedma_test: Failed to add character device");
                goto _err_add_cdev;
        }

        /* register driver as a platform driver */
        if (driver_register(&edma_test_driver) != 0) {
                ret = -EINVAL;
                goto _err_driver_register;
        }

        /* Register the drive as a platform device */
        if (platform_device_register(&edma_test_plat_device) != 0) {
                ret = -EINVAL;
                goto _err_plat_register;
        }

        edma_test_class = class_create(THIS_MODULE, "edma_test");
        if (!edma_test_class) {
                ret = -EIO;
                goto _err_class_create;
        }

        //class_device_create(edma_test_class, NULL, dev, NULL, "edma_test");
        device_create(edma_test_class, NULL, dev, NULL, "edma_test");

        return 0;

_err_class_create:
        platform_device_unregister(&edma_test_plat_device);
_err_plat_register:
        driver_unregister(&edma_test_driver);
_err_driver_register:
        unregister_chrdev(MAJOR(dev), DRIVER_NAME);
_err_register_dev:
        cdev_del(&c_dev);
_err_add_cdev:
        unregister_chrdev_region(dev, 1);

        return ret;
}

void __exit edma_test_exit(void)
{
}

module_init(edma_test_init);
module_exit(edma_test_exit);

MODULE_AUTHOR("Texas Instruments");
MODULE_LICENSE("GPL");

