cd ../
make omx
cp component-sources/omx_05_02_00_48/bin/audio_encode/bin/ti816x-evm/audio_encode_a8host_debug.xv5T emb_m_388/myapp/
cp component-sources/omx_05_02_00_48/bin/capture_encode_SDI_CVBS/bin/ti816x-evm/capture_encode_SDI_CVBS_a8host_debug.xv5T emb_m_388/myapp/
cp component-sources/omx_05_02_00_48/bin/capture_encode_2SDI/bin/ti816x-evm/capture_encode_2SDI_a8host_debug.xv5T emb_m_388/myapp/
cp component-sources/omx_05_02_00_48/bin/capture_encode_2SDI/bin/ti816x-evm/capture_encode_2SDI_a8host_debug.xv5T emb_m_388/myapp/
