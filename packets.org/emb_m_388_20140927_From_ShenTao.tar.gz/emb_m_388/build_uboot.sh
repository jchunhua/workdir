cd jianwei_u-boot-2010.06-psp04.04.00.01
make ARCH=arm CROSS_COMPILE=arm-none-linux-gnueabi- distclean
make ARCH=arm CROSS_COMPILE=arm-none-linux-gnueabi- ti8168_evm_min_sd
make ARCH=arm CROSS_COMPILE=arm-none-linux-gnueabi- u-boot.ti

cp u-boot.min.sd ../myapp/MLO

make ARCH=arm CROSS_COMPILE=arm-none-linux-gnueabi- distclean
make ARCH=arm CROSS_COMPILE=arm-none-linux-gnueabi- ti8168_evm_config_nand
make ARCH=arm CROSS_COMPILE=arm-none-linux-gnueabi- u-boot.ti

cp u-boot.bin ../myapp/
cp u-boot.noxip.bin ../myapp/
