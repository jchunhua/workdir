/*
 *  Copyright (c) 2010-2011, Texas Instruments Incorporated
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  *  Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *  *  Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *  *  Neither the name of Texas Instruments Incorporated nor the names of
 *     its contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 *  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 *  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 *  OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 *  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  Contact information for paper mail:
 *  Texas Instruments
 *  Post Office Box 655303
 *  Dallas, Texas 75265
 *  Contact information:
 *  http://www-k.ext.ti.com/sc/technical-support/product-information-centers.htm?
 *  DCMP=TIHomeTracking&HQS=Other+OT+home_d_contact
 *  ============================================================================
 *
 */

/**
 *******************************************************************************
 *  @file  capture_encode_test.c
 *  @brief This file contains all Functions related to Test Application
 *
 *         This is the example IL Client support to create, configure & chaining
 *         of single channel omx-components using non tunneling 
 *         mode
 *
 *  @rev 1.0
 *******************************************************************************
 */

/*******************************************************************************
*                             Compilation Control Switches
*******************************************************************************/
/* None */

/*******************************************************************************
*                             INCLUDE FILES
*******************************************************************************/

/*--------------------- system and platform files ----------------------------*/
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <xdc/std.h>

/*-------------------------program files -------------------------------------*/
#include "ti/omx/interfaces/openMaxv11/OMX_Core.h"
#include "ti/omx/interfaces/openMaxv11/OMX_Component.h"
#include "ilclient.h"
#include "ilclient_utils.h"
#include <omx_venc.h>
#include <omx_vfpc.h>
#include <omx_vfdc.h>
#include <omx_vfcc.h>
#include <omx_ctrl.h>
#include <omx_vswmosaic.h>

#include "common.h"

//extern IL_ARGS encode_args;
extern OMX_BOOL gILClientExit;
extern int gILVencClientExit;

typedef void *(*ILC_StartFcnPtr) (void *);

int fd;
extern int g_max_decode;
extern int g_max_display;
extern int g_max_scalar;
extern int g_max_NF;
extern int dei0_input_width;
extern int dei0_input_height;
unsigned int g_timestamp;
extern t_cfg_param g_cfg_param;
extern t_cmem_buf_desc g_encbuf;
/* ========================================================================== */
/**
* IL_ClientCbEventHandler() : This method is the event handler implementation to 
* handle events from the OMX Derived component
*
* @param hComponent        : Handle to the component
* @param ptrAppData        : 
* @param eEvent            :
* @param nData1            :
* @param nData2            :
* @param pEventData        :
*
*  @return      
*  OMX_ErrorNone = Successful 
*
*  Other_value = Failed (Error code is returned)
*
*/
/* ========================================================================== */
OMX_ERRORTYPE IL_ClientCbEventHandler(OMX_HANDLETYPE hComponent,
                                              OMX_PTR ptrAppData,
                                              OMX_EVENTTYPE eEvent,
                                              OMX_U32 nData1, OMX_U32 nData2, 
                                              OMX_PTR pEventData)
{
  IL_CLIENT_COMP_PRIVATE *comp;

  comp = ptrAppData;

  printf ("got event");
  if (eEvent == OMX_EventCmdComplete)
  {
    if (nData1 == OMX_CommandStateSet)
    {
      printf ("State changed to: ");
      switch ((int) nData2)
      {
        case OMX_StateInvalid:
          printf ("OMX_StateInvalid \n");
          break;
        case OMX_StateLoaded:
          printf ("OMX_StateLoaded \n");
          break;
        case OMX_StateIdle:
          printf ("OMX_StateIdle \n");
          break;
        case OMX_StateExecuting:
          printf ("OMX_StateExecuting \n");
          break;
        case OMX_StatePause:
          printf ("OMX_StatePause\n");
          break;
        case OMX_StateWaitForResources:
          printf ("OMX_StateWaitForResources\n");
          break;
      }
      /* post an semaphore, so that in IL Client we can confirm the state
         change */
      semp_post (comp->done_sem);
    }
    else if (OMX_CommandPortEnable || OMX_CommandPortDisable)
    {
      printf ("Enable/Disable Event \n");
      semp_post (comp->port_sem);
    }
  }
  else if (eEvent == OMX_EventBufferFlag)
  {
    printf ("OMX_EventBufferFlag \n");
    if ((int) nData2 == OMX_BUFFERFLAG_EOS)
    {
      printf ("got EOS event \n");
      semp_post (comp->eos);
    }
  }
  else if (eEvent == OMX_EventError)
  {
    printf ("*** unrecoverable error: %s (0x%lx) \n",
            IL_ClientErrorToStr (nData1), nData1);
    printf ("Press a key to proceed\n");
  }
  else
  {
    printf ("unhandled event, param1 = %i, param2 = %i \n", (int) nData1,
            (int) nData2);
  }

  return OMX_ErrorNone;
}

/* ========================================================================== */
/**
* IL_ClientCbEmptyBufferDone() : This method is the callback implementation to 
* handle EBD events from the OMX Derived component
*
* @param hComponent        : Handle to the component
* @param ptrAppData        : app pointer, which was passed during the getHandle
* @param pBuffer           : buffer header, for the buffer which is consumed
*
*  @return      
*  OMX_ErrorNone = Successful 
*
*  Other_value = Failed (Error code is returned)
*
*/
/* ========================================================================== */

OMX_ERRORTYPE IL_ClientCbEmptyBufferDone(OMX_HANDLETYPE hComponent,
                                          OMX_PTR ptrAppData, 
                                          OMX_BUFFERHEADERTYPE *pBuffer)
{

  IL_CLIENT_COMP_PRIVATE *thisComp = (IL_CLIENT_COMP_PRIVATE *) ptrAppData;
  IL_CLIENT_INPORT_PARAMS *inPortParamsPtr;
  IL_CLIENT_PIPE_MSG localPipeMsg;

  OMX_ERRORTYPE eError = OMX_ErrorNone;
  int retVal = 0;

  inPortParamsPtr = thisComp->inPortParams + pBuffer->nInputPortIndex;

  /* if the buffer is from file i/o, write the free buffer header into ipbuf
     pipe, else keep it in its local pipe. From local pipe It would be given
     to remote component as "consumed buffer " */
  if (inPortParamsPtr->connInfo.remotePipe[0] == NULL)
  {
    /* write the empty buffer pointer to input pipe */
    retVal = write (inPortParamsPtr->ipBufPipe[1], &pBuffer, sizeof (pBuffer));

    if (sizeof (pBuffer) != retVal)
    {
      printf ("Error writing to Input buffer i/p Pipe!\n");
      eError = OMX_ErrorNotReady;
      return eError;
    }
  }
  else
  {
    /* Create a message that EBD is done and this buffer is ready to be
       recycled. This message will be read in buffer processing thread and and 
       remote component will be indicated about its status */
    localPipeMsg.cmd = IL_CLIENT_PIPE_CMD_EBD;
    localPipeMsg.pbufHeader = pBuffer;
    retVal = write (thisComp->localPipe[1],
                    &localPipeMsg, sizeof (IL_CLIENT_PIPE_MSG));
    if (sizeof (IL_CLIENT_PIPE_MSG) != retVal)
    {
      printf ("Error writing to local Pipe!\n");
      eError = OMX_ErrorNotReady;
      return eError;
    }

  }

  return eError;
}

/* ========================================================================== */
/**
* IL_ClientCbFillBufferDone() : This method is the callback implementation to 
* handle FBD events from the OMX Derived component
*
* @param hComponent        : Handle to the component
* @param ptrAppData        : app pointer, which was passed during the getHandle
* @param pBuffer           : buffer header, for the buffer which is produced
*
*  @return      
*  OMX_ErrorNone = Successful 
*
*  Other_value = Failed (Error code is returned)
*
*/
/* ========================================================================== */

OMX_ERRORTYPE IL_ClientCbFillBufferDone(OMX_HANDLETYPE hComponent,
                                         OMX_PTR ptrAppData, 
                                         OMX_BUFFERHEADERTYPE *pBuffer)
{

  IL_CLIENT_COMP_PRIVATE *thisComp = (IL_CLIENT_COMP_PRIVATE *) ptrAppData;
  IL_CLIENT_OUTPORT_PARAMS *outPortParamsPtr;
  IL_CLIENT_PIPE_MSG localPipeMsg;

  OMX_ERRORTYPE eError = OMX_ErrorNone;
  int retVal = 0;

  /* get the pipe corrsponding to this port, portIndex is part of bufferheader
     structure */
  outPortParamsPtr =
    thisComp->outPortParams + (pBuffer->nOutputPortIndex -
                               thisComp->startOutportIndex);

  /* if the buffer is from file i/o, write the free buffer header into outbuf
     pipe, else keep it in its local pipe. From local pipe It would be given
     to remote component as "filled buffer " */

  if (outPortParamsPtr->connInfo.remotePipe[0] == NULL)
  {
    /* write the empty buffer pointer to input pipe */
    retVal = write (outPortParamsPtr->opBufPipe[1], &pBuffer, sizeof (pBuffer));

    if (sizeof (pBuffer) != retVal)
    {
      printf ("Error writing to Input buffer i/p Pipe!\n");
      eError = OMX_ErrorNotReady;
      return eError;
    }
  }
  else
  {
    /* Create a message that FBD is done and this buffer is ready to be used
       by other compoenent. This message will be read in buffer processing
       thread and and remote component will be indicated about its status */
    localPipeMsg.cmd = IL_CLIENT_PIPE_CMD_FBD;
    localPipeMsg.pbufHeader = pBuffer;
    retVal = write (thisComp->localPipe[1],
                    &localPipeMsg, sizeof (IL_CLIENT_PIPE_MSG));
    if (sizeof (IL_CLIENT_PIPE_MSG) != retVal)
    {
      printf ("Error writing to local Pipe!\n");
      eError = OMX_ErrorNotReady;
      return eError;
    }

  }
  return eError;
}

void IL_ClientMUXConnInConnOutTask(void *threadsArg)
{
  OMX_ERRORTYPE err = OMX_ErrorNone;
  IL_CLIENT_COMP_PRIVATE *deiILComp0 = NULL;
  IL_CLIENT_COMP_PRIVATE *deiILComp1 = NULL;
  IL_CLIENT_COMP_PRIVATE *disILComp = NULL;
  OMX_BUFFERHEADERTYPE *dei0_pBufferOut = NULL;
  OMX_BUFFERHEADERTYPE *dei1_pBufferOut = NULL;
  OMX_BUFFERHEADERTYPE *pBufferIn = NULL;
  static unsigned int frameCounter = 0;
  unsigned int i = 0, j = 0;
  struct timeval timestart, timeend;
  double linStart=0, linEnd=0;
  struct edma_buf buf;
  int test = 0;

  deiILComp0 = ((IL_Client *) threadsArg)->deiILComp[0];
  deiILComp1 = ((IL_Client *) threadsArg)->deiILComp[1];
  disILComp = ((IL_Client *) threadsArg)->disILComp[0];

  /* use the initial i/p buffers and make empty this buffer calls */
  err = IL_ClientInitialOutputResources (deiILComp0, 0);
  err = IL_ClientInitialOutputResources (deiILComp1, 0);
  err = IL_ClientInitialInputResources (disILComp);
 
  //buf.acnt = ((IL_Client *) threadsArg)->nWidth * 2;
  //buf.bcnt = ((IL_Client *) threadsArg)->nHeight;
  buf.acnt = RESIZER_WIDTH * 2;
  buf.bcnt = RESIZER_HEIGHT;
  buf.ccnt = 1;
  buf.BRCnt = buf.bcnt;
  buf.srcbidx = buf.acnt;
  buf.desbidx = buf.acnt;
  buf.srccidx = buf.acnt;
  buf.descidx = buf.acnt;
  buf.sync_mode = ABSYNC;

  for (i = 0; i < deiILComp0->outPortParams->nBufferCountActual; i++)
  {
    /* Read filled buffer pointer from the pipe */
    read ((deiILComp0->outPortParams)->opBufPipe[0],
          &dei0_pBufferOut, sizeof (dei0_pBufferOut));
    /* Read filled buffer pointer from the pipe */
    read ((deiILComp1->outPortParams)->opBufPipe[0],
          &dei1_pBufferOut, sizeof (dei1_pBufferOut));

    buf.dmaphyssrc =  DomxCore_mapUsrVirtualAddr2phy((uint32_t)dei0_pBufferOut->pBuffer);
    buf.dmaphysdest = DomxCore_mapUsrVirtualAddr2phy((uint32_t)disILComp->inPortParams->pInBuff[i]->pBuffer);
    write(fd, &buf, 1);

    buf.acnt = RESIZER_WIDTH;
    buf.bcnt = RESIZER_HEIGHT;
    buf.ccnt = 1;
    buf.BRCnt = buf.bcnt;
    buf.srcbidx = RESIZER_WIDTH;
    buf.desbidx = ((IL_Client *) threadsArg)->nWidth;
    buf.srccidx = RESIZER_WIDTH;
    buf.descidx = ((IL_Client *) threadsArg)->nWidth;
    buf.sync_mode = ABSYNC;
    write(fd, &buf, 1);

    buf.dmaphyssrc = buf.dmaphyssrc + RESIZER_WIDTH*RESIZER_HEIGHT;
    buf.dmaphysdest = buf.dmaphysdest + ((IL_Client *) threadsArg)->nWidth*((IL_Client *) threadsArg)->nHeight;
    buf.acnt = RESIZER_WIDTH;
    buf.bcnt = RESIZER_HEIGHT;
    buf.ccnt = 1;
    buf.BRCnt = buf.bcnt;
    buf.srcbidx = RESIZER_WIDTH;
    buf.desbidx = ((IL_Client *) threadsArg)->nWidth;
    buf.srccidx = RESIZER_WIDTH;
    buf.descidx = ((IL_Client *) threadsArg)->nWidth;
    buf.sync_mode = ABSYNC;
    write(fd, &buf, 1);

    /* Pass the input buffer to the component */
    err = OMX_FillThisBuffer (deiILComp0->handle, dei0_pBufferOut);
    err = OMX_FillThisBuffer (deiILComp1->handle, dei1_pBufferOut);

    /* Pass the input buffer to the component */
    err = OMX_EmptyThisBuffer (disILComp->handle,
                               disILComp->inPortParams->pInBuff[i]);
  }

  while (1)
  {
    /* Read filled buffer pointer from the pipe */
    read ((deiILComp0->outPortParams)->opBufPipe[0],
          &dei0_pBufferOut, sizeof (dei0_pBufferOut));
    /* Read filled buffer pointer from the pipe */
    read ((deiILComp1->outPortParams)->opBufPipe[0],
          &dei1_pBufferOut, sizeof (dei1_pBufferOut));

    /* Read empty buffer pointer from the pipe */
    read (disILComp->inPortParams->ipBufPipe[0],
          &pBufferIn, sizeof (pBufferIn));

if(test < 150) {
    buf.dmaphyssrc =  DomxCore_mapUsrVirtualAddr2phy((uint32_t)dei0_pBufferOut->pBuffer);
} else {
    buf.dmaphyssrc =  DomxCore_mapUsrVirtualAddr2phy((uint32_t)dei1_pBufferOut->pBuffer);
}
    buf.dmaphysdest = DomxCore_mapUsrVirtualAddr2phy((uint32_t)pBufferIn->pBuffer);
    //gettimeofday(&timestart, NULL);
    //memcpy(pBufferIn->pBuffer, pBufferOut->pBuffer, pBufferOut->nFilledLen);

    buf.acnt = RESIZER_WIDTH;
    buf.bcnt = RESIZER_HEIGHT;
    buf.ccnt = 1;
    buf.BRCnt = buf.bcnt;
    buf.srcbidx = RESIZER_WIDTH;
    buf.desbidx = ((IL_Client *) threadsArg)->nWidth;
    buf.srccidx = RESIZER_WIDTH;
    buf.descidx = ((IL_Client *) threadsArg)->nWidth;
    buf.sync_mode = ABSYNC;
    write(fd, &buf, 1);

    buf.dmaphyssrc = buf.dmaphyssrc + RESIZER_WIDTH*RESIZER_HEIGHT;
    buf.dmaphysdest = buf.dmaphysdest + ((IL_Client *) threadsArg)->nWidth*((IL_Client *) threadsArg)->nHeight;
    buf.acnt = RESIZER_WIDTH;
    buf.bcnt = RESIZER_HEIGHT;
    buf.ccnt = 1;
    buf.BRCnt = buf.bcnt;
    buf.srcbidx = RESIZER_WIDTH;
    buf.desbidx = ((IL_Client *) threadsArg)->nWidth;
    buf.srccidx = RESIZER_WIDTH;
    buf.descidx = ((IL_Client *) threadsArg)->nWidth;
    buf.sync_mode = ABSYNC;
    write(fd, &buf, 1);

    pBufferIn->nFilledLen = (((IL_Client *) threadsArg)->nWidth*((IL_Client *) threadsArg)->nHeight * 2);
    //write(fd, &buf, 1);
    //pBufferIn->nFilledLen = dei0_pBufferOut->nFilledLen;
    //gettimeofday(&timeend, NULL);

    //linStart = ((double)timestart.tv_sec*1000000 + (double)timestart.tv_usec);
    //linEnd = ((double)timeend.tv_sec*1000000 + (double)timeend.tv_usec);
    //printf("time %f\n", (linEnd-linStart));  //tony add

    /* Pass the input buffer to the component */
    err = OMX_FillThisBuffer (deiILComp0->handle, dei0_pBufferOut);
    err = OMX_FillThisBuffer (deiILComp1->handle, dei1_pBufferOut);

    /* Pass the input buffer to the component */
    err = OMX_EmptyThisBuffer (disILComp->handle, pBufferIn);

test++;
if(test==300) {
   test = 0;
}

    if (OMX_ErrorNone != err)
    {
      /* put back the frame in pipe and wait for state change */
      write ((deiILComp0->outPortParams)->opBufPipe[1],
             &dei0_pBufferOut, sizeof (dei0_pBufferOut));
      printf ("IL_ClientMUXConnInConnOutTask: waiting for action from IL Client \n");

      /* since in this example we are changing states in other thread it will
         return error for giving ETB/FTB calls in non-execute state. Since
         example is shutting down, we exit the thread */

      pthread_exit(deiILComp0);
    }
  }
}

/* ========================================================================== */
/**
* IL_ClientOutputBitStreamWriteTask() : This task function is file writetask for
* encoder component. 
*
* @param threadsArg        : Handle to the application
*
*/
/* ========================================================================== */
void PacknSend2df(char *buf, unsigned int len, unsigned int type, unsigned int frame_num, unsigned int timestamp, unsigned int channel, t_datafifo *df)
{
	t_frame_info frm_info;
	int i;
	char *ptr;
	unsigned int residual;
	unsigned int pkt_len;
	int flags;

	frm_info.frame_length = len;
	frm_info.frame_num = frame_num;
	frm_info.frame_type = type;
	frm_info.time_stamp = timestamp;
	frm_info.pkts_in_frame = len/MAX_AVPKT_SIZE;
	residual = len - MAX_AVPKT_SIZE * frm_info.pkts_in_frame;
	if(residual){
		frm_info.pkts_in_frame += 1;
	}

	residual = len;
	ptr = buf;
	for(i=0; i<frm_info.pkts_in_frame; i++){
		frm_info.packet_num = i;
		pkt_len = (MAX_AVPKT_SIZE<residual)?MAX_AVPKT_SIZE:residual;

		//build message
		t_cmd Msg;
		fill_cmd_header(&Msg, COMMAND_GETDATA_ACK);

		if(type==FRMTYPE_AUDIO){
			add_attr_char(&Msg,"Type", "Audio");
		}
		else{
			add_attr_char(&Msg, "Type", "Video");
		}
		if(channel == 0){
			add_attr_char(&Msg, "StreamId", "00");
		}
		else{
			add_attr_char(&Msg, "StreamId", "01");
		}
		add_attr_bin(&Msg, "Info", (char *)&frm_info, sizeof(frm_info));
		add_attr_bin(&Msg, "Data", ptr, pkt_len);

		//send the message to socket
		size_t size;
		char2hex(Msg.data_len, &size, DATA_LEN_SIZE);
		size += PACKET_HEADER_SIZE;
		//send(sock, Msg.fullbuf, size, 0);
		flags = FRAME_FLAG_NEWFRAME | FRAME_FLAG_FRAMEEND;
		datafifo_producer_data_add(df, Msg.fullbuf, size, flags, 0);
		//debug_printf("send %d bytes\n", ret);
		//calculate new data start point and length left
		ptr += pkt_len;
		residual -= pkt_len;
		//sleep(1);
	}
}

void IL_ClientOutputBitStreamWriteTask0(void *threadsArg)
{
	//unsigned int dataRead = 0;
	OMX_ERRORTYPE err = OMX_ErrorNone;
	IL_CLIENT_COMP_PRIVATE *encILComp = NULL;
	OMX_BUFFERHEADERTYPE *pBufferOut = NULL;
	unsigned int frameCounter = 0;

	encILComp = ((IL_Client *) threadsArg)->encILComp[0];

	/* use the initial i/p buffers and make empty this buffer calls */
	err = IL_ClientEncUseInitialOutputResources (encILComp);

	fd_set rfd;
	int max_fd = encILComp->outPortParams->opBufPipe[0];

	while (1)
	{
		FD_ZERO(&rfd);
		FD_SET(encILComp->outPortParams->opBufPipe[0], &rfd);
	    struct timeval tv;
	    tv.tv_sec = 0;
	    tv.tv_usec = 10000;

	    int ret = select(max_fd+1, &rfd, NULL, NULL, &tv);

	    if(ret<0){
	    	pthread_exit(0);
	    }

	    if(ret>0){
	    	if(FD_ISSET(encILComp->outPortParams->opBufPipe[0], &rfd)){
	    		/* Read filled buffer pointer from the pipe */
	    		read (encILComp->outPortParams->opBufPipe[0], &pBufferOut, sizeof (pBufferOut));

	    		//write data to the datafifo
	    		int frametype;
	    		if((pBufferOut->pBuffer[4]&0xf) == 0x7){
	    			frametype = FRMTYPE_VIDEO_IDR;
	    		}
	    		else {
	    			frametype = FRMTYPE_VIDEO_P;
	    		}

	    		PacknSend2df(pBufferOut->pBuffer, pBufferOut->nFilledLen, frametype, frameCounter, frameCounter, 0, &((IL_Client *) threadsArg)->pt_venc->cvd_producer_fifo_0);
	    		frameCounter++;
	    		if((frameCounter%30)==0){
	    			//printf("storage encode frame = %d\n", frameCounter);
	    		}

	    		/* Pass the input buffer to the component */
	    		err = OMX_FillThisBuffer (encILComp->handle, pBufferOut);

	    		if (OMX_ErrorNone != err)
	    		{
	    			/* put back the frame in pipe and wait for state change */
	    			write (encILComp->outPortParams->opBufPipe[1], &pBufferOut, sizeof (pBufferOut));
	    			printf ("IL_ClientOutputBitStreamWriteTask: waiting for action from IL Client \n");

	    			/* since in this example we are changing states in other thread it will
	    			return error for giving ETB/FTB calls in non-execute state. Since
	    			example is shutting down, we exit the thread */

	    			pthread_exit (encILComp);
	    		}
	    	}
	    }

		if(gILVencClientExit==2)
		{
			//frameCounter = 0;
			semp_post(encILComp->eos);
			pthread_exit(encILComp);
		}
	}
}

void IL_ClientOutputBitStreamWriteTask1(void *threadsArg)
{
	//unsigned int dataRead = 0;
	OMX_ERRORTYPE err = OMX_ErrorNone;
	IL_CLIENT_COMP_PRIVATE *encILComp = NULL;
	OMX_BUFFERHEADERTYPE *pBufferOut = NULL;
	unsigned int frameCounter = 0;

	/* Open the file of data to be rendered.  */

	encILComp = ((IL_Client *) threadsArg)->encILComp[1];

	/* use the initial i/p buffers and make empty this buffer calls */
	err = IL_ClientEncUseInitialOutputResources (encILComp);

	fd_set rfd;
	int max_fd = encILComp->outPortParams->opBufPipe[0];

	while (1)
	{
		FD_ZERO(&rfd);
		FD_SET(encILComp->outPortParams->opBufPipe[0], &rfd);
	    struct timeval tv;
	    tv.tv_sec = 0;
	    tv.tv_usec = 10000;

	    int ret = select(max_fd+1, &rfd, NULL, NULL, &tv);

	    if(ret<0){
	    	pthread_exit(0);
	    }

	    if(ret>0){
	    	if(FD_ISSET(encILComp->outPortParams->opBufPipe[0], &rfd)){
	    		/* Read filled buffer pointer from the pipe */
	    		read (encILComp->outPortParams->opBufPipe[0], &pBufferOut, sizeof (pBufferOut));

	    		int frametype;
	    		if((pBufferOut->pBuffer[4]&0xf) == 0x7){
	    			frametype = FRMTYPE_VIDEO_IDR;
	    		}
	    		else {
	    			frametype = FRMTYPE_VIDEO_P;
	    		}

	    		PacknSend2df(pBufferOut->pBuffer, pBufferOut->nFilledLen, frametype, frameCounter, frameCounter, 1, &((IL_Client *) threadsArg)->pt_venc->cvd_producer_fifo_1);
	    		frameCounter++;
	    		if((frameCounter%30)==0){
	    			//printf("live encode frame = %d\n", frameCounter);
	    		}

	    		/* Pass the input buffer to the component */
	    		err = OMX_FillThisBuffer (encILComp->handle, pBufferOut);

	    		if (OMX_ErrorNone != err)
	    		{
	    			/* put back the frame in pipe and wait for state change */
	    			write (encILComp->outPortParams->opBufPipe[1], &pBufferOut, sizeof (pBufferOut));
	    			printf ("IL_ClientOutputBitStreamWriteTask: waiting for action from IL Client \n");

	    			/* since in this example we are changing states in other thread it will
	    			return error for giving ETB/FTB calls in non-execute state. Since
	    			example is shutting down, we exit the thread */

	    			pthread_exit (encILComp);
	    		}
	    	}
	    }

		if(gILVencClientExit==2)
		{
			pthread_exit(encILComp);
		}
	}
}

void uciPacknSend2df(char *buf, unsigned int len, unsigned int frame_num, unsigned int timestamp, unsigned int channel, t_datafifo *df)
{
	t_frame_info frm_info;
	int i;
	char *ptr;
	unsigned int residual;
	unsigned int pkt_len;
	int flags;

	frm_info.frame_length = len;
	frm_info.frame_num = frame_num;
	frm_info.frame_type = 0;
	frm_info.time_stamp = timestamp;
	frm_info.pkts_in_frame = len/MAX_AVPKT_SIZE;
	residual = len - MAX_AVPKT_SIZE * frm_info.pkts_in_frame;
	if(residual){
		frm_info.pkts_in_frame += 1;
	}

	residual = len;
	ptr = buf;
	for(i=0; i<frm_info.pkts_in_frame; i++){
		frm_info.packet_num = i;
		pkt_len = (MAX_AVPKT_SIZE<residual)?MAX_AVPKT_SIZE:residual;

		//build message
		t_cmd Msg;
		fill_cmd_header(&Msg, COMMAND_EVENT_UCI);
#if 0
		if(type==FRMTYPE_AUDIO){
			add_attr_char(&Msg,"Type", "Audio");
		}
		else{
			add_attr_char(&Msg, "Type", "Video");
		}
#endif
		if(channel == 0){
			add_attr_char(&Msg, "StreamId", "00");
		}
		else{
			add_attr_char(&Msg, "StreamId", "01");
		}
		add_attr_bin(&Msg, "Info", (char *)&frm_info, sizeof(frm_info));
		add_attr_bin(&Msg, "Data", ptr, pkt_len);

		//send the message to data fifo
		size_t size;
		char2hex(Msg.data_len, &size, DATA_LEN_SIZE);
		size += PACKET_HEADER_SIZE;
		//send(sock, Msg.fullbuf, size, 0);
		flags = FRAME_FLAG_NEWFRAME | FRAME_FLAG_FRAMEEND;
		datafifo_producer_data_add(df, Msg.fullbuf, size, flags, 0);
		//debug_printf("send %d bytes\n", ret);
		//calculate new data start point and length left
		ptr += pkt_len;
		residual -= pkt_len;
		//sleep(1);
	}
}

void IL_ClientDei1OutResizerDataTask0(void *threadsArg)
{
	OMX_ERRORTYPE err = OMX_ErrorNone;
	IL_CLIENT_COMP_PRIVATE *deiILComp0 = NULL;
	OMX_BUFFERHEADERTYPE *pBufferOut = NULL;
	OMX_BUFFERHEADERTYPE *pBufferIn = NULL;
	static unsigned int frameCounter = 0;
	struct timeval timestart, timeend;
	double linStart=0, linEnd=0;
	struct edma_buf buf;

	int copied=0;
	FILE *fd_raw = NULL;
	deiILComp0 = ((IL_Client *) threadsArg)->deiILComp[0];
	/* use the initial i/p buffers and make empty this buffer calls */
	err = IL_ClientInitialOutputResources (deiILComp0, 0);

	buf.acnt = RESIZER_WIDTH * 2;
	buf.bcnt = RESIZER_HEIGHT;
	buf.ccnt = 1;
	buf.BRCnt = buf.bcnt;
	buf.srcbidx = buf.acnt;
	buf.desbidx = buf.acnt;
	buf.srccidx = buf.acnt;
	buf.descidx = buf.acnt;
	buf.sync_mode = ABSYNC;
	buf.dmaphysdest = g_encbuf.phy_addr + 0x300000;

	unsigned int frame_cnt = 0;
	fd_set rfd;
	int max_fd = (deiILComp0->outPortParams)->opBufPipe[0];

	while (1)
	{
		FD_ZERO(&rfd);
		FD_SET((deiILComp0->outPortParams)->opBufPipe[0], &rfd);
	    struct timeval tv;
	    tv.tv_sec = 0;
	    tv.tv_usec = 10000;

	    int ret = select(max_fd+1, &rfd, NULL, NULL, &tv);

	    if(ret<0){
	    	pthread_exit(0);
	    }

	    if(ret>0){
	    	if(FD_ISSET((deiILComp0->outPortParams)->opBufPipe[0], &rfd)){
	    		/* Read filled buffer pointer from the pipe */
	    	    read ((deiILComp0->outPortParams)->opBufPipe[0], &pBufferOut, sizeof (pBufferOut));
#if 1
	    	    if(!(frame_cnt%2)){
#if 0
	    	    	buf.dmaphyssrc =  DomxCore_mapUsrVirtualAddr2phy((uint32_t)pBufferOut->pBuffer);
	    	    	write(fd, &buf, 1);
	    	    	CMEM_cacheInv(g_encbuf.vir_addr+0x300000, RESIZER_WIDTH*RESIZER_HEIGHT*2);

	    	    	unsigned char *ptr = g_encbuf.vir_addr+0x300000;
	    	    	uciPacknSend2df(ptr, RESIZER_WIDTH*RESIZER_HEIGHT*2, frame_cnt, frame_cnt, 0, &((IL_Client *) threadsArg)->pt_venc->uci_producer_fifo_0);
#endif
	    	    	uciPacknSend2df(pBufferOut->pBuffer, pBufferOut->nFilledLen, frame_cnt, frame_cnt, 0, &((IL_Client *) threadsArg)->pt_venc->uci_producer_fifo_0);

	    #if 0
	    	    	if(copied<100){
	    	    		if(!fd_raw){
	    	    			fd_raw = fopen("sample.raw", "w");
	    	    		}
	    	    		if(fd_raw){
	    	    			//fwrite(d_ptr, 1, 256*144, fd_raw);
	    	    			fwrite(s_ptr, 1, 256*144*2, fd_raw);
	    	    			printf("%d bytes written to file sample.raw\n", 256*144);
	    	    			//fclose(fd_raw);
	    	    		}
	    	    		copied++;
	    	    	}
	    	    	else{
	    	    		if(fd_raw){
	    	    			fclose(fd_raw);
	    	    			fd_raw = NULL;
	    	    		}
	    	    	}
	    #endif
	    	    }
#endif
	    		if((frame_cnt%300)==0){
	    			printf("uci 0 frame = %d\n", frame_cnt);
	    		}
	    	    /* Pass the input buffer to the component */
	    	    err = OMX_FillThisBuffer (deiILComp0->handle, pBufferOut);
	    	    frame_cnt++;

	    	    if (OMX_ErrorNone != err)
	    	    {
	    	    	/* put back the frame in pipe and wait for state change */
	    	    	write ((deiILComp0->outPortParams)->opBufPipe[1], &pBufferOut, sizeof (pBufferOut));
	    	    	printf ("IL_ClientDei1OutResizerDataTask0: waiting for action from IL Client \n");

	    	    	/* since in this example we are changing states in other thread it will
					return error for giving ETB/FTB calls in non-execute state. Since
					example is shutting down, we exit the thread */

	    	    	pthread_exit (deiILComp0);
	    	    }
	    	}
	    }

	    if(gILVencClientExit){
	    	pthread_exit(0);
	    }
	}
}

void IL_ClientDei1OutResizerDataTask1(void *threadsArg)
{
	OMX_ERRORTYPE err = OMX_ErrorNone;
	IL_CLIENT_COMP_PRIVATE *deiILComp1 = NULL;
	OMX_BUFFERHEADERTYPE *pBufferOut = NULL;
	OMX_BUFFERHEADERTYPE *pBufferIn = NULL;
	static unsigned int frameCounter = 0;
	struct timeval timestart, timeend;
	double linStart=0, linEnd=0;
	struct edma_buf buf;

	int copied=0;
	FILE *fd_raw = NULL;
	deiILComp1 = ((IL_Client *) threadsArg)->deiILComp[1];
	/* use the initial i/p buffers and make empty this buffer calls */
	err = IL_ClientInitialOutputResources (deiILComp1, 0);

	buf.acnt = RESIZER_WIDTH * 2;
	buf.bcnt = RESIZER_HEIGHT;
	buf.ccnt = 1;
	buf.BRCnt = buf.bcnt;
	buf.srcbidx = buf.acnt;
	buf.desbidx = buf.acnt;
	buf.srccidx = buf.acnt;
	buf.descidx = buf.acnt;
	buf.sync_mode = ABSYNC;
	buf.dmaphysdest = g_encbuf.phy_addr + 0x320000;

	unsigned int frame_cnt = 0;
	fd_set rfd;
	int max_fd = (deiILComp1->outPortParams)->opBufPipe[0];
	while (1)
	{
		FD_ZERO(&rfd);
		FD_SET((deiILComp1->outPortParams)->opBufPipe[0], &rfd);
	    struct timeval tv;
	    tv.tv_sec = 0;
	    tv.tv_usec = 10000;

	    int ret = select(max_fd+1, &rfd, NULL, NULL, &tv);

	    if(ret<0){
	    	pthread_exit(0);
	    }

	    if(ret>0){
	    	if(FD_ISSET((deiILComp1->outPortParams)->opBufPipe[0], &rfd)){
	    		/* Read filled buffer pointer from the pipe */
	    		read ((deiILComp1->outPortParams)->opBufPipe[0], &pBufferOut, sizeof (pBufferOut));

	    	    if(!(frame_cnt%2)){
#if 0
	    	    	buf.dmaphyssrc =  DomxCore_mapUsrVirtualAddr2phy((uint32_t)pBufferOut->pBuffer);
	    	    	write(fd, &buf, 1);
	    	    	CMEM_cacheInv(g_encbuf.vir_addr+0x320000, RESIZER_WIDTH*RESIZER_HEIGHT*2);

	    	    	unsigned char *ptr = g_encbuf.vir_addr+0x320000;
	    	    	uciPacknSend2df(ptr, RESIZER_WIDTH*RESIZER_HEIGHT*2, frame_cnt, frame_cnt, 1, &((IL_Client *) threadsArg)->pt_venc->uci_producer_fifo_1);
#endif
	    	    	uciPacknSend2df(pBufferOut->pBuffer, pBufferOut->nFilledLen, frame_cnt, frame_cnt, 1, &((IL_Client *) threadsArg)->pt_venc->uci_producer_fifo_1);
	    #if 0
	    	    	if(copied<100){
	    	    		if(!fd_raw){
	    	    			fd_raw = fopen("sample.raw", "w");
	    	    		}
	    	    		if(fd_raw){
	    	    			//fwrite(d_ptr, 1, 256*144, fd_raw);
	    	    			fwrite(s_ptr, 1, 256*144*2, fd_raw);
	    	    			printf("%d bytes written to file sample.raw\n", 256*144);
	    	    			//fclose(fd_raw);
	    	    		}
	    	    		copied++;
	    	    	}
	    	    	else{
	    	    		if(fd_raw){
	    	    			fclose(fd_raw);
	    	    			fd_raw = NULL;
	    	    		}
	    	    	}
	    #endif
	    	    }

	    		if((frame_cnt%300)==0){
	    			printf("uci 1 frame = %d\n", frame_cnt);
	    		}
	    		/* Pass the input buffer to the component */
	    		err = OMX_FillThisBuffer (deiILComp1->handle, pBufferOut);
	    		frame_cnt++;

	    		if (OMX_ErrorNone != err)
	    		{
	    			/* put back the frame in pipe and wait for state change */
	    			write ((deiILComp1->outPortParams)->opBufPipe[1], &pBufferOut, sizeof (pBufferOut));
	    			printf ("IL_ClientDei1OutResizerDataTask: waiting for action from IL Client \n");

	    			/* since in this example we are changing states in other thread it will
	             	 return error for giving ETB/FTB calls in non-execute state. Since
	             	 example is shutting down, we exit the thread */

	    			pthread_exit (deiILComp1);
	    		}
	    	}
	    }

		if(gILVencClientExit){
			pthread_exit(0);
		}
	}
}

void IL_ClientSDIConnDEITask0(void *threadsArg)
{
  OMX_ERRORTYPE err = OMX_ErrorNone;
  IL_CLIENT_COMP_PRIVATE *capILComp0 = NULL;
  IL_CLIENT_COMP_PRIVATE *deiILComp0 = NULL;
  OMX_BUFFERHEADERTYPE *pBufferOut = NULL;
  OMX_BUFFERHEADERTYPE *pBufferIn = NULL;
  struct edma_buf buf;
  unsigned int i = 0, j = 0;
  int dei0_input_width = 1920, dei0_input_height = 1080;

  dei0_input_width = ((IL_Client *) threadsArg)->nWidth;
  dei0_input_height = ((IL_Client *) threadsArg)->nHeight;

  capILComp0 = ((IL_Client *) threadsArg)->capILComp[0];
  deiILComp0 = ((IL_Client *) threadsArg)->deiILComp[0];

  /* use the initial i/p buffers and make empty this buffer calls */
  err = IL_ClientInitialOutputResources (capILComp0, 0);
  err = IL_ClientInitialInputResources (deiILComp0);

  buf.acnt = 1920 * 3;
  buf.bcnt = 1080 >> 1;
  buf.ccnt = 1;
  buf.BRCnt = buf.bcnt;
  buf.srcbidx = buf.acnt;
  buf.desbidx = buf.acnt;
  buf.srccidx = buf.acnt;
  buf.descidx = buf.acnt;
  buf.sync_mode = ABSYNC;

#if 0
  for (i = 0; i < deiILComp0->inPortParams->nBufferCountActual; i++)
  {
    /* Read filled buffer pointer from the pipe */
    read ((capILComp0->outPortParams)->opBufPipe[0],
          &pBufferOut, sizeof (pBufferOut));

    buf.dmaphyssrc =  DomxCore_mapUsrVirtualAddr2phy((uint32_t)pBufferOut->pBuffer);
    buf.dmaphysdest = DomxCore_mapUsrVirtualAddr2phy((uint32_t)deiILComp0->inPortParams->pInBuff[i]->pBuffer);

    buf.acnt = dei0_input_width;
    buf.bcnt = dei0_input_height;
    buf.ccnt = 1;
    buf.BRCnt = buf.bcnt;
    buf.srcbidx = 1920;
    buf.desbidx = buf.acnt;
    buf.srccidx = 1920;
    buf.descidx = buf.acnt;
    buf.sync_mode = ABSYNC;
    write(fd, &buf, 1);

    buf.dmaphyssrc = buf.dmaphyssrc + 1920*1080;
    buf.dmaphysdest = buf.dmaphysdest + dei0_input_width*dei0_input_height;
    buf.acnt = dei0_input_width;
    buf.bcnt = (dei0_input_height >> 1);
    buf.ccnt = 1;
    buf.BRCnt = buf.bcnt;
    buf.srcbidx = 1920;
    buf.desbidx = buf.acnt;
    buf.srccidx = 1920;
    buf.descidx = buf.acnt;
    buf.sync_mode = ABSYNC;
    write(fd, &buf, 1);

    deiILComp0->inPortParams->pInBuff[i]->nFilledLen = (dei0_input_width * dei0_input_height * 3) >> 1;

    /* Pass the input buffer to the component */
    err = OMX_FillThisBuffer (capILComp0->handle, pBufferOut);
    err = OMX_EmptyThisBuffer (deiILComp0->handle,
                               deiILComp0->inPortParams->pInBuff[i]);
  }
#endif

	i = 0;
	fd_set rfd;
	int max_fd = (capILComp0->outPortParams)->opBufPipe[0];

  while (1)
  {
		FD_ZERO(&rfd);
		FD_SET((capILComp0->outPortParams)->opBufPipe[0], &rfd);
	    struct timeval tv;
	    tv.tv_sec = 0;
	    tv.tv_usec = 10000;

	    int ret = select(max_fd+1, &rfd, NULL, NULL, &tv);

	    if(ret<0){
	    	pthread_exit(0);
	    }

	    if(ret>0){
	    	if(FD_ISSET((capILComp0->outPortParams)->opBufPipe[0], &rfd)){
	    	    /* Read filled buffer pointer from the pipe */
	    	    read ((capILComp0->outPortParams)->opBufPipe[0], &pBufferOut, sizeof (pBufferOut));
	    	    buf.dmaphyssrc =  DomxCore_mapUsrVirtualAddr2phy((uint32_t)pBufferOut->pBuffer);

	    	    /* Read empty buffer pointer from the pipe */
	    	    if(i<deiILComp0->inPortParams->nBufferCountActual){
	    	    	buf.dmaphysdest = DomxCore_mapUsrVirtualAddr2phy((uint32_t)deiILComp0->inPortParams->pInBuff[i]->pBuffer);
	    	    }
	    	    else{
		    	    read (deiILComp0->inPortParams->ipBufPipe[0], &pBufferIn, sizeof (pBufferIn));
		    	    buf.dmaphysdest = DomxCore_mapUsrVirtualAddr2phy((uint32_t)pBufferIn->pBuffer);
	    	    }

	    	    buf.acnt = dei0_input_width;
	    	    buf.bcnt = dei0_input_height;
	    	    buf.ccnt = 1;
	    	    buf.BRCnt = buf.bcnt;
	    	    buf.srcbidx = 1920;
	    	    buf.desbidx = buf.acnt;
	    	    buf.srccidx = 1920;
	    	    buf.descidx = buf.acnt;
	    	    buf.sync_mode = ABSYNC;
	    	    write(fd, &buf, 1);

	    	    buf.dmaphyssrc = buf.dmaphyssrc + 1920*1080;
	    	    buf.dmaphysdest = buf.dmaphysdest + dei0_input_width*dei0_input_height;
	    	    buf.acnt = dei0_input_width;
	    	    buf.bcnt = (dei0_input_height >> 1);
	    	    buf.ccnt = 1;
	    	    buf.BRCnt = buf.bcnt;
	    	    buf.srcbidx = 1920;
	    	    buf.desbidx = buf.acnt;
	    	    buf.srccidx = 1920;
	    	    buf.descidx = buf.acnt;
	    	    buf.sync_mode = ABSYNC;
	    	    write(fd, &buf, 1);

	    	    //pBufferIn->nFilledLen = (dei1_input_width * dei1_input_height * 3) >> 1;

	    	    /* Pass the input buffer to the component */
	    	    err = OMX_FillThisBuffer (capILComp0->handle, pBufferOut);

	    	    /* Pass the input buffer to the component */
	    	    if(i<deiILComp0->inPortParams->nBufferCountActual){
	    	    	deiILComp0->inPortParams->pInBuff[i]->nFilledLen = (dei0_input_width*dei0_input_height*3) >> 1;
	    	    	err = OMX_EmptyThisBuffer (deiILComp0->handle, deiILComp0->inPortParams->pInBuff[i]);
	    	    }
	    	    else{
	    	    	pBufferIn->nFilledLen = (dei0_input_width * dei0_input_height * 3) >> 1;
	    	    	err = OMX_EmptyThisBuffer (deiILComp0->handle, pBufferIn);
	    	    }

	    	    i++;

	    	    if (OMX_ErrorNone != err)
	    	    {
	    	      /* put back the frame in pipe and wait for state change */
	    	      write (capILComp0->outPortParams->opBufPipe[1],
	    	             &pBufferOut, sizeof (pBufferOut));
	    	      printf ("IL_ClientSDIConnDEITask: waiting for action from IL Client \n");

	    	      /* since in this example we are changing states in other thread it will
	    	         return error for giving ETB/FTB calls in non-execute state. Since
	    	         example is shutting down, we exit the thread */

	    	      pthread_exit(capILComp0);
	    	    }
	    	}
	    }

  	if(gILClientExit || gILVencClientExit){
  		gILVencClientExit = 2;
  		pthread_exit(0);
  	}
	}
}

void IL_ClientSDIConnDEITask1(void *threadsArg)
{
	OMX_ERRORTYPE err = OMX_ErrorNone;
	IL_CLIENT_COMP_PRIVATE *capILComp1 = NULL;
	IL_CLIENT_COMP_PRIVATE *deiILComp1 = NULL;
	OMX_BUFFERHEADERTYPE *pBufferOut = NULL;
	OMX_BUFFERHEADERTYPE *pBufferIn = NULL;
	struct edma_buf buf;
	unsigned int i = 0, j = 0;
	int dei1_input_width = 1920, dei1_input_height = 1080;

	dei1_input_width = ((IL_Client *) threadsArg)->nWidth;
	dei1_input_height = ((IL_Client *) threadsArg)->nHeight;

	capILComp1 = ((IL_Client *) threadsArg)->capILComp[1];
	deiILComp1 = ((IL_Client *) threadsArg)->deiILComp[1];

	/* use the initial i/p buffers and make empty this buffer calls */
	err = IL_ClientInitialOutputResources (capILComp1, 0);
	err = IL_ClientInitialInputResources (deiILComp1);

#if 0
	for (i = 0; i < deiILComp1->inPortParams->nBufferCountActual; i++)
	{
		/* Read filled buffer pointer from the pipe */
		read ((capILComp1->outPortParams)->opBufPipe[0], &pBufferOut, sizeof (pBufferOut));

		buf.dmaphyssrc =  DomxCore_mapUsrVirtualAddr2phy((uint32_t)pBufferOut->pBuffer);
		buf.dmaphysdest = DomxCore_mapUsrVirtualAddr2phy((uint32_t)deiILComp1->inPortParams->pInBuff[i]->pBuffer);

		buf.acnt = dei1_input_width;
		buf.bcnt = dei1_input_height;
		buf.ccnt = 1;
		buf.BRCnt = buf.bcnt;
		buf.srcbidx = 1920;
		buf.desbidx = buf.acnt;
		buf.srccidx = 1920;
		buf.descidx = buf.acnt;
		buf.sync_mode = ABSYNC;
		write(fd, &buf, 1);

		buf.dmaphyssrc = buf.dmaphyssrc + 1920*1080;
		buf.dmaphysdest = buf.dmaphysdest + dei1_input_width*dei1_input_height;
		buf.acnt = dei1_input_width;
		buf.bcnt = (dei1_input_height >> 1);
		buf.ccnt = 1;
		buf.BRCnt = buf.bcnt;
		buf.srcbidx = 1920;
		buf.desbidx = buf.acnt;
		buf.srccidx = 1920;
		buf.descidx = buf.acnt;
		buf.sync_mode = ABSYNC;
		write(fd, &buf, 1);

		deiILComp1->inPortParams->pInBuff[i]->nFilledLen = (dei1_input_width*dei1_input_height*3) >> 1;

		/* Pass the input buffer to the component */
		err = OMX_FillThisBuffer (capILComp1->handle, pBufferOut);
		err = OMX_EmptyThisBuffer (deiILComp1->handle, deiILComp1->inPortParams->pInBuff[i]);
	}
#endif

	i = 0;
	fd_set rfd;
	int max_fd = (capILComp1->outPortParams)->opBufPipe[0];

  while (1)
  {
		FD_ZERO(&rfd);
		FD_SET((capILComp1->outPortParams)->opBufPipe[0], &rfd);
	    struct timeval tv;
	    tv.tv_sec = 0;
	    tv.tv_usec = 10000;

	    int ret = select(max_fd+1, &rfd, NULL, NULL, &tv);

	    if(ret<0){
	    	pthread_exit(0);
	    }

	    if(ret>0){
	    	if(FD_ISSET((capILComp1->outPortParams)->opBufPipe[0], &rfd)){
	    	    /* Read filled buffer pointer from the pipe */
	    	    read ((capILComp1->outPortParams)->opBufPipe[0], &pBufferOut, sizeof (pBufferOut));
	    	    buf.dmaphyssrc =  DomxCore_mapUsrVirtualAddr2phy((uint32_t)pBufferOut->pBuffer);

	    	    /* Read empty buffer pointer from the pipe */
	    	    if(i<deiILComp1->inPortParams->nBufferCountActual){
	    	    	buf.dmaphysdest = DomxCore_mapUsrVirtualAddr2phy((uint32_t)deiILComp1->inPortParams->pInBuff[i]->pBuffer);
	    	    }
	    	    else{
		    	    read (deiILComp1->inPortParams->ipBufPipe[0], &pBufferIn, sizeof (pBufferIn));
		    	    buf.dmaphysdest = DomxCore_mapUsrVirtualAddr2phy((uint32_t)pBufferIn->pBuffer);
	    	    }

	    	    buf.acnt = dei1_input_width;
	    	    buf.bcnt = dei1_input_height;
	    	    buf.ccnt = 1;
	    	    buf.BRCnt = buf.bcnt;
	    	    buf.srcbidx = 1920;
	    	    buf.desbidx = buf.acnt;
	    	    buf.srccidx = 1920;
	    	    buf.descidx = buf.acnt;
	    	    buf.sync_mode = ABSYNC;
	    	    write(fd, &buf, 1);

	    	    buf.dmaphyssrc = buf.dmaphyssrc + 1920*1080;
	    	    buf.dmaphysdest = buf.dmaphysdest + dei1_input_width*dei1_input_height;
	    	    buf.acnt = dei1_input_width;
	    	    buf.bcnt = (dei1_input_height >> 1);
	    	    buf.ccnt = 1;
	    	    buf.BRCnt = buf.bcnt;
	    	    buf.srcbidx = 1920;
	    	    buf.desbidx = buf.acnt;
	    	    buf.srccidx = 1920;
	    	    buf.descidx = buf.acnt;
	    	    buf.sync_mode = ABSYNC;
	    	    write(fd, &buf, 1);

	    	    //pBufferIn->nFilledLen = (dei1_input_width * dei1_input_height * 3) >> 1;

	    	    /* Pass the input buffer to the component */
	    	    err = OMX_FillThisBuffer (capILComp1->handle, pBufferOut);

	    	    /* Pass the input buffer to the component */
	    	    if(i<deiILComp1->inPortParams->nBufferCountActual){
	    	    	deiILComp1->inPortParams->pInBuff[i]->nFilledLen = (dei1_input_width*dei1_input_height*3) >> 1;
	    	    	err = OMX_EmptyThisBuffer (deiILComp1->handle, deiILComp1->inPortParams->pInBuff[i]);
	    	    }
	    	    else{
	    	    	pBufferIn->nFilledLen = (dei1_input_width * dei1_input_height * 3) >> 1;
	    	    	err = OMX_EmptyThisBuffer (deiILComp1->handle, pBufferIn);
	    	    }

	    	    i++;

	    	    if (OMX_ErrorNone != err)
	    	    {
	    	      /* put back the frame in pipe and wait for state change */
	    	      write (capILComp1->outPortParams->opBufPipe[1],
	    	             &pBufferOut, sizeof (pBufferOut));
	    	      printf ("IL_ClientSDIConnDEITask: waiting for action from IL Client \n");

	    	      /* since in this example we are changing states in other thread it will
	    	         return error for giving ETB/FTB calls in non-execute state. Since
	    	         example is shutting down, we exit the thread */

	    	      pthread_exit(capILComp1);
	    	    }
	    	}
	    }

    	if(gILClientExit || gILVencClientExit){
    		//gILVencClientExit = 2;
    		pthread_exit(0);
    	}
	}
}

/* ========================================================================== */
/**
* IL_ClientConnInConnOutTask() : This task function is for passing buffers from
* one component to other connected component. This functions reads from local
* pipe of a perticular component , and takes action based on the message in the
* pipe. This pipe is written by callback ( EBD/FBD) function from component and
* from other component threads, which writes into this pipe for buffer 
* communication.
*
* @param threadsArg        : Handle to a particular component
*
*/
/* ========================================================================== */

void IL_ClientConnInConnOutTask(void *threadsArg)
{
  IL_CLIENT_PIPE_MSG pipeMsg;
  IL_CLIENT_COMP_PRIVATE *thisComp = (IL_CLIENT_COMP_PRIVATE *) threadsArg;
  OMX_ERRORTYPE err = OMX_ErrorNone;

  /* Initially pipes will not have any buffers, so components needs to be given 
     empty buffers for output ports. Input bufefrs are given by other
     component, or file read task */
  IL_ClientUseInitialOutputResources (thisComp);

  for (;;)
  {
    /* Read from its own local Pipe */
    read (thisComp->localPipe[0], &pipeMsg, sizeof (IL_CLIENT_PIPE_MSG));

    /* check the function type */

    switch (pipeMsg.cmd)
    {

      case IL_CLIENT_PIPE_CMD_EXIT:
        printf ("exiting thread \n ");
        pthread_exit (thisComp);
        break;
      case IL_CLIENT_PIPE_CMD_ETB:
        err = IL_ClientProcessPipeCmdETB (thisComp, &pipeMsg);
        /* If not in proper state, bufers may not be accepted by component */
        if (OMX_ErrorNone != err)
        {
          write (thisComp->localPipe[1], &pipeMsg, sizeof (IL_CLIENT_PIPE_MSG));
          printf (" ETB: wait \n");
          /* since in this example we are changing states in other thread it
             will return error for giving ETB/FTB calls in non-execute state.
             Since example is shutting down, we exit the thread */
          pthread_exit (thisComp);
          /* if error is incorrect state operation, wait for state to change */
          /* waiting mechanism should be implemented here */
        }

        break;
      case IL_CLIENT_PIPE_CMD_FTB:
        err = IL_ClientProcessPipeCmdFTB (thisComp, &pipeMsg);

        if (OMX_ErrorNone != err)
        {
          write (thisComp->localPipe[1], &pipeMsg, sizeof (IL_CLIENT_PIPE_MSG));
          printf (" FTB: wait \n");
          /* if error is incorrect state operation, wait for state to change */
          /* waiting mechanism should be implemented here */
          /* since in this example we are changing states in other thread it
             will return error for giving ETB/FTB calls in non-execute state.
             Since example is shutting down, we exit the thread */
          pthread_exit (thisComp);

        }
        break;

      case IL_CLIENT_PIPE_CMD_EBD:
        IL_ClientProcessPipeCmdEBD (thisComp, &pipeMsg);

        break;
      case IL_CLIENT_PIPE_CMD_FBD:
        IL_ClientProcessPipeCmdFBD (thisComp, &pipeMsg);
        break;
      default:
        break;
    }
  }
}

/* ========================================================================== */
/**
* IL_ClientProcessPipeCmdETB() : This function passes the bufefrs to component
* for consuming. This buffer will come from other component as an output. To 
* consume it, IL client finds its bufefr header (for consumer component), and 
* calls ETB call.
* @param thisComp        : Handle to a particular component
* @param pipeMsg         : message structure, which is written in response to 
*                          callbacks
*
*/
/* ========================================================================== */

OMX_ERRORTYPE IL_ClientProcessPipeCmdETB(IL_CLIENT_COMP_PRIVATE *thisComp,
                                          IL_CLIENT_PIPE_MSG *pipeMsg)
{
  OMX_ERRORTYPE err = OMX_ErrorNone;
  OMX_BUFFERHEADERTYPE *pBufferIn;

  /* search its own buffer header based on submitted by connected comp */
  IL_ClientUtilGetSelfBufHeader (thisComp, pipeMsg->bufHeader.pBuffer,
                                 ILCLIENT_INPUT_PORT,
                                 pipeMsg->bufHeader.nInputPortIndex,
                                 &pBufferIn);

  /* populate buffer header */
  pBufferIn->nFilledLen = pipeMsg->bufHeader.nFilledLen;
  pBufferIn->nOffset = pipeMsg->bufHeader.nOffset;
  pBufferIn->nTimeStamp = pipeMsg->bufHeader.nTimeStamp;
  pBufferIn->nFlags = pipeMsg->bufHeader.nFlags;
  pBufferIn->hMarkTargetComponent = pipeMsg->bufHeader.hMarkTargetComponent;
  pBufferIn->pMarkData = pipeMsg->bufHeader.pMarkData;
  pBufferIn->nTickCount = 0;

  /* call etb to the component */
  err = OMX_EmptyThisBuffer (thisComp->handle, pBufferIn);
  return (err);
}

/* ========================================================================== */
/**
* IL_ClientProcessPipeCmdFTB() : This function passes the bufefrs to component
* for consuming. This buffer will come from other component as consumed at input
* To  consume it, IL client finds its bufefr header (for consumer component),
* and calls FTB call.
* @param thisComp        : Handle to a particular component
* @param pipeMsg         : message structure, which is written in response to 
*                          callbacks
*
*/
/* ========================================================================== */

OMX_ERRORTYPE IL_ClientProcessPipeCmdFTB(IL_CLIENT_COMP_PRIVATE *thisComp,
                                          IL_CLIENT_PIPE_MSG *pipeMsg)
{
  OMX_ERRORTYPE err = OMX_ErrorNone;
  OMX_BUFFERHEADERTYPE *pBufferOut;

  /* search its own buffer header based on submitted by connected comp */
  IL_ClientUtilGetSelfBufHeader (thisComp, pipeMsg->bufHeader.pBuffer,
                                 ILCLIENT_OUTPUT_PORT,
                                 pipeMsg->bufHeader.nOutputPortIndex,
                                 &pBufferOut);

  /* call etb to the component */
  err = OMX_FillThisBuffer (thisComp->handle, pBufferOut);

  return (err);
}

/* ========================================================================== */
/**
* IL_ClientProcessPipeCmdEBD() : This function passes the bufefrs to component
* for consuming. This empty buffer will go to other component to be reused at 
* output port.
* @param thisComp        : Handle to a particular component
* @param pipeMsg         : message structure, which is written in response to 
*                          callbacks
*
*/
/* ========================================================================== */

OMX_ERRORTYPE IL_ClientProcessPipeCmdEBD(IL_CLIENT_COMP_PRIVATE *thisComp,
                                          IL_CLIENT_PIPE_MSG *pipeMsg)
{
  OMX_ERRORTYPE err = OMX_ErrorNone;
  OMX_BUFFERHEADERTYPE *pBufferIn;
  IL_CLIENT_PIPE_MSG remotePipeMsg;
  IL_CLIENT_INPORT_PARAMS *inPortParamsPtr;
  int retVal = 0;

  pBufferIn = pipeMsg->pbufHeader;

  /* find the input port structure (pipe) */
  inPortParamsPtr = thisComp->inPortParams + pBufferIn->nInputPortIndex;

  remotePipeMsg.cmd = IL_CLIENT_PIPE_CMD_FTB;
  remotePipeMsg.bufHeader.pBuffer = pBufferIn->pBuffer;
  remotePipeMsg.bufHeader.nOutputPortIndex =
    inPortParamsPtr->connInfo.remotePort;

  /* write the fill buffer message to remote pipe */
  retVal = write (inPortParamsPtr->connInfo.remotePipe[1],
                  &remotePipeMsg, sizeof (IL_CLIENT_PIPE_MSG));

  if (sizeof (IL_CLIENT_PIPE_MSG) != retVal)
  {
    printf ("Error writing to remote Pipe!\n");
    err = OMX_ErrorNotReady;
    return err;
  }

  return (err);
}

/* ========================================================================== */
/**
* IL_ClientProcessPipeCmdFBD() : This function passes the bufefrs to component
* for consuming. This buffer will go to other component to be consumed at input
* port.
* @param thisComp        : Handle to a particular component
* @param pipeMsg         : message structure, which is written in response to 
*                          callbacks
*
*/
/* ========================================================================== */

OMX_ERRORTYPE IL_ClientProcessPipeCmdFBD(IL_CLIENT_COMP_PRIVATE *thisComp,
                                          IL_CLIENT_PIPE_MSG *pipeMsg)
{
  OMX_ERRORTYPE err = OMX_ErrorNone;
  OMX_BUFFERHEADERTYPE *pBufferOut;
  IL_CLIENT_PIPE_MSG remotePipeMsg;
  IL_CLIENT_OUTPORT_PARAMS *outPortParamsPtr;
  int retVal = 0;
  pBufferOut = pipeMsg->pbufHeader;

  remotePipeMsg.cmd = IL_CLIENT_PIPE_CMD_ETB;
  remotePipeMsg.bufHeader.pBuffer = pBufferOut->pBuffer;

  outPortParamsPtr =
    thisComp->outPortParams + (pBufferOut->nOutputPortIndex -
                               thisComp->startOutportIndex);

  /* populate buffer header */
  remotePipeMsg.bufHeader.nFilledLen = pBufferOut->nFilledLen;
  remotePipeMsg.bufHeader.nOffset = pBufferOut->nOffset;
  remotePipeMsg.bufHeader.nTimeStamp = pBufferOut->nTimeStamp;
  remotePipeMsg.bufHeader.nFlags = pBufferOut->nFlags;
  remotePipeMsg.bufHeader.hMarkTargetComponent =
    pBufferOut->hMarkTargetComponent;
  remotePipeMsg.bufHeader.pMarkData = pBufferOut->pMarkData;
  remotePipeMsg.bufHeader.nTickCount = pBufferOut->nTickCount;
  remotePipeMsg.bufHeader.nInputPortIndex =
    outPortParamsPtr->connInfo.remotePort;

  /* write the fill buffer message to remote pipe */
  retVal = write (outPortParamsPtr->connInfo.remotePipe[1],
                  &remotePipeMsg, sizeof (IL_CLIENT_PIPE_MSG));

  if (sizeof (IL_CLIENT_PIPE_MSG) != retVal)
  {
    printf ("Error writing to remote Pipe!\n");
    err = OMX_ErrorNotReady;
    return err;
  }

  return (err);
}

/* ========================================================================== */
/**
* IL_ClientSIGINTHandler() : This function is the SIGINT handler that will be
* called when the user invokes CTRL-C. This is for demonstration purpose. Also
* it assumes that the OMX chain is in EXECUTING state when CTRL-C is invoked
*
* @param sig             : Signal identifier
*/
/* ========================================================================== */
void IL_ClientSIGINTHandler(int sig)
{
 gILClientExit = OMX_TRUE;
 printf("IL_ClientSIGINTHandler: gILClientExit %d\n", OMX_TRUE);
}

/* ========================================================================== */
/**
* Capture_Encode_Example() : This method is the IL Client implementation for 
* connecting capture, dei and display, and Encode OMX components. This function
*  creates configures, and connects the components.
* it manages the buffer communication.
*
* @param args         : parameters( widt,height,frame rate etc) for this function
*
*  @return      
*  OMX_ErrorNone = Successful 
*
*  Other_value = Failed (Error code is returned)
*
*/
/* ========================================================================== */

/* Main IL Client application to create , intiate and connect components */

int Capture_Encode_Example(void *thread_args)
{
  IL_Client *pAppData = NULL;
  OMX_ERRORTYPE eError = OMX_ErrorNone;
  OMX_U32 i, j, m;
  OMX_S32 ret_value;
  OMX_BOOL bUseSwMosaic;  
  IL_CLIENT_PIPE_MSG pipeMsg;
  IL_CLIENT_INPORT_PARAMS  *inPortParamsPtr = NULL;
  IL_CLIENT_OUTPORT_PARAMS *outPortParamsPtr = NULL;
  gILClientExit = OMX_FALSE;
  gILVencClientExit = OMX_FALSE;

  printf("g_max_decode =%d\n", g_max_decode);

  bUseSwMosaic = OMX_FALSE;
  /* Initialize application specific data structures and buffer management
     data */
  IL_ARGS arg;
  IL_ARGS *args = &arg;

  if(g_cfg_param.frame_height == 1080){
	  strcpy(args->mode, "1080p");
  }
  else{
	  strcpy(args->mode, "720p");
  }
  args->frame_rate = 60; //60; //g_cfg_param.frame_rate;
  args->bit_rate = g_cfg_param.bit_rate*1000;//1000000;
  args->num_frames = 10000;
  args->display_id = 0;
  strcpy(args->output_file, "sample.h264");

  IL_ClientInit (&pAppData, args->mode, args->frame_rate,
                 args->bit_rate, args->num_frames, args->display_id);

  
  pAppData->pt_venc = (t_venc *)thread_args;

  fd = open("/dev/edma_test", O_RDWR); 
  if (fd<0) {
        printf("Can't Open edma_test");
  }

  printf (" openeing file \n");

  /* Open the file of data to be rendered.  */
  pAppData->fOut = fopen (args->output_file, "wb");
    
  if (pAppData->fOut == NULL)
  {
    printf ("Error: failed to open the file %s for writing \n",
            args->output_file);
    goto EXIT;
  }

  /* Initialize application / IL Client callback functions */
  /* Callbacks are passed during getHandle call to component, component uses
     these callabacks to communicate with IL Client */
  /* event handler is to handle the state changes , omx commands and any
     message for IL client */
  pAppData->pCb.EventHandler = IL_ClientCbEventHandler;

  /* Empty buffer done is data callback at the input port, where component let
     the application know that buffer has been consumed, this is not applicabel 
     if there is no input port in the component */
  pAppData->pCb.EmptyBufferDone = IL_ClientCbEmptyBufferDone;

  /* fill buffer done is callback at the output port, where component lets the
     application know that an output buffer is available with the processed data 
   */
  pAppData->pCb.FillBufferDone = IL_ClientCbFillBufferDone;

/******************************************************************************/
  /* Create the capture Component, component handle would be returned component 
     name is unique and fixed for a componnet, callback are passed to
     component in this function. component would be in loaded state post this
     call */
     
  for( i = 0; i < g_max_decode; i++) {
    eError =
      OMX_GetHandle (&pAppData->pCapHandle[i],
                     (OMX_STRING) "OMX.TI.VPSSM3.VFCC", pAppData->capILComp[i],
                     &pAppData->pCb);
    
    printf (" capture compoenent is created \n");
    
    if ((eError != OMX_ErrorNone) || (pAppData->pCapHandle[i] == NULL))
    {
      printf ("Error in Get Handle function : %s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    
    pAppData->capILComp[i]->handle = pAppData->pCapHandle[i];
    
    /* This is control component, without ports. It is implemented as OMX
       component */
    eError =
      OMX_GetHandle (&pAppData->pTvpHandle[i],
                     (OMX_STRING) "OMX.TI.VPSSM3.CTRL.TVP",
                     pAppData->capILComp[i], &pAppData->pCb);
    
    printf (" control TVP compoenent is created \n");
    
    if ((eError != OMX_ErrorNone) || (pAppData->pTvpHandle[i] == NULL))
    {
      printf ("Error in Get Handle function : %s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    
    /* Configute the capture componet */
    /* calling OMX_Setparam in this function */
    IL_ClientSetCaptureParams (pAppData, i);

    printf ("enable capture output port \n");
    
    OMX_SendCommand (pAppData->pCapHandle[i], OMX_CommandPortEnable,
                     OMX_VFCC_OUTPUT_PORT_START_INDEX, NULL);
    
    semp_pend (pAppData->capILComp[i]->port_sem);
  }

/******************************************************************************/
  /* Create DEI component, it creatd OMX compponent for dei writeback, Int
     this client we are passing the same callbacks to all the components */

  for( i = 0; i < g_max_decode; i++) {
    eError =
      OMX_GetHandle (&pAppData->pDeiHandle[i],
                     (OMX_STRING) "OMX.TI.VPSSM3.VFPC.DEIMDUALOUT",
                     pAppData->deiILComp[i], &pAppData->pCb);
    
    if ((eError != OMX_ErrorNone) || (pAppData->pDeiHandle[i] == NULL))
    {
      printf ("Error in Get Handle function : %s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    pAppData->deiILComp[i]->handle = pAppData->pDeiHandle[i];
    
    printf (" dei compoenent is created \n");
    
    /* omx calls are made in this function for setting the parameters for DEI
       component, For clarity purpose it is written as separate function */
    
    IL_ClientSetDeiParams (pAppData, i);
    
    /* enable input and output port */
    /* as per openmax specs all the ports should be enabled by default but EZSDK
       OMX component does not enable it hence we manually need to enable it. */
    
    printf ("enable dei input port \n");
    OMX_SendCommand (pAppData->pDeiHandle[i], OMX_CommandPortEnable,
                     OMX_VFPC_INPUT_PORT_START_INDEX, NULL);
    
    /* wait for both ports to get enabled, event handler would be notified from
       the component after enabling the port, which inturn would post this
       semaphore */
    semp_pend (pAppData->deiILComp[i]->port_sem);
    
    printf ("enable dei output port 0 \n");
    OMX_SendCommand (pAppData->pDeiHandle[i], OMX_CommandPortEnable,
                     OMX_VFPC_OUTPUT_PORT_START_INDEX, NULL);
    semp_pend (pAppData->deiILComp[i]->port_sem);
    
    printf ("enable dei output port 1 \n");
    OMX_SendCommand (pAppData->pDeiHandle[i], OMX_CommandPortEnable,
                     OMX_VFPC_OUTPUT_PORT_START_INDEX + 1, NULL);
    semp_pend (pAppData->deiILComp[i]->port_sem);
  }

/******************************************************************************/
  /* Create Scalar component, it created OMX component for scalar writeback ,
     In this client we are passing the same callbacks to all the components */
  for (i = 0; i < g_max_scalar; i++) {
   eError =
     OMX_GetHandle (&pAppData->pScHandle[i],
                    (OMX_STRING) "OMX.TI.VPSSM3.VFPC.INDTXSCWB",
                    pAppData->scILComp[i], &pAppData->pCb);

   if ((eError != OMX_ErrorNone) || (pAppData->pScHandle[i] == NULL))
   {
     printf ("Error in Get Handle function : %s \n",
             IL_ClientErrorToStr (eError));
     goto EXIT;
   }
   pAppData->scILComp[i]->handle = pAppData->pScHandle[i];

   printf ("scalar component %d is created \n", i);

   /* omx calls are made in this function for setting the parameters for scalar
      component, For clarity purpose it is written as separate function */

   IL_ClientSetScalarParams (pAppData, i);

   /* enable input and output port */
   /* as per openmax specs all the ports should be enabled by default but EZSDK
      OMX component does not enable it hence we manually need to enable it. */

   printf ("enable scalar input port \n");
   OMX_SendCommand (pAppData->pScHandle[i], OMX_CommandPortEnable,
                    OMX_VFPC_INPUT_PORT_START_INDEX, NULL);

   /* wait for both ports to get enabled, event handler would be notified from
      the component after enabling the port, which inturn would post this
      semaphore */
   semp_pend (pAppData->scILComp[i]->port_sem);

   printf ("enable scalar output port \n");
   OMX_SendCommand (pAppData->pScHandle[i], OMX_CommandPortEnable,
                    OMX_VFPC_OUTPUT_PORT_START_INDEX, NULL);
   semp_pend (pAppData->scILComp[i]->port_sem);
 }
   /* Noise filter is used to convert 422 o/p to 420 for SD display only */
   /* Create NF component, it creatd OMX compponnet for Dei writeback ,
     Int this client we are passing the same callbacks to all the component */
 for (i = 0; i < g_max_NF; i++) {
   eError =
     OMX_GetHandle (&pAppData->pNfHandle[i],
                    (OMX_STRING) "OMX.TI.VPSSM3.VFPC.NF",
                    pAppData->nfILComp[i], &pAppData->pCb);

   if ((eError != OMX_ErrorNone) || (pAppData->pNfHandle[i] == NULL))
   {
     printf ("Error in Get Handle function : %s \n",
             IL_ClientErrorToStr (eError));
     goto EXIT;
   }
   pAppData->nfILComp[i]->handle = pAppData->pNfHandle[i];

   printf (" NF compoenent is created \n");

   /* omx calls are made in this function for setting the parameters for Dei
      component, For clarity purpose it is written as separate function */

   IL_ClientSetNfParams (pAppData, i);

   /* enable input and output port */
   /* as per openmax specs all the ports should be enabled by default but EZSDK
      OMX component does not enable it hence we manually need to enable it. */

   printf ("enable NF input port \n");
   OMX_SendCommand (pAppData->pNfHandle[i], OMX_CommandPortEnable,
                    OMX_VFPC_INPUT_PORT_START_INDEX, NULL);

   /* wait for both ports to get enabled, event handler would be notified from
      the component after enabling the port, which inturn would post this
      semaphore */
   semp_pend (pAppData->nfILComp[i]->port_sem);

   printf ("enable NF output port \n");
   OMX_SendCommand (pAppData->pNfHandle[i], OMX_CommandPortEnable,
                    OMX_VFPC_OUTPUT_PORT_START_INDEX, NULL);
   semp_pend (pAppData->nfILComp[i]->port_sem);
 }

/******************************************************************************/
  /* Create the H264 encoder Component, component handle would be returned
     component name is unique and fixed for a componnet, callback are passed
     to componnet in this function. component would be loaded state post this
     call */

  for( i = 0; i < g_max_decode; i++) {
    eError =
      OMX_GetHandle (&pAppData->pEncHandle[i],
                     (OMX_STRING) "OMX.TI.DUCATI.VIDENC", pAppData->encILComp[i],
                     &pAppData->pCb);
    
    printf (" encoder compoenent is created \n");
    
    if ((eError != OMX_ErrorNone) || (pAppData->pEncHandle[i] == NULL))
    {
      printf ("Error in Get Handle function : %s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    
    pAppData->encILComp[i]->handle = pAppData->pEncHandle[i];
    
    /* Configute the encode componet, ports are default enabled for encode comp,
       so no need to enable from IL Client */
    /* calling OMX_Setparam in this function */
    IL_ClientSetEncodeParams (pAppData, i);
  }

/******************************************************************************/

/******************************************************************************/
/* Create and Configure the display component. It will use VFDC component on  */
/* media controller.                                                          */
/******************************************************************************/

  /* Create the display component */
  /* getting display component handle */
  for( i = 0; i < g_max_display; i++) {    
    eError =
      OMX_GetHandle (&pAppData->pDisHandle[i], "OMX.TI.VPSSM3.VFDC",
                     pAppData->disILComp[i], &pAppData->pCb);
    if (eError != OMX_ErrorNone)
    {
      ERROR ("failed to get handle\n");
    }
    
    printf ("found handle %p for component %s \n", pAppData->pDisHandle[i],
            "OMX.TI.VPSSM3.VFDC");
    
    pAppData->disILComp[i]->handle = pAppData->pDisHandle[i];
    
    printf (" got display handle \n");
    /* getting display controller component handle, Display contrller is
       implemented as an OMX component, however it does not has any input or
       output ports. It is used only for controling display hw */
    eError =
      OMX_GetHandle (&pAppData->pctrlHandle[i], "OMX.TI.VPSSM3.CTRL.DC",
                     pAppData->disILComp[i], &pAppData->pCb);
    if (eError != OMX_ErrorNone)
    {
      ERROR ("failed to get handle\n");
    }
    
    printf ("found handle %p for component %s\n", pAppData->pctrlHandle[i],
            "OMX.TI.VPSSM3.CTRL.DC");
    
    /* omx calls are made in this function for setting the parameters for display 
       component, For clarity purpose it is written as separate function */
    
    IL_ClientSetDisplayParams (pAppData, i);
    
    /* as per openmax specs all the ports should be enabled by default but EZSDK 
       OMX component does not enable it hence we manually need to enable it */
    printf ("enable input port \n");
    
    OMX_SendCommand (pAppData->pDisHandle[i], OMX_CommandPortEnable,
                     OMX_VFDC_INPUT_PORT_START_INDEX, NULL);
    
    /* wait for port to get enabled, event handler would be notified from the
       component after enabling the port, which inturn would post this 
       semaphore */
    
    semp_pend (pAppData->disILComp[i]->port_sem);
  }

/******************************************************************************/

  /* Connect the capture to dei, This application uses 'pipe' to pass the
     buffers between different components. each compponent has a local pipe,
     which It reads for taking buffers. By connecting this functions informs
     about local pipe to other component, so that other component can pass
     buffers to this 'remote' pipe */
#if 0
  printf (" connect call for capture0-Dei0 \n ");
  IL_ClientConnectComponents (pAppData->capILComp[0],
                              OMX_VFCC_OUTPUT_PORT_START_INDEX,
                              pAppData->deiILComp[0],
                              OMX_VFPC_INPUT_PORT_START_INDEX);

  printf (" connect call for capture1-Dei1 \n ");
  IL_ClientConnectComponents (pAppData->capILComp[1],
                              OMX_VFCC_OUTPUT_PORT_START_INDEX,
                              pAppData->deiILComp[1],
                              OMX_VFPC_INPUT_PORT_START_INDEX);
#endif    
  IL_ClientConnectComponents (pAppData->deiILComp[0],
                              OMX_VFPC_OUTPUT_PORT_START_INDEX + 1,
                              pAppData->encILComp[0], OMX_VIDENC_INPUT_PORT);

  IL_ClientConnectComponents (pAppData->deiILComp[1],
                              OMX_VFPC_OUTPUT_PORT_START_INDEX + 1,
                              pAppData->encILComp[1], OMX_VIDENC_INPUT_PORT);
#if 0
  IL_ClientConnectComponents (pAppData->deiILComp[1],
                              OMX_VFPC_OUTPUT_PORT_START_INDEX,
                              pAppData->disILComp[0],
                              OMX_VFDC_INPUT_PORT_START_INDEX);
#endif
/******************************************************************************/

  /* OMX_SendCommand expecting OMX_StateIdle, after this command component will 
     wait for all buffers to be allocated as per omx buffers are created during 
     loaded to Idle transition IF ports are enabled ) */

  for( i = 0; i < g_max_decode; i++) {
    eError =
      OMX_SendCommand (pAppData->pTvpHandle[i], OMX_CommandStateSet,
                       OMX_StateIdle, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error in SendCommand()-OMX_StateIdle State set : %s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    
    semp_pend (pAppData->capILComp[i]->done_sem);
    
    eError =
      OMX_SendCommand (pAppData->pCapHandle[i], OMX_CommandStateSet,
                       OMX_StateIdle, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error in SendCommand()-OMX_StateIdle State set : %s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }

    /* Allocate I/O Buffers; componnet would allocated buffers and would return
       the buffer header containing the pointer to buffer */
    for (j = 0; j < pAppData->capILComp[i]->outPortParams->nBufferCountActual; j++)
    {
      eError = OMX_AllocateBuffer (pAppData->pCapHandle[i],
                                   &pAppData->capILComp[i]->outPortParams->
                                   pOutBuff[j],
                                   OMX_VFCC_OUTPUT_PORT_START_INDEX, pAppData,
                                   pAppData->capILComp[i]->outPortParams->
                                   nBufferSize);
    
      if (eError != OMX_ErrorNone)
      {
        printf
          ("Capture: Error in OMX_AllocateBuffer() : %s \n",
           IL_ClientErrorToStr (eError));
        goto EXIT;
      }
    }
    printf (" Capture outport buffers allocated \n ");
    
    semp_pend (pAppData->capILComp[i]->done_sem);
    
    printf (" Capture is in IDLE state \n");
  }  
  
/******************************************************************************/

  for( i = 0; i < g_max_decode; i++) {
    eError =
      OMX_SendCommand (pAppData->pDeiHandle[i], OMX_CommandStateSet,
                       OMX_StateIdle, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error in SendCommand()-OMX_StateIdle State set : %s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    
    /* Since DEI is connected to capture output, buffers would be used from
       capture output port */
#if 0
    for (j = 0; j < pAppData->deiILComp[i]->inPortParams->nBufferCountActual; j++)
    {    
      eError = OMX_UseBuffer (pAppData->pDeiHandle[i],
                              &pAppData->deiILComp[i]->inPortParams->pInBuff[j],
                              OMX_VFPC_INPUT_PORT_START_INDEX,
                              pAppData->deiILComp[i],
                              pAppData->capILComp[i]->outPortParams->nBufferSize,
                              pAppData->capILComp[i]->outPortParams->
                              pOutBuff[j]->pBuffer);
    
      if (eError != OMX_ErrorNone)
      {
        printf ("Error in OMX_UseBuffer()-input Port State set : %s \n",
                IL_ClientErrorToStr (eError));
        goto EXIT;
      }
    }
#endif
    for (j = 0; j < pAppData->deiILComp[i]->numInport; j++)
    {
       inPortParamsPtr = pAppData->deiILComp[i]->inPortParams + j;
       /* buffer alloaction for input port */
       for (m = 0; m < inPortParamsPtr->nBufferCountActual; m++)
       {
          eError = OMX_AllocateBuffer (pAppData->pDeiHandle[i],
                                      &inPortParamsPtr->pInBuff[m],
                                       OMX_VFPC_INPUT_PORT_START_INDEX + j,
                                       pAppData, inPortParamsPtr->nBufferSize);
          if (eError != OMX_ErrorNone)
          {
            printf
              ("Error in OMX_AllocateBuffer()-Input Port State set : %s \n",
               IL_ClientErrorToStr (eError));
            goto EXIT;
          }
        }
    }

    printf (" Dei input port use buffer done \n ");

    /* DEI is dual o/p port OMX component; allocate buffers on both ports */
    for (j = 0; j < pAppData->deiILComp[i]->numOutport; j++)
    {
      outPortParamsPtr = pAppData->deiILComp[i]->outPortParams + j;
      /* buffer alloaction for output port */
      for (m = 0; m < outPortParamsPtr->nBufferCountActual; m++)
      {
        eError = OMX_AllocateBuffer (pAppData->pDeiHandle[i],
                                     &outPortParamsPtr->pOutBuff[m],
                                     OMX_VFPC_OUTPUT_PORT_START_INDEX + j,
                                     pAppData, outPortParamsPtr->nBufferSize);
        if (eError != OMX_ErrorNone)
        {
          printf
            ("Error in OMX_AllocateBuffer()-Output Port State set : %s \n",
             IL_ClientErrorToStr (eError));
          goto EXIT;
        }
      }
    }
    printf (" DEI outport buffers allocated \n ");
    
    /* Wait for initialization to complete.. Wait for Idle stete of component
       after all buffers are alloacted componet would chnage to idle */
    
    semp_pend (pAppData->deiILComp[i]->done_sem);
    
    printf (" DEI is in IDLE state \n");
  }

/*******************************************************************************/

  for (i = 0; i < g_max_scalar; i++) {
    eError =
      OMX_SendCommand (pAppData->pScHandle[i], OMX_CommandStateSet,
                      OMX_StateIdle, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error in SendCommand()-OMX_StateIdle State set : %s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }

    /* scalar input port allocates the buffers */
    for (j = 0; j < pAppData->scILComp[i]->inPortParams->nBufferCountActual; j++)
    {
      eError = OMX_AllocateBuffer (pAppData->pScHandle[i],
                                   &pAppData->scILComp[i]->
                                   inPortParams->pInBuff[j],
                                   OMX_VFPC_INPUT_PORT_START_INDEX, pAppData,
                                   pAppData->scILComp[i]->
                                   inPortParams->nBufferSize);
      if (eError != OMX_ErrorNone)
      {
        printf ("Error in OMX_UseBuffer()-input Port State set : %s \n",
                IL_ClientErrorToStr (eError));
        goto EXIT;
      }
    }
    printf ("Scalar %d input port use buffer done \n", i);

    /* scalar output port allocates the buffers */
    for (j = 0; j < pAppData->scILComp[i]->outPortParams->nBufferCountActual; j++)
    {
      eError = OMX_AllocateBuffer (pAppData->pScHandle[i],
                                   &pAppData->scILComp[i]->
                                   outPortParams->pOutBuff[j],
                                   OMX_VFPC_OUTPUT_PORT_START_INDEX, pAppData,
                                   pAppData->scILComp[i]->
                                   outPortParams->nBufferSize);
      if (eError != OMX_ErrorNone)
      {
        printf ("Error in OMX_AllocateBuffer()-Output Port State set : %s \n",
                IL_ClientErrorToStr (eError));
        goto EXIT;
      }
    }

    printf ("scalar %d outport buffers allocated \n", i);

    semp_pend (pAppData->scILComp[i]->done_sem);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error %s:    WaitForState has timed out \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    printf ("scalar %d state IDLE \n", i);
 }

/******************************************************************************/
  for (i = 0; i < g_max_NF; i++) { 
   eError =
      OMX_SendCommand (pAppData->pNfHandle[i], OMX_CommandStateSet,
                       OMX_StateIdle, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error in SendCommand()-OMX_StateIdle State set : %s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }

    /* since nf is connected to scalar, buffers are supplied by scalar to
       nf, so nf does not allocate the buffers. However it is informed to 
       use the buffers created by scalar. nf component would create only
       buffer headers corresponding to these buffers */

    for (j = 0; j < pAppData->scILComp[i]->outPortParams->nBufferCountActual; j++)
    {
      //outPortParamsPtr = pAppData->deiILComp[i]->outPortParams;
      outPortParamsPtr = pAppData->scILComp[i]->outPortParams;

      eError = OMX_UseBuffer (pAppData->pNfHandle[i],
                              &pAppData->nfILComp[i]->inPortParams->pInBuff[j],
                              OMX_VFPC_INPUT_PORT_START_INDEX,
                              pAppData->nfILComp[i],
                              outPortParamsPtr->nBufferSize,
                              outPortParamsPtr->pOutBuff[j]->pBuffer);

      if (eError != OMX_ErrorNone)
      {
        printf ("Error in OMX_UseBuffer()-input Port State set : %s \n",
                IL_ClientErrorToStr (eError));
        goto EXIT;
      }
    }
    printf (" Noise Filter input port use buffer done \n ");

    /* in SDK conventionally output port allocates the buffers, nf would
       create the buffers which would be consumed by display component */
    /* buffer alloaction for output port */
    for (j = 0; j < pAppData->nfILComp[i]->outPortParams->nBufferCountActual; j++)
    {
      eError = OMX_AllocateBuffer (pAppData->pNfHandle[i],
                                   &pAppData->nfILComp[i]->
                                   outPortParams->pOutBuff[j],
                                   OMX_VFPC_OUTPUT_PORT_START_INDEX, pAppData,
                                   pAppData->nfILComp[i]->
                                   outPortParams->nBufferSize);
      if (eError != OMX_ErrorNone)
      {
        printf ("Error in OMX_AllocateBuffer()-Output Port State set : %s \n",
                IL_ClientErrorToStr (eError));
        goto EXIT;
      }
    }

    printf (" Noise Filter outport buffers allocated \n ");

    semp_pend (pAppData->nfILComp[i]->done_sem);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error %s:    WaitForState has timed out \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    printf (" Noise Filter state IDLE \n ");
  }

/*******************************************************************************/

  /* OMX_SendCommand expecting OMX_StateIdle, after this command component
     would create codec, and will wait for all buffers to be allocated */
     
  for( i = 0; i < g_max_decode; i++) {     
    eError =
      OMX_SendCommand (pAppData->pEncHandle[i], OMX_CommandStateSet,
                       OMX_StateIdle, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error in SendCommand()-OMX_StateIdle State set : %s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    /* since encoder is connected to dei, buffers are supplied by dei to
       encoder, so encoder does not allocate the buffers. However it is informed
       to use the buffers created by dei. encode component would create only
       buffer headers corresponding to these buffers */
    
    for (j = 0; j < pAppData->encILComp[i]->inPortParams->nBufferCountActual; j++)
    {
      outPortParamsPtr = pAppData->deiILComp[i]->outPortParams + 1;

      eError = OMX_UseBuffer (pAppData->pEncHandle[i],
                              &pAppData->encILComp[i]->inPortParams->pInBuff[j],
                              OMX_VIDENC_INPUT_PORT,
                              pAppData->encILComp[i],
                              outPortParamsPtr->nBufferSize,
                              outPortParamsPtr->pOutBuff[j]->pBuffer);
      if (eError != OMX_ErrorNone)
      {
        printf ("Error in encode OMX_UseBuffer(): %s \n",
                IL_ClientErrorToStr (eError));
        goto EXIT;
      }
    }
    printf (" encoder input port use buffer done \n ");
    
    /* in SDK conventionally output port allocates the buffers, encode would
       create the buffers which would be consumed by filewrite thread */
    /* buffer alloaction for output port */
    for (j = 0; j < pAppData->encILComp[i]->outPortParams->nBufferCountActual; j++)
    {
      eError = OMX_AllocateBuffer (pAppData->pEncHandle[i],
                                   &pAppData->encILComp[i]->outPortParams->
                                   pOutBuff[j], OMX_VIDENC_OUTPUT_PORT,
                                   pAppData,
                                   pAppData->encILComp[i]->outPortParams->
                                   nBufferSize);
      if (eError != OMX_ErrorNone)
      {
        printf ("Error in OMX_AllocateBuffer()-Output Port State set : %s i %d j %d\n",
                IL_ClientErrorToStr (eError), i, j);
        goto EXIT;
      }
    }
    
    printf (" encoder outport buffers allocated \n ");
    
    semp_pend (pAppData->encILComp[i]->done_sem);
    
    printf (" Encoder state IDLE \n ");
  } 
  
/******************************************************************************/

  /* control component does not allocate any data buffers, It's interface is
     though as it is omx componenet */
  for( i = 0; i < g_max_display; i++) {
    eError =
      OMX_SendCommand (pAppData->pctrlHandle[i], OMX_CommandStateSet,
                       OMX_StateIdle, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error in SendCommand()-OMX_StateIdle State set : %s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    
    semp_pend (pAppData->disILComp[i]->done_sem);
    
    printf (" ctrl-dc state IDLE \n ");
    
    eError =
      OMX_SendCommand (pAppData->pDisHandle[i], OMX_CommandStateSet,
                       OMX_StateIdle, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error in SendCommand()-OMX_StateIdle State set : %s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    /* Since display has only input port and buffers are already created by DEI
       component, only use_buffer call is used at input port. there is no output
       port in the display component */
    for (j = 0; j < pAppData->disILComp[i]->inPortParams->nBufferCountActual; j++)
    {
#if 0      
      outPortParamsPtr = pAppData->deiILComp[1]->outPortParams;
      eError = OMX_UseBuffer (pAppData->pDisHandle[i],
                              &pAppData->disILComp[i]->inPortParams->pInBuff[j],
                              OMX_VFDC_INPUT_PORT_START_INDEX,
                              pAppData->disILComp[i],
                              outPortParamsPtr->nBufferSize,
                              outPortParamsPtr->pOutBuff[j]->pBuffer);
#endif      
#if 1
      eError = OMX_AllocateBuffer (pAppData->pDisHandle[i],
                                   &pAppData->disILComp[i]->inPortParams->pInBuff[j],
                                   OMX_VFDC_INPUT_PORT_START_INDEX,
                                   pAppData,
                                   pAppData->disILComp[i]->inPortParams->
                                   nBufferSize);
#endif    
      if (eError != OMX_ErrorNone)
      {
        printf ("Error in Display OMX_UseBuffer()- %s \n",
                IL_ClientErrorToStr (eError));
        goto EXIT;
      }
    }
    printf (" display buffers allocated \n waiting for IDLE");
    semp_pend (pAppData->disILComp[i]->done_sem);
    
    printf (" display state IDLE \n ");
  }  
/******************************************************************************/

  /* change state tho execute, so that component can accept buffers from IL
     client. Please note the ordering of components is from consumer to
     producer component i.e. capture-dei-encoder/display */
  for( i = 0; i < g_max_display; i++) {
    eError =
      OMX_SendCommand (pAppData->pctrlHandle[i], OMX_CommandStateSet,
                       OMX_StateExecuting, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error in SendCommand()-OMX_StateIdle State set : %s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    
    semp_pend (pAppData->disILComp[i]->done_sem);
    
    printf (" display control state execute \n ");
    
    /* change state to execute so that buffers processing can start */
    eError =
      OMX_SendCommand (pAppData->pDisHandle[i], OMX_CommandStateSet,
                       OMX_StateExecuting, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error from SendCommand-Executing State set :%s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    
    semp_pend (pAppData->disILComp[i]->done_sem);
    
    printf (" display state execute \n ");
  }  
/******************************************************************************/

  /* change state to execute so that buffers processing can start */

  for( i = 0; i < g_max_decode; i++) {  
    eError =
      OMX_SendCommand (pAppData->pEncHandle[i], OMX_CommandStateSet,
                       OMX_StateExecuting, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error from SendCommand-Executing State set :%s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    
    semp_pend (pAppData->encILComp[i]->done_sem);
    
    printf (" encoder state execute \n ");
  }
/******************************************************************************/

  /* change state to execute so that buffers processing can start */
  for( i = 0; i < g_max_decode; i++) {  
    eError =
      OMX_SendCommand (pAppData->pDeiHandle[i], OMX_CommandStateSet,
                       OMX_StateExecuting, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error from SendCommand-Executing State set :%s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    
    semp_pend (pAppData->deiILComp[i]->done_sem);
    
    printf (" dei state execute \n ");
  } 

/******************************************************************************/

  for (i = 0; i < g_max_NF; i++) {
    /* change state to execute so that buffers processing can start */
    eError =
      OMX_SendCommand (pAppData->pNfHandle[i], OMX_CommandStateSet,
                       OMX_StateExecuting, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error from SendCommand-Executing State set :%s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    semp_pend (pAppData->nfILComp[i]->done_sem);
  }

  for (i = 0; i < g_max_scalar; i++) {
    eError =
      OMX_SendCommand (pAppData->pScHandle[i], OMX_CommandStateSet,
                      OMX_StateExecuting, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error from SendCommand-Executing State set :%s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }

    semp_pend (pAppData->scILComp[i]->done_sem);

    printf ("scalar state execute \n");
  }
  
/******************************************************************************/

  /* change state to execute so that buffers processing can start */
  for( i = 0; i < g_max_decode; i++) {  
    eError =
      OMX_SendCommand (pAppData->pCapHandle[i], OMX_CommandStateSet,
                       OMX_StateExecuting, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error from SendCommand-Executing State set :%s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    
    semp_pend (pAppData->capILComp[i]->done_sem);
    
    printf (" capture state execute \n ");
    
    eError =
      OMX_SendCommand (pAppData->pTvpHandle[i], OMX_CommandStateSet,
                       OMX_StateExecuting, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error from SendCommand-Executing State set :%s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    
    semp_pend (pAppData->capILComp[i]->done_sem);
    
    printf (" capture control ( TVP ) state execute \n ");
  }  

/******************************************************************************/

  /* Create thread for writing bitstream and passing the buffers to encoder
     component */
  for( i = 0; i < g_max_decode; i++) {     
    pthread_attr_init (&pAppData->encILComp[i]->ThreadAttr);
     
    if(i == 0) { 
      if (0 !=
          pthread_create (&pAppData->encILComp[i]->outDataStrmThrdId,
                          &pAppData->encILComp[i]->ThreadAttr,
                          (ILC_StartFcnPtr) IL_ClientOutputBitStreamWriteTask0, pAppData))
      {
        printf ("Create_Task failed !");
        goto EXIT;
      }
    } else if(i == 1) {
      if (0 !=
          pthread_create (&pAppData->encILComp[i]->outDataStrmThrdId,
                          &pAppData->encILComp[i]->ThreadAttr,
                          (ILC_StartFcnPtr) IL_ClientOutputBitStreamWriteTask1, pAppData))
      {
        printf ("Create_Task failed !");
        goto EXIT;
      }
    }

    printf (" file write thread created \n ");
    
    pthread_attr_init (&pAppData->encILComp[i]->ThreadAttr);
    
    /* These threads are created for each component to pass the buffers to each
       other. this thread function reads the buffers from pipe and feeds it to
       component or for processed buffers, passes the buffers to connected
       component */
    if (0 !=
        pthread_create (&pAppData->encILComp[i]->connDataStrmThrdId,
                        &pAppData->encILComp[i]->ThreadAttr,
                        (ILC_StartFcnPtr) IL_ClientConnInConnOutTask, pAppData->encILComp[i]))
    {
      printf ("Create_Task failed !");
      goto EXIT;
    }
    
    printf (" encode connect thread created \n ");
  }

  for (i = 0; i < g_max_scalar; i++) {
    pthread_attr_init (&pAppData->scILComp[i]->ThreadAttr);

    if (0 !=
        pthread_create (&pAppData->scILComp[i]->connDataStrmThrdId,
                        &pAppData->scILComp[i]->ThreadAttr,
                        (ILC_StartFcnPtr) IL_ClientConnInConnOutTask, pAppData->scILComp[i]))
    {
      printf ("Create_Task failed !");
      goto EXIT;
    }

    printf ("scalar %d connect thread created \n", i);
  }

  for (i = 0; i < g_max_NF; i++) {
    pthread_attr_init (&pAppData->nfILComp[i]->ThreadAttr);

    if (0 !=
        pthread_create (&pAppData->nfILComp[i]->connDataStrmThrdId,
                        &pAppData->nfILComp[i]->ThreadAttr,
                        (ILC_StartFcnPtr) IL_ClientConnInConnOutTask, pAppData->nfILComp[i]))
    {
      printf ("Create_Task failed !");
      goto EXIT;
    }

    printf (" Noise Filter connect thread created \n ");
  }

  for( i = 0; i < g_max_decode; i++){
	    pthread_attr_init (&pAppData->deiILComp[i]->ThreadAttr);

	    if (0 !=
	        pthread_create (&pAppData->deiILComp[i]->connDataStrmThrdId,
	                        &pAppData->deiILComp[i]->ThreadAttr,
	                        (ILC_StartFcnPtr) IL_ClientConnInConnOutTask, pAppData->deiILComp[i]))
	    {
	      printf ("Create_Task failed !");
	      goto EXIT;
	    }

	    printf (" dei connect thread created \n ");
  }

  for( i = 0; i < g_max_decode; i++) {

    pthread_attr_init (&pAppData->capILComp[i]->ThreadAttr);

    if (0 !=
        pthread_create (&pAppData->capILComp[i]->connDataStrmThrdId,
                        &pAppData->capILComp[i]->ThreadAttr,
                        (ILC_StartFcnPtr) IL_ClientConnInConnOutTask, pAppData->capILComp[i]))
    {
      printf ("Create_Task failed !");
      goto EXIT;
    }
    printf (" capture connect thread created \n ");
  }

#if 1
  pthread_attr_init (&pAppData->deiILComp[0]->ThreadAttr);

  if (0 !=
      pthread_create (&pAppData->deiILComp[0]->outDataStrmThrdId,
                      &pAppData->deiILComp[0]->ThreadAttr,
                      (ILC_StartFcnPtr) IL_ClientDei1OutResizerDataTask0, pAppData))
  {
    printf ("Create_Task failed !");
    goto EXIT;
  }

  pthread_attr_init (&pAppData->deiILComp[1]->ThreadAttr);

  if (0 !=
      pthread_create (&pAppData->deiILComp[1]->outDataStrmThrdId,
                      &pAppData->deiILComp[1]->ThreadAttr,
                      (ILC_StartFcnPtr) IL_ClientDei1OutResizerDataTask1, pAppData))
  {
    printf ("Create_Task failed !");
    goto EXIT;
  }

  pthread_attr_init (&pAppData->deiILComp[0]->ThreadAttr);

  if (0 !=
      pthread_create (&pAppData->deiILComp[0]->inDataStrmThrdId,
                      &pAppData->deiILComp[0]->ThreadAttr,
                      (ILC_StartFcnPtr) IL_ClientSDIConnDEITask0, pAppData))
  {
    printf ("Create_Task failed !");
    goto EXIT;
  }


  pthread_attr_init (&pAppData->deiILComp[1]->ThreadAttr);

  if (0 !=
      pthread_create (&pAppData->deiILComp[1]->inDataStrmThrdId,
                      &pAppData->deiILComp[1]->ThreadAttr,
                      (ILC_StartFcnPtr) IL_ClientSDIConnDEITask1, pAppData))
  {
    printf ("Create_Task failed !");
    goto EXIT;
  }
#endif

#if 1
#if 0
    pthread_attr_init (&pAppData->disILComp[0]->ThreadAttr);

    if (0 !=
        pthread_create (&pAppData->disILComp[0]->inDataStrmThrdId,
                        &pAppData->disILComp[0]->ThreadAttr,
                        (ILC_StartFcnPtr) IL_ClientMUXConnInConnOutTask, pAppData))
    {
      printf ("Create_Task failed !");
      goto EXIT;
    }
#endif
#endif

  for( i = 0; i < g_max_display; i++) {   
    if (0 !=
        pthread_create (&pAppData->disILComp[i]->connDataStrmThrdId,
                        &pAppData->disILComp[i]->ThreadAttr,
                        (ILC_StartFcnPtr) IL_ClientConnInConnOutTask, pAppData->disILComp[i]))
    {
      printf ("Create_Task failed !");
      goto EXIT;
    }
    printf (" display connect thread created \n ");
  }

    printf (" executing the application now!! \n");

/******************************************************************************/
  /* Waiting for this semaphore to be posted by the bitstream write thread */
  for( i = 0; i < 1; i++) {
    semp_pend(pAppData->encILComp[i]->eos);
  }  
/******************************************************************************/
  printf(" tearing down the capture-encode example\n ");

  for( i = 0; i < g_max_decode; i++) {
    pthread_join(pAppData->encILComp[i]->outDataStrmThrdId, (void **) &ret_value);
    pthread_join(pAppData->deiILComp[i]->outDataStrmThrdId, (void **) &ret_value);
    pthread_join(pAppData->deiILComp[i]->inDataStrmThrdId, (void **) &ret_value);
  }
  /* tear down sequence */

  /* change the state to idle */
  /* before changing state to idle, buffer communication to component should be 
     stoped , writing an exit message to threads */

  pipeMsg.cmd = IL_CLIENT_PIPE_CMD_EXIT;

  for( i = 0; i < g_max_decode; i++) {
    write (pAppData->deiILComp[i]->localPipe[1],
           &pipeMsg, sizeof (IL_CLIENT_PIPE_MSG));
    
    write (pAppData->capILComp[i]->localPipe[1],
           &pipeMsg, sizeof (IL_CLIENT_PIPE_MSG));
  }

  for (i = 0; i < g_max_scalar; i++) {
    write (pAppData->scILComp[i]->localPipe[1],
           &pipeMsg, sizeof (IL_CLIENT_PIPE_MSG));
  }

  for (i = 0; i < g_max_NF; i++) {
    write (pAppData->nfILComp[i]->localPipe[1],
           &pipeMsg, sizeof (IL_CLIENT_PIPE_MSG));
  } 

  for( i = 0; i < g_max_display; i++) {
    write (pAppData->disILComp[i]->localPipe[1],
           &pipeMsg, sizeof (IL_CLIENT_PIPE_MSG));
  }

  for( i = 0; i < g_max_decode; i++) {
    write (pAppData->encILComp[i]->localPipe[1],
           &pipeMsg, sizeof (IL_CLIENT_PIPE_MSG));
  }

  /* terminate the threads */
  for( i = 0; i < g_max_decode; i++) {
    pthread_join (pAppData->encILComp[i]->connDataStrmThrdId, (void **) &ret_value);
  }

  for( i = 0; i < g_max_decode; i++) {
    pthread_join (pAppData->deiILComp[i]->connDataStrmThrdId, (void **) &ret_value);

    pthread_join (pAppData->capILComp[i]->connDataStrmThrdId, (void **) &ret_value);
  }
  for (i = 0; i < g_max_scalar; i++) {
    pthread_join (pAppData->scILComp[i]->connDataStrmThrdId, (void **) &ret_value);
  }
  for (i = 0; i < g_max_NF; i++) {
    pthread_join (pAppData->nfILComp[i]->connDataStrmThrdId, (void **) &ret_value);
  }
  for( i = 0; i < g_max_display; i++) {
    pthread_join (pAppData->disILComp[i]->connDataStrmThrdId, (void **) &ret_value);
  }

  /* change state to idle so that buffers processing would stop */
  for( i = 0; i < g_max_decode; i++) {
    eError =
      OMX_SendCommand (pAppData->pCapHandle[i], OMX_CommandStateSet,
                       OMX_StateIdle, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error from SendCommand-Idle State set :%s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    
    semp_pend (pAppData->capILComp[i]->done_sem);
    printf (" capture state idle \n ");
    
    /* change state to idle so that buffers processing would stop */
    eError =
      OMX_SendCommand(pAppData->pTvpHandle[i], OMX_CommandStateSet,
                      OMX_StateIdle, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf("Error from SendCommand-Idle State set :%s \n",
             IL_ClientErrorToStr(eError));
      goto EXIT;
    }
    
    semp_pend(pAppData->capILComp[i]->done_sem);
    printf(" control tvp state idle \n ");
  }

  /* change state to idle so that buffers processing can stop */
  for( i = 0; i < g_max_decode; i++) {  
    eError =
      OMX_SendCommand (pAppData->pDeiHandle[i], OMX_CommandStateSet,
                       OMX_StateIdle, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error from SendCommand-Idle State set :%s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    
    semp_pend (pAppData->deiILComp[i]->done_sem);
    
    printf (" DEI state idle \n ");
  }

  for (i = 0; i < g_max_scalar; i++) {
    eError =
       OMX_SendCommand (pAppData->pScHandle[i], OMX_CommandStateSet,
                        OMX_StateIdle, NULL);
     if (eError != OMX_ErrorNone)
     {
       printf ("Error from SendCommand-Idle State set :%s \n",
               IL_ClientErrorToStr (eError));
       goto EXIT;
     }

     semp_pend (pAppData->scILComp[i]->done_sem);

     printf ("Scalar %d state  idle \n", i);
  }

  for (i = 0; i < g_max_NF; i++) {
    /* change state to idle so that buffers processing can stop */
    eError =
      OMX_SendCommand (pAppData->pNfHandle[i], OMX_CommandStateSet,
                       OMX_StateIdle, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error from SendCommand-Idle State set :%s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }

    semp_pend (pAppData->nfILComp[i]->done_sem);

    printf (" Noise Filter state idle \n ");
  }

  /* change state to execute so that buffers processing can stop */
  for( i = 0; i < g_max_display; i++) {    
    eError =
      OMX_SendCommand (pAppData->pDisHandle[i], OMX_CommandStateSet,
                       OMX_StateIdle, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error from SendCommand-Idle State set :%s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    
    semp_pend (pAppData->disILComp[i]->done_sem);
    
    printf (" display state idle \n ");
  }  

  /* change state to execute so that buffers processing can stop */
  for( i = 0; i < g_max_display; i++) {      
    eError =
      OMX_SendCommand(pAppData->pctrlHandle[i], OMX_CommandStateSet,
                      OMX_StateIdle, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf("Error from SendCommand-Idle State set :%s \n",
             IL_ClientErrorToStr(eError));
      goto EXIT;
    }
    
    semp_pend(pAppData->disILComp[i]->done_sem);
    
    printf(" display control state idle \n ");
  }

  /* change state to execute so that buffers processing can stop */
  for( i = 0; i < g_max_decode; i++) {  
    eError =
    OMX_SendCommand (pAppData->pEncHandle[i], OMX_CommandStateSet,
                     OMX_StateIdle, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error from SendCommand-Idle State set :%s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    
    semp_pend (pAppData->encILComp[i]->done_sem);
    
    printf (" Encoder state idle \n ");
  }

/******************************************************************************/
  for( i = 0; i < g_max_display; i++) {    
    eError =
      OMX_SendCommand (pAppData->pDisHandle[i], OMX_CommandStateSet,
                       OMX_StateLoaded, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error from SendCommand-Idle State set :%s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    /* During idle-> loaded state transition buffers need to be freed up */
    for (j = 0; j < pAppData->disILComp[i]->inPortParams->nBufferCountActual; j++)
    {
      eError =
        OMX_FreeBuffer (pAppData->pDisHandle[i],
                        OMX_VFDC_INPUT_PORT_START_INDEX,
                        pAppData->disILComp[i]->inPortParams->pInBuff[j]);
      if (eError != OMX_ErrorNone)
      {
        printf ("Error in OMX_FreeBuffer : %s \n", IL_ClientErrorToStr (eError));
        goto EXIT;
      }
    }
    
    semp_pend (pAppData->disILComp[i]->done_sem);
    
    printf (" display state loaded \n ");
    
    /* control component does not alloc/free any data buffers, It's interface
       is though as it is omx componenet */
    eError =
      OMX_SendCommand(pAppData->pctrlHandle[i], OMX_CommandStateSet,
                      OMX_StateLoaded, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf("Error in SendCommand()-OMX_StateLoaded State set : %s \n",
             IL_ClientErrorToStr(eError));
      goto EXIT;
    }
    
    semp_pend(pAppData->disILComp[i]->done_sem);
  }

/******************************************************************************/

  /* change the encoder state to loded */ 
  for( i = 0; i < g_max_decode; i++) {  
    eError =
      OMX_SendCommand (pAppData->pEncHandle[i], OMX_CommandStateSet,
                       OMX_StateLoaded, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error from SendCommand-Idle State set :%s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    /* During idle-> loaded state transition buffers need to be freed up */
    for (j = 0; j < pAppData->encILComp[i]->inPortParams->nBufferCountActual; j++)
    {
      eError =
        OMX_FreeBuffer (pAppData->pEncHandle[i], OMX_VIDENC_INPUT_PORT,
                        pAppData->encILComp[i]->inPortParams->pInBuff[j]);
      if (eError != OMX_ErrorNone)
      {
        printf ("Error in OMX_FreeBuffer : %s \n", IL_ClientErrorToStr (eError));
        goto EXIT;
      }
    }
    
    for (j = 0; j < pAppData->encILComp[i]->outPortParams->nBufferCountActual; j++)
    {
      eError =
        OMX_FreeBuffer (pAppData->pEncHandle[i], OMX_VIDENC_OUTPUT_PORT,
                        pAppData->encILComp[i]->outPortParams->pOutBuff[j]);
      if (eError != OMX_ErrorNone)
      {
        printf ("Error in OMX_FreeBuffer : %s \n", IL_ClientErrorToStr (eError));
        goto EXIT;
      }
    }
    
    semp_pend (pAppData->encILComp[i]->done_sem);
    
    printf (" encoder state loaded \n "); 
  }  
    
/******************************************************************************/
  for( i = 0; i < g_max_decode; i++) {
    eError =
      OMX_SendCommand (pAppData->pDeiHandle[i], OMX_CommandStateSet,
                       OMX_StateLoaded, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error from SendCommand-Idle State set :%s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    /* During idle-> loaded state transition buffers need to be freed up */
    for (j = 0; j < pAppData->deiILComp[i]->inPortParams->nBufferCountActual; j++)
    {
      eError =
        OMX_FreeBuffer (pAppData->pDeiHandle[i],
                        OMX_VFPC_INPUT_PORT_START_INDEX,
                        pAppData->deiILComp[i]->inPortParams->pInBuff[j]);
      if (eError != OMX_ErrorNone)
      {
        printf ("Error in OMX_FreeBuffer : %s \n", IL_ClientErrorToStr (eError));
        goto EXIT;
      }
    }
    
    /* DEI is dual o/p port OMX component; allocate buffers on both ports */
    for (j = 0; j < pAppData->deiILComp[i]->numOutport; j++)
    {
      outPortParamsPtr = pAppData->deiILComp[i]->outPortParams + j;
      /* buffer alloaction for output port */
      for (m = 0; m < outPortParamsPtr->nBufferCountActual; m++)
      {
        eError = OMX_FreeBuffer (pAppData->pDeiHandle[i],
                                 OMX_VFPC_OUTPUT_PORT_START_INDEX + j,
                                 outPortParamsPtr->pOutBuff[m]);
        if (eError != OMX_ErrorNone)
        {
          printf ("Error in OMX_AllocateBuffer()-Output Port State set : %s \n",
                  IL_ClientErrorToStr (eError));
          goto EXIT;
        } /* if (eError) */
      } /* for (i) */
    } /* for (j) */
    
    semp_pend (pAppData->deiILComp[i]->done_sem);
    
    printf (" dei state loaded \n ");
  }

/******************************************************************************/

  for (i = 0; i < g_max_scalar; i++) {
    eError =
      OMX_SendCommand (pAppData->pScHandle[i], OMX_CommandStateSet,
                       OMX_StateLoaded, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error from SendCommand-Idle State set :%s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    /* During idle-> loaded state transition buffers need to be freed up */
    for (j = 0; j < pAppData->scILComp[i]->inPortParams->nBufferCountActual; j++)
    {
      eError =
        OMX_FreeBuffer (pAppData->pScHandle[i], OMX_VFPC_INPUT_PORT_START_INDEX,
                        pAppData->scILComp[i]->inPortParams->pInBuff[j]);
      if (eError != OMX_ErrorNone)
      {
        printf ("Error in OMX_FreeBuffer : %s \n", IL_ClientErrorToStr (eError));
        goto EXIT;
      }
    }

    for (j = 0; j < pAppData->scILComp[i]->outPortParams->nBufferCountActual; j++)
    {
      eError =
        OMX_FreeBuffer (pAppData->pScHandle[i], OMX_VFPC_OUTPUT_PORT_START_INDEX,
                        pAppData->scILComp[i]->outPortParams->pOutBuff[j]);
      if (eError != OMX_ErrorNone)
      {
        printf ("Error in OMX_FreeBuffer : %s \n", IL_ClientErrorToStr (eError));
        goto EXIT;
      }
    }

    semp_pend (pAppData->scILComp[i]->done_sem);

    printf ("Scalar %d state loaded \n", i);
  }

  for (i = 0; i < g_max_NF; i++) {
    eError =
      OMX_SendCommand (pAppData->pNfHandle[i], OMX_CommandStateSet,
                       OMX_StateLoaded, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error from SendCommand-Idle State set :%s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    /* During idle-> loaded state transition buffers need to be freed up */
    for (j = 0; j < pAppData->nfILComp[i]->inPortParams->nBufferCountActual; j++)
    {
      eError =
        OMX_FreeBuffer (pAppData->pNfHandle[i], OMX_VFPC_INPUT_PORT_START_INDEX,
                        pAppData->nfILComp[i]->inPortParams->pInBuff[j]);
      if (eError != OMX_ErrorNone)
      {
        printf ("Error in OMX_FreeBuffer : %s \n", IL_ClientErrorToStr (eError));
        goto EXIT;
      }
    }

    for (j = 0; j < pAppData->nfILComp[i]->outPortParams->nBufferCountActual; j++)
    {
      eError =
        OMX_FreeBuffer (pAppData->pNfHandle[i], OMX_VFPC_OUTPUT_PORT_START_INDEX,
                        pAppData->nfILComp[i]->outPortParams->pOutBuff[j]);
      if (eError != OMX_ErrorNone)
      {
        printf ("Error in OMX_FreeBuffer : %s \n", IL_ClientErrorToStr (eError));
        goto EXIT;
      }
    }

    semp_pend (pAppData->nfILComp[i]->done_sem);

    printf (" Noise Filter state loaded \n ");
  }

/******************************************************************************/

  for( i = 0; i < g_max_decode; i++) {
    eError =
      OMX_SendCommand (pAppData->pCapHandle[i], OMX_CommandStateSet,
                       OMX_StateLoaded, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf ("Error from SendCommand-Idle State set :%s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    /* During idle-> loaded state transition buffers need to be freed up */
    for (j = 0; j < pAppData->capILComp[i]->outPortParams->nBufferCountActual; j++)
    {
      eError =
        OMX_FreeBuffer (pAppData->pCapHandle[i],
                        OMX_VFCC_OUTPUT_PORT_START_INDEX,
                        pAppData->capILComp[i]->outPortParams->pOutBuff[j]);
      if (eError != OMX_ErrorNone)
      {
        printf ("Error in OMX_FreeBuffer : %s \n", IL_ClientErrorToStr (eError));
        goto EXIT;
      }
    }
    
    semp_pend (pAppData->capILComp[i]->done_sem);
    
    printf (" capture state loaded \n ");
    
    /* ctrl tvp component does not alloc/free any data buffers, It's interface
       is though as it is omx componenet */
    eError =
      OMX_SendCommand(pAppData->pTvpHandle[i], OMX_CommandStateSet,
                      OMX_StateLoaded, NULL);
    if (eError != OMX_ErrorNone)
    {
      printf("Error in SendCommand()-OMX_StateLoaded State set : %s \n",
             IL_ClientErrorToStr(eError));
      goto EXIT;
    }
    
    semp_pend(pAppData->capILComp[i]->done_sem);
    
    printf(" ctrl-tvp state loaded \n ");
  }

/******************************************************************************/

  /* free handle for all component */

  for( i = 0; i < g_max_decode; i++) {
    eError = OMX_FreeHandle (pAppData->pCapHandle[i]);
    if ((eError != OMX_ErrorNone))
    {
      printf ("Error in Free Handle function : %s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    printf (" capture free handle \n");
    
    eError = OMX_FreeHandle(pAppData->pTvpHandle[i]);
    if ((eError != OMX_ErrorNone))
    {
      printf("Error in Free Handle function : %s \n",
             IL_ClientErrorToStr(eError));
      goto EXIT;
    }
    
    printf(" ctrl-tvp free handle \n");
  } 

  for( i = 0; i < g_max_decode; i++) {   
    eError = OMX_FreeHandle (pAppData->pEncHandle[i]);
    if ((eError != OMX_ErrorNone))
    {
      printf ("Error in Free Handle function : %s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    printf (" encoder free handle \n");
  }

  for( i = 0; i < g_max_decode; i++) {    
    eError = OMX_FreeHandle (pAppData->pDeiHandle[i]);
    if ((eError != OMX_ErrorNone))
    {
      printf ("Error in Free Handle function : %s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    
    printf (" dei free handle \n");
  }

  for (i = 0; i < g_max_scalar; i++) {
    eError = OMX_FreeHandle (pAppData->pScHandle[i]);
    if ((eError != OMX_ErrorNone))
    {
      printf ("Error in Free Handle function : %s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }

    printf ("scalar free handle \n");
  }

  for (i = 0; i < g_max_NF; i++) {
    eError = OMX_FreeHandle (pAppData->pNfHandle[i]);
    if ((eError != OMX_ErrorNone))
    {
      printf ("Error in Free Handle function : %s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    printf (" Noise Filter free handle \n");
  }

  for( i = 0; i < g_max_display; i++) {        
    eError = OMX_FreeHandle (pAppData->pDisHandle[i]);
    if ((eError != OMX_ErrorNone))
    {
      printf ("Error in Free Handle function : %s \n",
              IL_ClientErrorToStr (eError));
      goto EXIT;
    }
    
    printf (" display free handle \n");
    
    eError = OMX_FreeHandle(pAppData->pctrlHandle[i]);
    if ((eError != OMX_ErrorNone))
    {
      printf("Error in Free Handle function : %s \n",
             IL_ClientErrorToStr(eError));
      goto EXIT;
    }
    
    printf(" ctrl-dc free handle \n");
  }

    if (pAppData->fOut != NULL)
    {
      fclose(pAppData->fOut);
      pAppData->fOut = NULL;
    }

  IL_ClientDeInit (pAppData);

  printf ("IL Client deinitialized \n");

  printf (" example exit \n");

EXIT:
  return (0);
}

/* Nothing beyond this point */
