cd ../board-support/media-controller-utils_3_00_00_05/src/mm_host_util/
make 
cp mm_dm81xxbm.bin ../../../../emb_m_388/myapp/
