mv ../example-applications/linux-driver-examples-psp04.04.00.01/edma ../../example-applications/linux-driver-examples-psp04.04.00.01/edma_ti 
cp -r edma ../example-applications/linux-driver-examples-psp04.04.00.01/
cd ../
make psp-examples 
cp example-applications/linux-driver-examples-psp04.04.00.01/edma/edma_test.ko emb_m_388/myapp/
