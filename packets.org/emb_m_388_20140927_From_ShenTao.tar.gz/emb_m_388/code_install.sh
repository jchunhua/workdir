mv ../component-sources/omx_05_02_00_48/examples/ti/omx/demos/audio_encode ../component-sources/omx_05_02_00_48/examples/ti/omx/demos/audio_encode_ti
cp -r audio_encode/ ../component-sources/omx_05_02_00_48/examples/ti/omx/demos/
cp -r capture_encode_2SDI ../component-sources/omx_05_02_00_48/examples/ti/omx/demos/
cp -r capture_encode_SDI_CVBS ../component-sources/omx_05_02_00_48/examples/ti/omx/demos/

cp -r c674x-aaclcdec_01_41_00_00_elf/ ../component-sources/
cp -r c674x_aaclcenc_01_00_01_00_elf/ ../component-sources/

cp -r Makefile_top.patch ../
cp -r makefile_1.patch ../
cp -r makefile_2.patch ../
cp -r memsegdef_dm81xxbm.patch ../
cp -r memtbl_cfg.patch ../

cd ../
patch -p0  < memsegdef_dm81xxbm.patch
rm -rf memsegdef_dm81xxbm.patch

patch -p0 < memtbl_cfg.patch
rm -rf memtbl_cfg.patch

patch -p0 < Makefile_top.patch
rm -rf Makefile_top.patch

patch -p0 < makefile_1.patch
rm -rf makefile_1.patch

patch -p0 < makefile_2.patch
rm -rf makefile_2.patch
