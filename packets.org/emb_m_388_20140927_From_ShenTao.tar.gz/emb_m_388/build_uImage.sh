cp -r ./.config  linux-2.6.37-psp04.04.00.01/

cd linux-2.6.37-psp04.04.00.01/

make ARCH=arm CROSS_COMPILE=arm-none-linux-gnueabi- uImage

cp arch/arm/boot/uImage ../myapp/uImage-dm8168
