#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <malloc.h>

#define SHMKEY   18001
#define SHM_SIZE 1024
#define SEM1     19001
#define SEM2     19002

union semun
{
	int val;
	struct semid_ds *buf;
	ushort *array;
};

int  createsem(key_t key, int op);
void Wait(int sid);
void Signal(int sid);
void semcall(int sid, int op);

#include "emb8168.h"

#define COMMAND_HELLO "0001"
#define COMMAND_HELLO "0001"
#define COMMAND_SERVER "ffff"
#define COMMAND_CONFIG "0006"
#define COMMAND_MERGECTRL "0008"
#define COMMAND_GETDATA "0010"
#define COMMAND_GETDATA_ACK "0011"
#define COMMAND_EVENT_VID "0021"
#define COMMAND_EVENT_VGA "0023"
#define COMMAND_CAMHLD_BYPASS "0012"
#define COMMAND_BYP_RSP "0013"
#define COMMAND_INTERNAL_CMD "0000"
#define COMMAND_EVENT_UCI "0027"
#define COMMAND_EVENT_AUX "0025"
#define UCI_TYPE_VGA 0
#define UCI_TYPE_VID 1

#define VGA_THRESH 100

//#define FLAG_DEBUG
#ifdef FLAG_DEBUG
#define debug_printf(x...) printf(x) 
#else
#define debug_printf(x...) {}
#endif

static int char2hex(char *src, unsigned int *hex, int len)
{
	if(len > 8)
	{
		debug_printf("the length of char is too large\n");
		return -1;
	}
	int i,j;
	*hex = 0;
	for(i = 0;i < len; i++)
	{
        j = len - i - 1;
		*hex &= (~(0xf << (j*4)));
		if((src[i]>='0') && (src[i]<='9'))
		{
			*hex |= (src[i]-0x30) << (j*4);
		}
		else if((src[i]>='a') && (src[i]<='z'))
		{
			*hex |= (src[i]-0x57) << (j*4);
		}
		else if((src[i]>='A') && (src[i]<='Z'))
		{
			*hex |= (src[i]-0x37) << (j*4);
		}
	}
//	debug_printf("get char:%s h:%x\n", src, *hex);
	return 1;
}

static void add_attr_char(t_cmd *cmd, char *name, char *value)
{
	char datalen[DATA_LEN_SIZE+1];
    sprintf(cmd->cmd_p, "%01x%04x%s%s", strlen(name), strlen(value), name, value);
    //debug_printf("attr: %s\n", cmd->cmd_p);
    cmd->cmd_p += (ARG_NAME_LEN_SIZE + ARG_LEN_SIZE + strlen(name) + strlen(value));
    sprintf(datalen, "%04x", cmd->cmd_p-cmd->data);
    memcpy(cmd->data_len, datalen, DATA_LEN_SIZE);
}

static void add_attr_int(t_cmd *cmd,  char *name, unsigned int value)
{
	char c[10];
	memset(c, 0, sizeof(c));
	sprintf(c, "%x",value);
	add_attr_char(cmd, name, c);
}

static void add_attr_bin(t_cmd *cmd, char *name, char *value, unsigned int valuelen)
{
	char datalen[DATA_LEN_SIZE+1];
    sprintf(cmd->cmd_p, "%01x%04x%s", strlen(name), valuelen, name);
    //debug_printf("attr: %s\n", cmd->cmd_p);
    cmd->cmd_p += (ARG_NAME_LEN_SIZE + ARG_LEN_SIZE + strlen(name));
    memcpy(cmd->cmd_p, value, valuelen);
    cmd->cmd_p += valuelen;
    sprintf(datalen, "%04x", cmd->cmd_p-cmd->data);
    memcpy(cmd->data_len, datalen, DATA_LEN_SIZE);
}

static void fill_cmd_header(t_cmd *cmd, char *cmd_p)
{
	cmd->version = cmd->fullbuf;
	cmd->cmd = &cmd->fullbuf[2];
	cmd->data_len = &cmd->fullbuf[6];
	cmd->data = &cmd->fullbuf[10];
	cmd->cmd_p =cmd->data;
	memset(cmd, 0, sizeof(cmd));
	memcpy(cmd->version, COMMAND_VERSION, VERSION_SIZE);
	memcpy(cmd->cmd, cmd_p, CMD_SIZE);
}
