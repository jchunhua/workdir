/*
 *  Copyright (c) 2010-2011, Texas Instruments Incorporated
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  *  Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *  *  Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *  *  Neither the name of Texas Instruments Incorporated nor the names of
 *     its contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 *  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 *  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 *  OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 *  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  Contact information for paper mail:
 *  Texas Instruments
 *  Post Office Box 655303
 *  Dallas, Texas 75265
 *  Contact information:
 *  http://www-k.ext.ti.com/sc/technical-support/product-information-centers.htm?
 *  DCMP=TIHomeTracking&HQS=Other+OT+home_d_contact
 *  ============================================================================
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <xdc/std.h>
#include <memory.h>
#include <getopt.h>

/*-------------------------program files -------------------------------------*/
#include "ti/omx/interfaces/openMaxv11/OMX_Core.h"
#include "ti/omx/interfaces/openMaxv11/OMX_Component.h"
#include "OMX_TI_Common.h"
#include "OMX_Video.h"
#include "OMX_TI_Video.h"
#include "ilclient.h"
#include "ilclient_utils.h"
#include "platform_utils.h"
#include <omx_venc.h>
#include <omx_vfpc.h>
#include <omx_vfdc.h>
#include <omx_ctrl.h>
#include <omx_vfcc.h>
#include <omx_vswmosaic.h>
#include <OMX_TI_Index.h>
/*---------------------- function prototypes ---------------------------------*/
/* None */
#define HD_WIDTH       (1920)
#define HD_HEIGHT      (1080)
#define IL_CLIENT_VSWMOSAIC_PORT0 0
#define IL_CLIENT_VSWMOSAIC_PORT1 1

void usage (IL_ARGS *argsp)
{
  printf
    ("capture_encode -f <frame_rate> -m <mode>"
     "-b <bit_rate> -o <output_file> -n <num_frames> -d <0/1>\n\n"
     "-o | --output          output filename \n"
     "-m | --mode            1080p / 720p capture/On-chip HDMI display mode , 1080i capture \n"
     "-f | --framerate       encode frame rate \n"
     "-b | --bitrate         encode bit rate \n"
     "-n | --numframes       encode number of frames \n"
     "-d | --display_id      0 - for on-chip HDMI, 1 for Secondary display \n");

  printf(" example -    ./capture_encode_a8host_debug.xv5T -o sample.h264 -m 1080p -f 60 -b 1000000 -d 0 -n 1000 \n");
  printf(" for 720p, set hdmi mode before running example \n echo 720p-60 >/sys/devices/platform/vpss/display0/mode \n");
  
  exit (1);
}

/* ========================================================================== */
/**
* parse_args() : This function parses the input arguments provided to app.
*
* @param argc             : number of args 
* @param argv             : args passed by app
* @param argsp            : parsed data pointer
*
*  @return      
*
*
*/
/* ========================================================================== */

void parse_args (int argc, char *argv[], IL_ARGS *argsp)
{
  const char shortOptions[] = "o:f:b:n:m:d:";
  const struct option longOptions[] =
  {
    {"output", required_argument, NULL, ArgID_OUTPUT_FILE},
    {"framerate", required_argument, NULL, ArgID_FRAMERATE},
    {"bitrate", required_argument, NULL, ArgID_BITRATE},
    {"numframes", required_argument, NULL, ArgID_NUMFRAMES},
    {"mode", required_argument, NULL, ArgID_MODE},
    {"display_id", required_argument, NULL, ArgID_DISPLAYID},
    {0, 0, 0, 0}
  };

  int index, outfile = 0, mode = 0, nframes = 0;
  int display_id = 0;
  int argID;

  for (;;)
  {
    argID = getopt_long (argc, argv, shortOptions, longOptions, &index);

    if (argID == -1)
    {
      break;
    }

    switch (argID)
    {
      case ArgID_OUTPUT_FILE:
      case 'o':
        strncpy (argsp->output_file, optarg, MAX_FILE_NAME_SIZE);
        outfile = 1;
        break;
      case ArgID_FRAMERATE:
      case 'f':
        argsp->frame_rate = atoi (optarg);
        break;
      case ArgID_BITRATE:
      case 'b':
        argsp->bit_rate = atoi (optarg);
        break;
      case ArgID_NUMFRAMES:
      case 'n':
        argsp->num_frames = atoi(optarg);
        nframes = 1;
        break;
      case ArgID_MODE:
      case 'm':
        strncpy (argsp->mode, optarg, MAX_MODE_NAME_SIZE);
        mode = 1;
        break;
      case ArgID_DISPLAYID:
      case 'd':
        argsp->display_id = atoi (optarg);
        display_id = 1;
        break;
      default:
        usage (argsp);
        exit (1);
    }
  }

  if (optind < argc)
  {
    usage (argsp);
    exit (EXIT_FAILURE);
  }

  if (argsp->bit_rate == 0 || !outfile || argsp->frame_rate == 0 || !nframes || !mode || !display_id)
  {
    usage (argsp);
    exit (1);
  }

  printf ("output file: %s\n", argsp->output_file);
  printf ("bit_rate: %d\n", argsp->bit_rate);
  printf ("frame_rate: %d\n", argsp->frame_rate);
  printf ("num_frames: %d\n", argsp->num_frames);
  printf ("mode: %s\n", argsp->mode);
  printf ("display_id: %d\n", argsp->display_id);
}

/* ========================================================================== */
/**
* IL_ClientInit() : This function is to allocate and initialize the application
*                   data structure. It is just to maintain application control.
*
* @param pAppData          : appliaction / client data Handle 
* @param width             : stream width
* @param height            : stream height
* @param frameRate         : encode frame rate
* @param bitrate           : encoder bit rate
* @param numFrames         : encoded number of frames
* @param displayId         : display instance id
*
*  @return      
*
*
*/
/* ========================================================================== */
int g_max_decode = 2;
int g_max_display = 1;
int g_max_scalar = 0;
int g_max_NF = 0;
int capILComp_nWidth = 1920;
int capILComp_nHeight = 1080;

void IL_ClientInit (IL_Client **pAppData, char *mode, int frameRate,
                    int bitRate, int numFrames, int displayId)
{
  int i, j;
  IL_Client *pAppDataPtr;
  IL_CLIENT_INPORT_PARAMS *inPortParamsPtr;
  IL_CLIENT_OUTPORT_PARAMS *outPortParamsPtr;

  /* Allocating data structure for IL client structure / buffer management */

  pAppDataPtr = (IL_Client *) malloc (sizeof (IL_Client));
  memset (pAppDataPtr, 0x0, sizeof (IL_Client));

  /* update the user provided parameters */
  pAppDataPtr->nFrameRate = frameRate;
  pAppDataPtr->nBitRate = bitRate;
  pAppDataPtr->nEncodedFrms = numFrames;
  strncpy ((char *) pAppDataPtr->mode, mode, MAX_MODE_NAME_SIZE);  
  
  /* based on capture/display mode selected set width and height */
  if ((strcmp (mode, "1080p") == 0) || (strcmp (mode, "1080i") == 0))  {
   pAppDataPtr->nHeight = 1080;
   pAppDataPtr->nWidth =  1920; 
  }
  else  if (strcmp (mode, "720p") == 0) {
   pAppDataPtr->nHeight = 720;
   pAppDataPtr->nWidth =  1280; 
  }
  else
  {
    ERROR ("In correct Mode selected!! \n");
  }
  pAppDataPtr->displayId = displayId;

  for (i = 0; i < g_max_decode; i++) {
    /* alloacte data structure for each component used in this IL Client */
    pAppDataPtr->capILComp[i] =
      (IL_CLIENT_COMP_PRIVATE *) malloc (sizeof (IL_CLIENT_COMP_PRIVATE));
    memset (pAppDataPtr->capILComp[i], 0x0, sizeof (IL_CLIENT_COMP_PRIVATE));
    
    /* these semaphores are used for tracking the callbacks received from
       component */
    pAppDataPtr->capILComp[i]->eos = malloc (sizeof (semp_t));
    semp_init (pAppDataPtr->capILComp[i]->eos, 0);
    
    pAppDataPtr->capILComp[i]->done_sem = malloc (sizeof (semp_t));
    semp_init (pAppDataPtr->capILComp[i]->done_sem, 0);
    
    pAppDataPtr->capILComp[i]->port_sem = malloc (sizeof (semp_t));
    semp_init (pAppDataPtr->capILComp[i]->port_sem, 0);
    
    /* alloacte data structure for each component used in this IL Client */
    pAppDataPtr->deiILComp[i] =
      (IL_CLIENT_COMP_PRIVATE *) malloc (sizeof (IL_CLIENT_COMP_PRIVATE));
    memset (pAppDataPtr->deiILComp[i], 0x0, sizeof (IL_CLIENT_COMP_PRIVATE));
    
    /* these semaphores are used for tracking the callbacks received from
       component */
    pAppDataPtr->deiILComp[i]->eos = malloc (sizeof (semp_t));
    semp_init (pAppDataPtr->deiILComp[i]->eos, 0);
    
    pAppDataPtr->deiILComp[i]->done_sem = malloc (sizeof (semp_t));
    semp_init (pAppDataPtr->deiILComp[i]->done_sem, 0);
    
    pAppDataPtr->deiILComp[i]->port_sem = malloc (sizeof (semp_t));
    semp_init (pAppDataPtr->deiILComp[i]->port_sem, 0);
  }

  for (i = 0; i < g_max_scalar; i++) {
    /* alloacte data structure for each component used in this IL Cleint */
     pAppDataPtr->scILComp[i] =
       (IL_CLIENT_COMP_PRIVATE *) malloc (sizeof (IL_CLIENT_COMP_PRIVATE));
     memset (pAppDataPtr->scILComp[i], 0x0, sizeof (IL_CLIENT_COMP_PRIVATE));

     /* these semaphores are used for tracking the callbacks received from
        component */
     pAppDataPtr->scILComp[i]->eos = malloc (sizeof (semp_t));
     semp_init (pAppDataPtr->scILComp[i]->eos, 0);

     pAppDataPtr->scILComp[i]->done_sem = malloc (sizeof (semp_t));
     semp_init (pAppDataPtr->scILComp[i]->done_sem, 0);

     pAppDataPtr->scILComp[i]->port_sem = malloc (sizeof (semp_t));
     semp_init (pAppDataPtr->scILComp[i]->port_sem, 0);
  }

  for (i = 0; i < g_max_NF; i++) {
    /* alloacte data structure for each component used in this IL Cleint */
    pAppDataPtr->nfILComp[i] =
      (IL_CLIENT_COMP_PRIVATE *) malloc (sizeof (IL_CLIENT_COMP_PRIVATE));
    memset (pAppDataPtr->nfILComp[i], 0x0, sizeof (IL_CLIENT_COMP_PRIVATE));

    /* these semaphores are used for tracking the callbacks received from
       component */
    pAppDataPtr->nfILComp[i]->eos = malloc (sizeof (semp_t));
    semp_init (pAppDataPtr->nfILComp[i]->eos, 0);

    pAppDataPtr->nfILComp[i]->done_sem = malloc (sizeof (semp_t));
    semp_init (pAppDataPtr->nfILComp[i]->done_sem, 0);

    pAppDataPtr->nfILComp[i]->port_sem = malloc (sizeof (semp_t));
    semp_init (pAppDataPtr->nfILComp[i]->port_sem, 0);
  }

  for (i = 0; i < g_max_display; i++) {
    /* alloacte data structure for each component used in this IL Client */
    pAppDataPtr->encILComp[i] =
      (IL_CLIENT_COMP_PRIVATE *) malloc (sizeof (IL_CLIENT_COMP_PRIVATE));
    memset (pAppDataPtr->encILComp[i], 0x0, sizeof (IL_CLIENT_COMP_PRIVATE));
    
    /* these semaphores are used for tracking the callbacks received from
       component */
    pAppDataPtr->encILComp[i]->eos = malloc (sizeof (semp_t));
    semp_init (pAppDataPtr->encILComp[i]->eos, 0);
    
    pAppDataPtr->encILComp[i]->done_sem = malloc (sizeof (semp_t));
    semp_init (pAppDataPtr->encILComp[i]->done_sem, 0);
    
    pAppDataPtr->encILComp[i]->port_sem = malloc (sizeof (semp_t));
    semp_init (pAppDataPtr->encILComp[i]->port_sem, 0);

    /* alloacte data structure for each component used in this IL Client */
    pAppDataPtr->disILComp[i] =
      (IL_CLIENT_COMP_PRIVATE *) malloc (sizeof (IL_CLIENT_COMP_PRIVATE));
    memset (pAppDataPtr->disILComp[i], 0x0, sizeof (IL_CLIENT_COMP_PRIVATE));
    
    /* these semaphores are used for tracking the callbacks received from
       component */
    pAppDataPtr->disILComp[i]->eos = malloc (sizeof (semp_t));
    semp_init (pAppDataPtr->disILComp[i]->eos, 0);
    
    pAppDataPtr->disILComp[i]->done_sem = malloc (sizeof (semp_t));
    semp_init (pAppDataPtr->disILComp[i]->done_sem, 0);
    
    pAppDataPtr->disILComp[i]->port_sem = malloc (sizeof (semp_t));
    semp_init (pAppDataPtr->disILComp[i]->port_sem, 0);
  }
  /* number of ports for each component, which this IL client will handle, this 
     will be equal to number of ports supported by component or less */
  for (i = 0; i < g_max_decode; i++) {
    pAppDataPtr->capILComp[i]->numInport = 0;        
    /* capture does not has i/p ports */          
    pAppDataPtr->capILComp[i]->numOutport = 1;       
    pAppDataPtr->capILComp[i]->startOutportIndex = 0;
                                                  
    pAppDataPtr->deiILComp[i]->numInport = 1;        
    pAppDataPtr->deiILComp[i]->numOutport = 2;       
    /* VFPC OMX component support max 16 input / output ports, so o/p port index
       starts at 16 */                            
    pAppDataPtr->deiILComp[i]->startOutportIndex = OMX_VFPC_NUM_INPUT_PORTS;
  }

  for (i = 0; i < g_max_scalar; i++) {
    pAppDataPtr->scILComp[i]->numInport = 1;
    pAppDataPtr->scILComp[i]->numOutport = 1;
    /* VFPC OMX component support max 16 input / output ports, so o/p port index
       starts at 16 */
    pAppDataPtr->scILComp[i]->startOutportIndex = OMX_VFPC_NUM_INPUT_PORTS;
  }

  for (i = 0; i < g_max_NF; i++) {
    pAppDataPtr->nfILComp[i]->numInport = 1;
    pAppDataPtr->nfILComp[i]->numOutport = 1;

    /* VFPC OMX component support max 16 input / output ports, so o/p port index
       starts at 16 */
    pAppDataPtr->nfILComp[i]->startOutportIndex = OMX_VFPC_NUM_INPUT_PORTS;
  }

  for (i = 0; i < g_max_display; i++) {
    pAppDataPtr->encILComp[i]->numInport = 1;        
    pAppDataPtr->encILComp[i]->numOutport = 1;       
    pAppDataPtr->encILComp[i]->startOutportIndex = 1;
                                                  
    pAppDataPtr->disILComp[i]->numInport = 1;        
    /* display does not has o/p ports */          
    pAppDataPtr->disILComp[i]->numOutport = 0;                                                
    pAppDataPtr->disILComp[i]->startOutportIndex = 0;                                         
  }                                       
  /* allocate data structure for input and output port params of IL client
     component, It is for maintaining data structure in IL Client only.
     Components will have its own data structure inside omx components */
  for (i = 0; i < g_max_decode; i++) {                                         
    pAppDataPtr->capILComp[i]->outPortParams =
      malloc (sizeof (IL_CLIENT_OUTPORT_PARAMS) *
              pAppDataPtr->capILComp[i]->numOutport);                                          
    memset (pAppDataPtr->capILComp[i]->outPortParams, 0x0,
            sizeof (IL_CLIENT_OUTPORT_PARAMS) *
            pAppDataPtr->capILComp[i]->numOutport);
                                           
    pAppDataPtr->deiILComp[i]->inPortParams = 
      malloc (sizeof (IL_CLIENT_INPORT_PARAMS) *
              pAppDataPtr->deiILComp[i]->numInport);                                          
    memset (pAppDataPtr->deiILComp[i]->inPortParams, 0x0,
            sizeof (IL_CLIENT_INPORT_PARAMS));
    
    pAppDataPtr->deiILComp[i]->outPortParams =
      malloc (sizeof (IL_CLIENT_INPORT_PARAMS) *
              pAppDataPtr->deiILComp[i]->numOutport);
    memset (pAppDataPtr->deiILComp[i]->outPortParams, 0x0,
            pAppDataPtr->deiILComp[i]->numOutport *
            sizeof (IL_CLIENT_OUTPORT_PARAMS));
  }
  for (i = 0; i < g_max_scalar; i++) {
    pAppDataPtr->scILComp[i]->inPortParams =
      malloc (sizeof (IL_CLIENT_INPORT_PARAMS) *
              pAppDataPtr->scILComp[i]->numInport);
    memset (pAppDataPtr->scILComp[i]->inPortParams, 0x0,
            sizeof (IL_CLIENT_INPORT_PARAMS));

    pAppDataPtr->scILComp[i]->outPortParams =
      malloc (sizeof (IL_CLIENT_INPORT_PARAMS) *
              pAppDataPtr->scILComp[i]->numOutport);
    memset (pAppDataPtr->scILComp[i]->outPortParams, 0x0,
            sizeof (IL_CLIENT_OUTPORT_PARAMS));
  }
  for (i = 0; i < g_max_NF; i++) {
    pAppDataPtr->nfILComp[i]->inPortParams =
      malloc (sizeof (IL_CLIENT_INPORT_PARAMS) *
              pAppDataPtr->nfILComp[i]->numInport);

    memset (pAppDataPtr->nfILComp[i]->inPortParams, 0x0,
            sizeof (IL_CLIENT_INPORT_PARAMS));

    pAppDataPtr->nfILComp[i]->outPortParams =
      malloc (sizeof (IL_CLIENT_INPORT_PARAMS) *
              pAppDataPtr->nfILComp[i]->numOutport);
    memset (pAppDataPtr->nfILComp[i]->outPortParams, 0x0,
            sizeof (IL_CLIENT_OUTPORT_PARAMS));
  }
  for (i = 0; i < g_max_display; i++) {
    pAppDataPtr->encILComp[i]->inPortParams =
      malloc (sizeof (IL_CLIENT_INPORT_PARAMS) *
              pAppDataPtr->encILComp[i]->numInport);
    memset (pAppDataPtr->encILComp[i]->inPortParams, 0x0,
            sizeof (IL_CLIENT_INPORT_PARAMS));
    
    pAppDataPtr->encILComp[i]->outPortParams =
      malloc (sizeof (IL_CLIENT_INPORT_PARAMS) *
              pAppDataPtr->encILComp[i]->numOutport);
    memset (pAppDataPtr->encILComp[i]->outPortParams, 0x0,
            sizeof (IL_CLIENT_OUTPORT_PARAMS));
    
    pAppDataPtr->disILComp[i]->inPortParams =
      malloc (sizeof (IL_CLIENT_INPORT_PARAMS) *
              pAppDataPtr->disILComp[i]->numInport);
    memset (pAppDataPtr->disILComp[i]->inPortParams, 0x0,
            sizeof (IL_CLIENT_INPORT_PARAMS));
  }
  /* specify some of the parameters, that will be used for initializing OMX
     component parameters */
  for (i = 0; i < g_max_decode; i++) {
    for (j = 0; j < pAppDataPtr->capILComp[i]->numOutport; j++)
    {
      outPortParamsPtr = pAppDataPtr->capILComp[i]->outPortParams + j;
      outPortParamsPtr->nBufferCountActual =
        IL_CLIENT_CAPTURE_OUTPUT_BUFFER_COUNT;
    
      outPortParamsPtr->nBufferSize =
        (capILComp_nHeight * capILComp_nWidth * 3) >> 1;
    
      /* this pipe will not be used in this application, as capture does not read 
         / write into file */
      pipe ((int *) outPortParamsPtr->opBufPipe);
    }
    
    /* each componet will have local pipe to take buffers from other component or 
       its own consumed buffer, so that it can be passed to other connected
       components */
    pipe ((int *) pAppDataPtr->capILComp[i]->localPipe);
    
    for (j = 0; j < pAppDataPtr->deiILComp[i]->numInport; j++)
    {
      inPortParamsPtr = pAppDataPtr->deiILComp[i]->inPortParams + j;
      inPortParamsPtr->nBufferCountActual = IL_CLIENT_DEI_INPUT_BUFFER_COUNT;
      /* since input of DEI is connected to output of capture, size is same as
         capture o/p buffers yuv 420 format */
      inPortParamsPtr->nBufferSize =
        (capILComp_nHeight * capILComp_nWidth * 3) >> 1;
        //(pAppDataPtr->nHeight * pAppDataPtr->nWidth * 3) >> 1;
      /* this pipe will not be used in this application, as dei does not read /
         write into file */
      pipe ((int *) inPortParamsPtr->ipBufPipe);
    }
    for (j = 0; j < pAppDataPtr->deiILComp[i]->numOutport; j++)
    {
    
      outPortParamsPtr = pAppDataPtr->deiILComp[i]->outPortParams + j;
      outPortParamsPtr->nBufferCountActual = IL_CLIENT_DEI_OUTPUT_BUFFER_COUNT;
      /* DEI one o/p is configured for YUV 422 output, so buffer size is
         calculated as follows */
      if (!(j % 2))
      {
        outPortParamsPtr->nBufferSize =
          pAppDataPtr->nHeight * pAppDataPtr->nWidth * 2;
        outPortParamsPtr->nBufferCountActual = IL_CLIENT_DEI_OUTPUT_BUFFER_COUNT;
    
       if (1 == pAppDataPtr->displayId) {
        /* configure the buffer size to that of the display size, for custom
           display this can be used to change width and height */
        outPortParamsPtr->nBufferSize = DISPLAY_HEIGHT * DISPLAY_WIDTH * 2;      
      }
    
      }
      else
      {
        /* DEI one o/p is configured for YUV 420 output for encode, so buffer
           size is calculated as follows */
        outPortParamsPtr->nBufferSize =
          (pAppDataPtr->nHeight * pAppDataPtr->nWidth * 3) >> 1;
          //(IL_CLIENT_ENC_HEIGHT * IL_CLIENT_ENC_WIDTH * 3) >> 1;
          (pAppDataPtr->nHeight * pAppDataPtr->nWidth * 3) >> 1;
        outPortParamsPtr->nBufferCountActual = IL_CLIENT_ENC_INPUT_BUFFER_COUNT;
    
      }
    
      /* this pipe will not be used in this application, as dei does not read /
         write into file */
      pipe ((int *) outPortParamsPtr->opBufPipe);
    }
    
    /* each componet will have local pipe to take bufffes from other component or 
       its own consumed buffer, so that it can be passed to other connected
       components */
    pipe ((int *) pAppDataPtr->deiILComp[i]->localPipe);
  }

  for (i = 0; i < g_max_scalar; i++) {
    for (j = 0; j < pAppDataPtr->scILComp[i]->numInport; j++)
    {
      inPortParamsPtr = pAppDataPtr->scILComp[i]->inPortParams + j;
      inPortParamsPtr->nBufferCountActual = IL_CLIENT_SCALAR_INPUT_BUFFER_COUNT;
      /* since input of scalar is connected to output of decoder, size is same as 
         decoder o/p buffers */
      inPortParamsPtr->nBufferSize =
        (pAppDataPtr->nHeight * pAppDataPtr->nWidth * 3) >> 1;

      /* this pipe will not be used in this application, as scalar does not read
         / write into file */
      pipe ((int *) inPortParamsPtr->ipBufPipe);
    }
    for (j = 0; j < pAppDataPtr->scILComp[i]->numOutport; j++)
    {
      outPortParamsPtr = pAppDataPtr->scILComp[i]->outPortParams + j;
      outPortParamsPtr->nBufferCountActual = IL_CLIENT_SCALAR_OUTPUT_BUFFER_COUNT;
      /* scalar is configured for YUV 422 output, so buffer size is calculates as 
         follows */
      outPortParamsPtr->nBufferSize =
        (pAppDataPtr->nHeight * pAppDataPtr->nWidth * 2);

       if (1 == pAppDataPtr->displayId) {
        /* configure the buffer size to that of the display size, for custom
           display this can be used to change width and height */
        outPortParamsPtr->nBufferSize = (DISPLAY_HEIGHT/2) * (DISPLAY_WIDTH/2) * 2;
      }
 
      /* this pipe will not be used in this application, as scalar does not read
         / write into file */
      pipe ((int *) outPortParamsPtr->opBufPipe);
    }

    /* each componet will have local pipe to take bufffes from other component or 
       its own consumed buffer, so that it can be passed to other conected
       components */
    pipe ((int *) pAppDataPtr->scILComp[i]->localPipe);
  }

  for (i = 0; i < g_max_NF; i++) {
    for (j = 0; j < pAppDataPtr->nfILComp[i]->numInport; j++)
    {
      inPortParamsPtr = pAppDataPtr->nfILComp[i]->inPortParams + j;
      inPortParamsPtr->nBufferCountActual = IL_CLIENT_NF_INPUT_BUFFER_COUNT;
      /* since input of scalar is connected to output of decoder, size is same as 
         decoder o/p buffers */
      inPortParamsPtr->nBufferSize = pAppDataPtr->nHeight * pAppDataPtr->nWidth  * 2;

      /* this pipe will not be used in this application, as scalar does not read
         / write into file */
      pipe ((int *) inPortParamsPtr->ipBufPipe);
    }
    for (j = 0; j < pAppDataPtr->nfILComp[i]->numOutport; j++)
    {
      outPortParamsPtr = pAppDataPtr->nfILComp[i]->outPortParams + j;
      outPortParamsPtr->nBufferCountActual = IL_CLIENT_NF_OUTPUT_BUFFER_COUNT;
      /* scalar is configured for YUV 422 output, so buffer size is calculates as 
         follows */
      outPortParamsPtr->nBufferSize =
      (pAppDataPtr->nHeight * pAppDataPtr->nWidth * 3) >> 1;
      /* this pipe will not be used in this application, as scalar does not read
         / write into file */
      pipe ((int *) outPortParamsPtr->opBufPipe);
    }

    /* each componet will have local pipe to take bufffes from other component or 
       its own consumed buffer, so that it can be passed to other conected
       components */
    pipe ((int *) pAppDataPtr->nfILComp[i]->localPipe);
  }

  for (i = 0; i < g_max_display; i++) {
    for (j = 0; j < pAppDataPtr->encILComp[i]->numInport; j++)
    {
      inPortParamsPtr = pAppDataPtr->encILComp[i]->inPortParams + j;
      inPortParamsPtr->nBufferCountActual = IL_CLIENT_ENC_INPUT_BUFFER_COUNT;
      /* input buffers size for yuv buffers, format is YUV420 hence 3/2 */
      inPortParamsPtr->nBufferSize =
        (pAppDataPtr->nHeight * pAppDataPtr->nWidth * 3) >> 1;
        //(IL_CLIENT_ENC_HEIGHT * IL_CLIENT_ENC_WIDTH * 3) >> 1;
      /* this pipe is used for taking buffers from file read thread; in this
         example, file read is not used */
      pipe ((int *) inPortParamsPtr->ipBufPipe);
    }
    for (j = 0; j < pAppDataPtr->encILComp[i]->numOutport; j++)
    {
      outPortParamsPtr = pAppDataPtr->encILComp[i]->outPortParams + j;
      outPortParamsPtr->nBufferCountActual = IL_CLIENT_ENC_OUTPUT_BUFFER_COUNT;
      /* this size could be smaller than this value */
      outPortParamsPtr->nBufferSize =
        (pAppDataPtr->nHeight * pAppDataPtr->nWidth * 3) >> 1;
        //(IL_CLIENT_ENC_HEIGHT * IL_CLIENT_ENC_WIDTH * 3) >> 1;
    
      /* This pipe is used if output is directed to file write thread, */
      pipe ((int *) outPortParamsPtr->opBufPipe);
    }
    /* each componet will have local pipe to take bufffers from other component
       or its own consumed buffer, so that it can be passed to other connected
       components */
    pipe ((int *) pAppDataPtr->encILComp[i]->localPipe);
    
    for (j = 0; j < pAppDataPtr->disILComp[i]->numInport; j++)
    {
      inPortParamsPtr = pAppDataPtr->disILComp[i]->inPortParams + j;
      inPortParamsPtr->nBufferCountActual = IL_CLIENT_DISPLAY_INPUT_BUFFER_COUNT;
    
      inPortParamsPtr->nBufferSize =
        pAppDataPtr->nHeight * pAppDataPtr->nWidth * 2;
      
      /* configuring for custom display parameters */  
       if (1 == pAppDataPtr->displayId) {
        inPortParamsPtr->nBufferSize = DISPLAY_HEIGHT * DISPLAY_WIDTH * 2;     
       }
      
      /* this pipe will not be used in this application, as display does not read 
         / write into file */
      pipe ((int *) inPortParamsPtr->ipBufPipe);
    }
    /* each componet will have local pipe to take bufffers from other component
       or its own consumed buffer, so that it can be passed to other connected
       components */
    pipe ((int *) pAppDataPtr->disILComp[i]->localPipe);
  }
  /* populate the pointer for allocated data structure */
  *pAppData = pAppDataPtr;
}

/* ========================================================================== */
/**
* IL_ClientInit() : This function is to deinitialize the application
*                   data structure.
*
* @param pAppData          : appliaction / client data Handle 
*  @return      
*
*
*/
/* ========================================================================== */

void IL_ClientDeInit (IL_Client * pAppData)
{
  int i, j;
  IL_CLIENT_INPORT_PARAMS *inPortParamsPtr;
  IL_CLIENT_OUTPORT_PARAMS *outPortParamsPtr;

  for (j = 0; j < g_max_decode; j++) {
    close ((int) pAppData->capILComp[j]->localPipe);
    
    for (i = 0; i < pAppData->capILComp[j]->numOutport; i++)
    {
      outPortParamsPtr = pAppData->capILComp[j]->outPortParams + i;
      /* this pipe will not be used in this application, as capture does not read 
         / write into file */
      close ((int) outPortParamsPtr->opBufPipe);
    }
  }

  for (j = 0; j < g_max_scalar; j++) {
    close ((int) pAppData->scILComp[j]->localPipe);

    for (i = 0; i < pAppData->scILComp[j]->numInport; i++)
    {
      inPortParamsPtr = pAppData->scILComp[j]->inPortParams + i;
      /* this pipe is not used in this application, as scalar does not read /
         write into file */
      close ((int) inPortParamsPtr->ipBufPipe);
    }
    for (i = 0; i < pAppData->scILComp[j]->numOutport; i++)
    {
      outPortParamsPtr = pAppData->scILComp[j]->outPortParams + i;
      /* this pipe is not used in this application, as scalar does not read /
         write into file */
      close ((int) outPortParamsPtr->opBufPipe);
    }
  }
 
  for (j = 0; j < g_max_NF; j++) {
    close ((int) pAppData->nfILComp[j]->localPipe);

    for (i = 0; i < pAppData->nfILComp[j]->numInport; i++)
    {
      inPortParamsPtr = pAppData->nfILComp[j]->inPortParams + i;
      /* this pipe is not used in this application, as scalar does not read /
         write into file */
      close ((int) inPortParamsPtr->ipBufPipe);
    }
    for (i = 0; i < pAppData->nfILComp[j]->numOutport; i++)
    {
      outPortParamsPtr = pAppData->nfILComp[j]->outPortParams + i;
      /* this pipe is not used in this application, as scalar does not read /
         write into file */
      close ((int) outPortParamsPtr->opBufPipe);
    }
  }

  for (j = 0; j < g_max_display; j++) {    
    close ((int) pAppData->disILComp[j]->localPipe);
    
    for (i = 0; i < pAppData->disILComp[j]->numInport; i++)
    {
      inPortParamsPtr = pAppData->disILComp[j]->inPortParams + i;
      /* this pipe will not be used in this application, as display does not read 
         / write into file */
      close ((int) inPortParamsPtr->ipBufPipe);
    }
  } 

  for (j = 0; j < g_max_decode; j++) {   
    close ((int) pAppData->deiILComp[j]->localPipe);
    
    for (i = 0; i < pAppData->deiILComp[j]->numInport; i++)
    {
      inPortParamsPtr = pAppData->deiILComp[j]->inPortParams + i;
      /* this pipe is not used in this application, as DEI does not read / write
         into file */
      close ((int) inPortParamsPtr->ipBufPipe);
    }
    for (i = 0; i < pAppData->deiILComp[j]->numOutport; i++)
    {
      outPortParamsPtr = pAppData->deiILComp[j]->outPortParams + i;
      /* this pipe is not used in this application, as dei does not read / write
         into file */
      close ((int) outPortParamsPtr->opBufPipe);
    }
  }

  for (j = 0; j < g_max_display; j++) {
    close ((int) pAppData->encILComp[j]->localPipe);
    
    for (i = 0; i < pAppData->encILComp[j]->numInport; i++)
    {
      inPortParamsPtr = pAppData->encILComp[j]->inPortParams + i;
      /* This pipe is used if output is directed to file write thread, in this
         example, file read is not used */
      close ((int) inPortParamsPtr->ipBufPipe);
    }
    for (i = 0; i < pAppData->encILComp[j]->numOutport; i++)
    {
      outPortParamsPtr = pAppData->encILComp[j]->outPortParams + i;
      close ((int) outPortParamsPtr->opBufPipe);
    }
  }

  for (j = 0; j < g_max_decode; j++) {
    free(pAppData->capILComp[j]->outPortParams);
  }
  for (j = 0; j < g_max_scalar; j++) {
    free (pAppData->scILComp[j]->inPortParams);

    free (pAppData->scILComp[j]->outPortParams);
  }
  for (i = 0; i < g_max_NF; i++) {
    free (pAppData->nfILComp[j]->inPortParams);

    free (pAppData->nfILComp[j]->outPortParams);
  }
  for (j = 0; j < g_max_display; j++) {    
    free (pAppData->disILComp[j]->inPortParams);
  }
  for (j = 0; j < g_max_decode; j++) {  
    free (pAppData->deiILComp[j]->inPortParams);
    
    free (pAppData->deiILComp[j]->outPortParams);
  }
  for (j = 0; j < g_max_display; j++) {
    free (pAppData->encILComp[j]->inPortParams);
    
    free (pAppData->encILComp[j]->outPortParams);
  }

  for (j = 0; j < g_max_decode; j++) {
    /* these semaphores are used for tracking the callbacks received from
       component */
    semp_deinit (pAppData->deiILComp[j]->eos);
    free(pAppData->deiILComp[j]->eos);
    
    semp_deinit (pAppData->deiILComp[j]->done_sem);
    free(pAppData->deiILComp[j]->done_sem);
    
    semp_deinit (pAppData->deiILComp[j]->port_sem);
    free(pAppData->deiILComp[j]->port_sem);

    semp_deinit (pAppData->capILComp[j]->eos);
    free(pAppData->capILComp[j]->eos);
    
    semp_deinit (pAppData->capILComp[j]->done_sem);
    free(pAppData->capILComp[j]->done_sem);
    
    semp_deinit (pAppData->capILComp[j]->port_sem);
    free(pAppData->capILComp[j]->port_sem);
  }
  for (j = 0; j < g_max_scalar; j++) {
    semp_deinit (pAppData->scILComp[j]->eos);
    free (pAppData->scILComp[j]->eos);

    semp_deinit (pAppData->scILComp[j]->done_sem);
    free (pAppData->scILComp[j]->done_sem);

    semp_deinit (pAppData->scILComp[j]->port_sem);
    free (pAppData->scILComp[j]->port_sem);

    free (pAppData->scILComp[j]);
  }
  for (j = 0; j < g_max_NF; j++) {
    semp_deinit (pAppData->nfILComp[j]->eos);
    free (pAppData->nfILComp[j]->eos);

    semp_deinit (pAppData->nfILComp[j]->done_sem);
    free (pAppData->nfILComp[j]->done_sem);

    semp_deinit (pAppData->nfILComp[j]->port_sem);
    free (pAppData->nfILComp[j]->port_sem);

    free (pAppData->nfILComp[j]);
  }
  for (j = 0; j < g_max_display; j++) {    
    semp_deinit (pAppData->disILComp[j]->eos);
    free(pAppData->disILComp[j]->eos);
    
    semp_deinit (pAppData->disILComp[j]->done_sem);
    free(pAppData->disILComp[j]->done_sem);
    
    semp_deinit (pAppData->disILComp[j]->port_sem);
    free(pAppData->disILComp[j]->port_sem);
    
    semp_deinit (pAppData->encILComp[j]->eos);
    free(pAppData->encILComp[j]->eos);
    
    semp_deinit (pAppData->encILComp[j]->done_sem);
    free(pAppData->encILComp[j]->done_sem);
    
    semp_deinit (pAppData->encILComp[j]->port_sem);
    free(pAppData->encILComp[j]->port_sem);
  } 
  for (j = 0; j < g_max_display; j++) {   
    free (pAppData->encILComp[j]);
  }  
  for (j = 0; j < g_max_decode; j++) {
    free (pAppData->deiILComp[j]);

    free (pAppData->capILComp[j]);
  }
  for (j = 0; j < g_max_display; j++) {    
    free (pAppData->disILComp[j]);
  }

  free (pAppData);

}

/* ========================================================================== */
/**
* IL_ClientErrorToStr() : Function to map the OMX error enum to string
*
* @param error   : OMX Error type
*
*  @return      
*  String conversion of the OMX_ERRORTYPE
*
*/
/* ========================================================================== */

OMX_STRING IL_ClientErrorToStr (OMX_ERRORTYPE error)
{
  OMX_STRING errorString;

  /* used for printing purpose */
  switch (error)
  {
    case OMX_ErrorNone:
      errorString = "OMX_ErrorNone";
      break;
    case OMX_ErrorInsufficientResources:
      errorString = "OMX_ErrorInsufficientResources";
      break;
    case OMX_ErrorUndefined:
      errorString = "OMX_ErrorUndefined";
      break;
    case OMX_ErrorInvalidComponentName:
      errorString = "OMX_ErrorInvalidComponentName";
      break;
    case OMX_ErrorComponentNotFound:
      errorString = "OMX_ErrorComponentNotFound";
      break;
    case OMX_ErrorInvalidComponent:
      errorString = "OMX_ErrorInvalidComponent";
      break;
    case OMX_ErrorBadParameter:
      errorString = "OMX_ErrorBadParameter";
      break;
    case OMX_ErrorNotImplemented:
      errorString = "OMX_ErrorNotImplemented";
      break;
    case OMX_ErrorUnderflow:
      errorString = "OMX_ErrorUnderflow";
      break;
    case OMX_ErrorOverflow:
      errorString = "OMX_ErrorOverflow";
      break;
    case OMX_ErrorHardware:
      errorString = "OMX_ErrorHardware";
      break;
    case OMX_ErrorInvalidState:
      errorString = "OMX_ErrorInvalidState";
      break;
    case OMX_ErrorStreamCorrupt:
      errorString = "OMX_ErrorStreamCorrupt";
      break;
    case OMX_ErrorPortsNotCompatible:
      errorString = "OMX_ErrorPortsNotCompatible";
      break;
    case OMX_ErrorResourcesLost:
      errorString = "OMX_ErrorResourcesLost";
      break;
    case OMX_ErrorNoMore:
      errorString = "OMX_ErrorNoMore";
      break;
    case OMX_ErrorVersionMismatch:
      errorString = "OMX_ErrorVersionMismatch";
      break;
    case OMX_ErrorNotReady:
      errorString = "OMX_ErrorNotReady";
      break;
    case OMX_ErrorTimeout:
      errorString = "OMX_ErrorTimeout";
      break;
    default:
      errorString = "<unknown>";
  }

  return errorString;
}

/* ========================================================================== */
/**
* IL_ClientUtilGetSelfBufHeader() : This util function is to get buffer header
*                                   specific to one component, from the buffer
*                                   received from other component  .
*
* @param thisComp   : application component data structure
* @param pBuffer    : OMX buffer pointer
* @param type       : it is to identfy teh port type
* @param portIndex  : port number of the component
* @param pBufferOut : components buffer header correponding to pBuffer
*
*  @return      
*  String conversion of the OMX_ERRORTYPE
*
*/
/* ========================================================================== */

OMX_ERRORTYPE IL_ClientUtilGetSelfBufHeader (IL_CLIENT_COMP_PRIVATE *thisComp,
                                             OMX_U8 *pBuffer,
                                             ILCLIENT_PORT_TYPE type,
                                             OMX_U32 portIndex,
                                             OMX_BUFFERHEADERTYPE **pBufferOut)
{
  int i;
  IL_CLIENT_INPORT_PARAMS *inPortParamsPtr;
  IL_CLIENT_OUTPORT_PARAMS *outPortParamsPtr;
  OMX_ERRORTYPE eError = OMX_ErrorNone;

  /* Check for input port buffer header queue */
  if (type == ILCLIENT_INPUT_PORT)
  {
    inPortParamsPtr = thisComp->inPortParams + portIndex;
    for (i = 0; i < inPortParamsPtr->nBufferCountActual; i++)
    {
      if (pBuffer == inPortParamsPtr->pInBuff[i]->pBuffer)
      {
        *pBufferOut = inPortParamsPtr->pInBuff[i];
      }
    }
  }
  /* Check for output port buffer header queue */
  else
  {
    outPortParamsPtr =
      thisComp->outPortParams + portIndex - thisComp->startOutportIndex;
    for (i = 0; i < outPortParamsPtr->nBufferCountActual; i++)
    {
      if (pBuffer == outPortParamsPtr->pOutBuff[i]->pBuffer)
      {
        *pBufferOut = outPortParamsPtr->pOutBuff[i];
      }
    }
  }

  return (eError);
}

/* ========================================================================== */
/**
* IL_ClientConnectComponents() : This util function is to update the pipe
*                                information of other connected comonnet, so that
*                                buffers can be passed to connected componnet.
*
* @param handleCompPrivA   : application component data structure for producer
* @param compAPortOut      : port of producer comp
* @param handleCompPrivB   : application component data structure for consumer
* @param compBPortIn       : port number of the consumer component
*
*  @return      
*  String conversion of the OMX_ERRORTYPE
*
*/
/* ========================================================================== */

OMX_ERRORTYPE IL_ClientConnectComponents (IL_CLIENT_COMP_PRIVATE 
                                            *handleCompPrivA,
                                          unsigned int compAPortOut,
                                          IL_CLIENT_COMP_PRIVATE
                                            *handleCompPrivB,
                                          unsigned int compBPortIn)
{
  OMX_ERRORTYPE eError = OMX_ErrorNone;
  IL_CLIENT_OUTPORT_PARAMS *outPortParamPtr = NULL;
  IL_CLIENT_INPORT_PARAMS *inPortParamPtr = NULL;

  /* update the input port connect structure */
  outPortParamPtr =
    handleCompPrivA->outPortParams + compAPortOut -
    handleCompPrivA->startOutportIndex;

  inPortParamPtr = handleCompPrivB->inPortParams + compBPortIn;

  /* update input port component pipe info with connected port */
  inPortParamPtr->connInfo.remoteClient = handleCompPrivA;
  inPortParamPtr->connInfo.remotePort = compAPortOut;
  inPortParamPtr->connInfo.remotePipe[0] = handleCompPrivA->localPipe[0];
  inPortParamPtr->connInfo.remotePipe[1] = handleCompPrivA->localPipe[1];

  /* update output port component pipe info with connected port */
  outPortParamPtr->connInfo.remoteClient = handleCompPrivB;
  outPortParamPtr->connInfo.remotePort = compBPortIn;
  outPortParamPtr->connInfo.remotePipe[0] = handleCompPrivB->localPipe[0];
  outPortParamPtr->connInfo.remotePipe[1] = handleCompPrivB->localPipe[1];

  return eError;
}

/* ========================================================================== */
/**
* IL_ClientUseInitialOutputResources() :  This function gives initially all
*                                         output buffers to a component.
*                                         after consuming component would keep
*                                         in local pipe for connect thread use. 
*
* @param pAppdata   : application data structure
*
*  @return      
*  String conversion of the OMX_ERRORTYPE
*
*/
/* ========================================================================== */

OMX_ERRORTYPE IL_ClientUseInitialOutputResources (IL_CLIENT_COMP_PRIVATE 
                                                    *thisComp)
{

  OMX_ERRORTYPE err = OMX_ErrorNone;
  unsigned int i = 0, j;
  IL_CLIENT_OUTPORT_PARAMS *outPortParamPtr = NULL;
  OMX_PARAM_PORTDEFINITIONTYPE param;

  memset (&param, 0, sizeof (param));

  OMX_INIT_PARAM (&param);

  /* Give output buffers to component which is limited by no of output buffers
     available. Rest of the data will be written on the callback from output
     data write thread */
  for (j = 0; j < thisComp->numOutport; j++)
  {

    param.nPortIndex = j + thisComp->startOutportIndex;

    OMX_GetParameter (thisComp->handle, OMX_IndexParamPortDefinition, &param);

    outPortParamPtr = thisComp->outPortParams + j;

    if (OMX_TRUE == param.bEnabled)
    {
      if (outPortParamPtr->connInfo.remotePipe[0] != 0)
      {

        for (i = 0; i < thisComp->outPortParams->nBufferCountActual; i++)
        {
          /* Pass the output buffer to the component */
          err =
            OMX_FillThisBuffer (thisComp->handle, outPortParamPtr->pOutBuff[i]);

        } /* for (i) */
      } /* if (outPortParamPtr...) */
    } /* if (OMX_TRUE) */
  } /* for (j) */

  return err;
}

/* ========================================================================== */
/**
* IL_ClientEncUseInitialOutputResources() :  This function gives initially all
*                                         output buffers to a component.
*                                         after consuming component would keep
*                                         in local pipe for connect thread use. 
*
* @param pAppdata   : application data structure
*
*  @return      
*  String conversion of the OMX_ERRORTYPE
*
*/
/* ========================================================================== */

OMX_ERRORTYPE IL_ClientEncUseInitialOutputResources (IL_CLIENT_COMP_PRIVATE 
                                                       *thisComp)
{
  OMX_ERRORTYPE err = OMX_ErrorNone;
  unsigned int i = 0;

  for (i = 0; i < thisComp->outPortParams->nBufferCountActual; i++)
  {
    /* Pass the output buffer to the component */
    err = OMX_FillThisBuffer (thisComp->handle,
                              thisComp->outPortParams->pOutBuff[i]);
  }

  return err;
}

OMX_ERRORTYPE IL_ClientInitialOutputResources (IL_CLIENT_COMP_PRIVATE
                                                       *thisComp, char instId)
{
  OMX_ERRORTYPE err = OMX_ErrorNone;
  unsigned int i = 0;

  for (i = 0; i < (thisComp->outPortParams+instId)->nBufferCountActual; i++)
  {
    /* Pass the output buffer to the component */
    err = OMX_FillThisBuffer (thisComp->handle,
                              (thisComp->outPortParams+instId)->pOutBuff[i]);
  }

  return err;
}

OMX_ERRORTYPE IL_ClientInitialInputResources (IL_CLIENT_COMP_PRIVATE *thisComp)
{

  OMX_ERRORTYPE err = OMX_ErrorNone;
  unsigned int i = 0;
  int frameSize = 0;

  /* Give input buffers to component which is limited by no of input buffers
     available. Rest of the data will be read on the callback from input data
     read thread */
  for (i = 0; i < thisComp->inPortParams->nBufferCountActual; i++)
  {
    frameSize = thisComp->inPortParams->nBufferSize;
    /* Get the size of one frame at a time */
    thisComp->inPortParams->pInBuff[i]->nFilledLen = frameSize;
    thisComp->inPortParams->pInBuff[i]->nOffset = 0;
    thisComp->inPortParams->pInBuff[i]->nAllocLen = frameSize;
    thisComp->inPortParams->pInBuff[i]->nInputPortIndex = 0;

    /* Pass the input buffer to the component */

    // err = OMX_EmptyThisBuffer (thisComp->handle,
       //                        thisComp->inPortParams->pInBuff[i]);

  }
  return err;
}

/* ========================================================================== */
/**
* IL_ClientSetDeiParams() : Function to fill the port definition 
* structures and call the Set_Parameter function on to the Capture
* Component
*
* @param pAppData   : Pointer to the application data
*
*  @return      
*  OMX_ErrorNone = Successful 
*
*  Other_value = Failed (Error code is returned)
*
*/
/* ========================================================================== */

OMX_ERRORTYPE IL_ClientSetCaptureParams (IL_Client *pAppData, unsigned int instId)
{

  OMX_PARAM_VFCC_HWPORT_PROPERTIES sHwPortParam;

  OMX_PARAM_VFCC_HWPORT_ID sHwPortId;

  OMX_CONFIG_VFCC_FRAMESKIP_INFO sCapSkipFrames;

  OMX_PARAM_CTRL_VIDDECODER_INFO sVidDecParam;

  OMX_PARAM_BUFFER_MEMORYTYPE memTypeCfg;

  OMX_PARAM_PORTDEFINITIONTYPE paramPort;

  OMX_ERRORTYPE eError = OMX_ErrorNone;

  OMX_INIT_PARAM (&paramPort);

  /* set input height/width and color format */
  paramPort.nPortIndex = OMX_VFCC_OUTPUT_PORT_START_INDEX;
  OMX_GetParameter (pAppData->pCapHandle[instId], OMX_IndexParamPortDefinition,
                    &paramPort);
  paramPort.nPortIndex = OMX_VFCC_OUTPUT_PORT_START_INDEX;
  paramPort.format.video.nFrameWidth = capILComp_nWidth;
  paramPort.format.video.nFrameHeight = capILComp_nHeight;
  paramPort.format.video.nStride = capILComp_nWidth;
  paramPort.nBufferCountActual = IL_CLIENT_CAPTURE_OUTPUT_BUFFER_COUNT;
  paramPort.format.video.eCompressionFormat = OMX_VIDEO_CodingUnused;
  /* Capture output in 420 format */
  paramPort.format.video.eColorFormat = OMX_COLOR_FormatYUV420SemiPlanar;
  paramPort.nBufferSize =
    (paramPort.format.video.nStride * capILComp_nHeight * 3) >> 1;

  if (strcmp ((char *) pAppData->mode, "1080i") == 0) {
  paramPort.format.video.nStride = pAppData->nWidth << 1;
  paramPort.format.video.eColorFormat = OMX_COLOR_FormatYCbYCr;
  paramPort.nBufferSize =
    (paramPort.format.video.nStride * pAppData->nHeight) >> 1;
  }
    
  printf ("Buffer Size computed: %d\n", (int) paramPort.nBufferSize);
  printf ("set input port params (width = %d, height = %d)",
          (int) capILComp_nWidth, (int) capILComp_nHeight);
  OMX_SetParameter (pAppData->pCapHandle[instId], OMX_IndexParamPortDefinition,
                    &paramPort);

  /* Setting Memory type at output port to Raw Memory */
  OMX_INIT_PARAM (&memTypeCfg);
  memTypeCfg.nPortIndex = OMX_VFCC_OUTPUT_PORT_START_INDEX;
  memTypeCfg.eBufMemoryType = OMX_BUFFER_MEMORY_DEFAULT;
  eError =
    OMX_SetParameter (pAppData->pCapHandle[instId], OMX_TI_IndexParamBuffMemType,
                      &memTypeCfg);

  if (eError != OMX_ErrorNone)
    ERROR ("failed to set memory Type at output port\n");

  OMX_INIT_PARAM (&sHwPortId);
  /* capture on EIO card is component input at VIP1 port */
  if(instId == 0)
    sHwPortId.eHwPortId = OMX_VIDEO_CaptureHWPortVIP1_PORTA;
  else if(instId == 1)  
    sHwPortId.eHwPortId = OMX_VIDEO_CaptureHWPortVIP2_PORTA;
    
  eError = OMX_SetParameter (pAppData->pCapHandle[instId],
                             (OMX_INDEXTYPE) OMX_TI_IndexParamVFCCHwPortID,
                             (OMX_PTR) & sHwPortId);

  OMX_INIT_PARAM (&sHwPortParam);

  sHwPortParam.eCaptMode = OMX_VIDEO_CaptureModeSC_NON_MUX;
  sHwPortParam.eVifMode = OMX_VIDEO_CaptureVifMode_16BIT;
  sHwPortParam.eInColorFormat = OMX_COLOR_FormatYCbYCr;
  sHwPortParam.eScanType = OMX_VIDEO_CaptureScanTypeProgressive;
  sHwPortParam.nMaxHeight = capILComp_nHeight;
  sHwPortParam.bFieldMerged   = OMX_FALSE;
 
  if (strcmp ((char *) pAppData->mode, "1080i") == 0) {
    sHwPortParam.eScanType = OMX_VIDEO_CaptureScanTypeInterlaced;
    sHwPortParam.nMaxHeight = pAppData->nHeight >> 1;
    sHwPortParam.bFieldMerged   = OMX_FALSE;
    }
  
  sHwPortParam.nMaxWidth = capILComp_nWidth;
  sHwPortParam.nMaxChnlsPerHwPort = 1;

  eError = OMX_SetParameter (pAppData->pCapHandle[instId],
                             (OMX_INDEXTYPE)
                             OMX_TI_IndexParamVFCCHwPortProperties,
                             (OMX_PTR) & sHwPortParam);

  if (pAppData->nFrameRate == 30)
  {
    OMX_INIT_PARAM (&sCapSkipFrames);
    printf (" applying skip mask \n");

    sCapSkipFrames.frameSkipMask = 0x2AAAAAAA;
    eError = OMX_SetConfig (pAppData->pCapHandle[instId],
                            (OMX_INDEXTYPE) OMX_TI_IndexConfigVFCCFrameSkip,
                            (OMX_PTR) & sCapSkipFrames);
  }

  /* Set parameters for TVP controller */

  OMX_INIT_PARAM (&sHwPortId);
  /* capture on EIO card is component input at VIP1 port */
  if(instId == 0)
    sHwPortId.eHwPortId = OMX_VIDEO_CaptureHWPortVIP1_PORTA;
  else if(instId == 1)
    sHwPortId.eHwPortId = OMX_VIDEO_CaptureHWPortVIP2_PORTA;
  
  eError = OMX_SetParameter (pAppData->pTvpHandle[instId],
                             (OMX_INDEXTYPE) OMX_TI_IndexParamVFCCHwPortID,
                             (OMX_PTR) & sHwPortId);
  OMX_INIT_PARAM (&sHwPortParam);
  sHwPortParam.eCaptMode = OMX_VIDEO_CaptureModeSC_NON_MUX;
  sHwPortParam.eVifMode = OMX_VIDEO_CaptureVifMode_16BIT;
  sHwPortParam.eInColorFormat = OMX_COLOR_FormatYCbYCr;
  sHwPortParam.eScanType = OMX_VIDEO_CaptureScanTypeProgressive;
  sHwPortParam.bFieldMerged   = OMX_FALSE;
  sHwPortParam.nMaxHeight = capILComp_nHeight;

   if (strcmp ((char *) pAppData->mode, "1080i") == 0) {
    sHwPortParam.eScanType = OMX_VIDEO_CaptureScanTypeInterlaced;
    sHwPortParam.nMaxHeight = pAppData->nHeight >> 1;
    sHwPortParam.bFieldMerged   = OMX_FALSE;
   }
  
  sHwPortParam.nMaxWidth = capILComp_nWidth;
  sHwPortParam.nMaxChnlsPerHwPort = 1;

  eError = OMX_SetParameter (pAppData->pTvpHandle[instId],
                             (OMX_INDEXTYPE)
                             OMX_TI_IndexParamVFCCHwPortProperties,
                             (OMX_PTR) & sHwPortParam);

  OMX_INIT_PARAM (&sVidDecParam);

  /* set the mode based on capture/display device */
  if (strcmp ((char *) pAppData->mode, "1080p") == 0)
  {
    sVidDecParam.videoStandard =  OMX_VIDEO_DECODER_STD_1080P_60;
  }
  else if (strcmp ((char *) pAppData->mode, "1080i") == 0)
  {
    sVidDecParam.videoStandard =  OMX_VIDEO_DECODER_STD_1080I_60;
  }
  else if (strcmp ((char *) pAppData->mode, "720p") == 0)
  {
    sVidDecParam.videoStandard =  OMX_VIDEO_DECODER_STD_720P_60;
  }
  else
  {
    ERROR ("Incorrect Display Mode configured!!\n");
  }

  sVidDecParam.videoStandard =  OMX_VIDEO_DECODER_STD_1080P_60;  

  /* setting TVP7002 component input */
  sVidDecParam.videoDecoderId = OMX_VID_DEC_TVP7002_DRV;
  sVidDecParam.videoSystemId = OMX_VIDEO_DECODER_VIDEO_SYSTEM_AUTO_DETECT;
  eError = OMX_SetParameter (pAppData->pTvpHandle[instId],
                             (OMX_INDEXTYPE) OMX_TI_IndexParamCTRLVidDecInfo,
                             (OMX_PTR) & sVidDecParam);
  if (eError != OMX_ErrorNone)
    ERROR ("failed to set Ctrl Vid dec info \n");

  return (eError);
}

/* ========================================================================== */
/**
* IL_ClientSetEncodeParams() : Function to fill the port definition 
* structures and call the Set_Parameter function on to the Encode
* Component
*
* @param pAppData   : Pointer to the application data
*
*  @return      
*  OMX_ErrorNone = Successful 
*
*  Other_value = Failed (Error code is returned)
*
*/
/* ========================================================================== */

OMX_ERRORTYPE IL_ClientSetEncodeParams (IL_Client *pAppData, unsigned int instId)
{
  OMX_ERRORTYPE eError = OMX_ErrorUndefined;
  OMX_HANDLETYPE pHandle = NULL;
  OMX_VIDEO_PARAM_PROFILELEVELTYPE tProfileLevel;
  OMX_VIDEO_PARAM_ENCODER_PRESETTYPE tEncoderPreset;
  OMX_VIDEO_PARAM_BITRATETYPE tVidEncBitRate;
  OMX_VIDEO_PARAM_PORTFORMATTYPE tVideoParams;
  OMX_PARAM_PORTDEFINITIONTYPE tPortDef;
  OMX_VIDEO_CONFIG_DYNAMICPARAMS tDynParams;
  OMX_VIDEO_PARAM_STATICPARAMS   tStaticParam;

  pHandle = pAppData->pEncHandle[instId];

  /* Number of frames to be encoded */
  pAppData->encILComp[instId]->numFrames = pAppData->nEncodedFrms;


  OMX_INIT_PARAM (&tPortDef);
  /* Get the Number of Ports */

  tPortDef.nPortIndex = OMX_VIDENC_INPUT_PORT;
  eError = OMX_GetParameter (pHandle, OMX_IndexParamPortDefinition, &tPortDef);
  /* set the actual number of buffers required */
  tPortDef.nBufferCountActual = IL_CLIENT_ENC_INPUT_BUFFER_COUNT;
  /* set the video format settings */
  tPortDef.format.video.nFrameWidth = pAppData->nWidth; //IL_CLIENT_ENC_WIDTH;
  tPortDef.format.video.nStride = pAppData->nWidth; //IL_CLIENT_ENC_WIDTH;
  tPortDef.format.video.nFrameHeight = pAppData->nHeight; //IL_CLIENT_ENC_HEIGHT;
  tPortDef.format.video.eColorFormat = OMX_COLOR_FormatYUV420SemiPlanar;
  /* settings for OMX_IndexParamVideoPortFormat */
  tPortDef.nBufferSize = (pAppData->nWidth * pAppData->nHeight * 3) >> 1;
  //tPortDef.nBufferSize = (IL_CLIENT_ENC_WIDTH * IL_CLIENT_ENC_HEIGHT * 3) >> 1;
  eError = OMX_SetParameter (pHandle, OMX_IndexParamPortDefinition, &tPortDef);
  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set Encode OMX_IndexParamPortDefinition for input \n");
  }

  OMX_INIT_PARAM (&tPortDef);

  tPortDef.nPortIndex = OMX_VIDENC_OUTPUT_PORT;
  eError = OMX_GetParameter (pHandle, OMX_IndexParamPortDefinition, &tPortDef);
  /* settings for OMX_IndexParamPortDefinition */
  /* set the actual number of buffers required */
  tPortDef.nBufferCountActual = IL_CLIENT_ENC_OUTPUT_BUFFER_COUNT;
  tPortDef.format.video.nFrameWidth = pAppData->nWidth; //IL_CLIENT_ENC_WIDTH;
  tPortDef.format.video.nFrameHeight = pAppData->nHeight; //IL_CLIENT_ENC_HEIGHT;
  tPortDef.format.video.eCompressionFormat = OMX_VIDEO_CodingAVC;
  tPortDef.format.video.xFramerate = (pAppData->nFrameRate << 16);
  tVideoParams.xFramerate = (pAppData->nFrameRate << 16);
  tPortDef.format.video.nBitrate = pAppData->nBitRate;
  /* settings for OMX_IndexParamVideoPortFormat */

  eError = OMX_SetParameter (pHandle, OMX_IndexParamPortDefinition, &tPortDef);
  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set Encode OMX_IndexParamPortDefinition for output \n");
  }

  /* For changing bit rate following index can be used */
  OMX_INIT_PARAM (&tVidEncBitRate);

  tVidEncBitRate.nPortIndex = OMX_VIDENC_OUTPUT_PORT;
  eError = OMX_GetParameter (pHandle, OMX_IndexParamVideoBitrate,
                             &tVidEncBitRate);

  tVidEncBitRate.eControlRate = OMX_Video_ControlRateVariable;
  tVidEncBitRate.nTargetBitrate = pAppData->nBitRate;
  eError = OMX_SetParameter (pHandle, OMX_IndexParamVideoBitrate,
                             &tVidEncBitRate);

  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set Encode bitrate \n");
  }
  /* Set the profile and level for H264 */
  OMX_INIT_PARAM (&tProfileLevel);
  tProfileLevel.nPortIndex = OMX_VIDENC_OUTPUT_PORT;

  eError = OMX_GetParameter (pHandle, OMX_IndexParamVideoProfileLevelCurrent,
                             &tProfileLevel);

  /* set as baseline 4.2 level */

  tProfileLevel.eProfile = OMX_VIDEO_AVCProfileBaseline;
  tProfileLevel.eLevel = OMX_VIDEO_AVCLevel42;

  eError = OMX_SetParameter (pHandle, OMX_IndexParamVideoProfileLevelCurrent,
                             &tProfileLevel);
  if (eError != OMX_ErrorNone)
    ERROR ("failed to set encoder pfofile \n");

  /* Encoder Preset settings */
  OMX_INIT_PARAM (&tEncoderPreset);
  tEncoderPreset.nPortIndex = OMX_VIDENC_OUTPUT_PORT;
  eError = OMX_GetParameter (pHandle, OMX_TI_IndexParamVideoEncoderPreset,
                             &tEncoderPreset);

  tEncoderPreset.eEncodingModePreset = OMX_Video_Enc_Default;
  tEncoderPreset.eRateControlPreset = OMX_Video_RC_None;

  eError = OMX_SetParameter (pHandle, OMX_TI_IndexParamVideoEncoderPreset,
                             &tEncoderPreset);
  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to Encoder Preset \n");
  }

  /* before creating use set_parameters, for run-time change use set_config
     all codec supported parameters can be set using this index       */

  OMX_INIT_PARAM (&tDynParams);

  tDynParams.nPortIndex = OMX_VIDENC_OUTPUT_PORT;
  
  eError = OMX_GetParameter (pHandle, OMX_TI_IndexParamVideoDynamicParams,
                             &tDynParams);
  
  /* setting I frame interval */
  tDynParams.videoDynamicParams.h264EncDynamicParams.videnc2DynamicParams.intraFrameInterval = 180;//90;
                         
  eError = OMX_SetParameter (pHandle, OMX_TI_IndexParamVideoDynamicParams,
                             &tDynParams);
#if 1                             
  OMX_INIT_PARAM (&tStaticParam);

  tStaticParam.nPortIndex = OMX_VIDENC_OUTPUT_PORT;

  eError = OMX_GetParameter (pHandle, OMX_TI_IndexParamVideoStaticParams,
                             &tStaticParam);

  tStaticParam.videoStaticParams.h264EncStaticParams.IDRFrameInterval = 1;

  tStaticParam.videoStaticParams.h264EncStaticParams.videnc2Params.encodingPreset = XDM_USER_DEFINED;

  tStaticParam.videoStaticParams.h264EncStaticParams.numTemporalLayer = IH264_TEMPORAL_LAYERS_1;

  /* for base profile */
  tStaticParam.videoStaticParams.h264EncStaticParams.transformBlockSize = IH264_TRANSFORM_4x4;
  tStaticParam.videoStaticParams.h264EncStaticParams.entropyCodingMode = IH264_ENTROPYCODING_CAVLC;
  /* for base profile end */

  /* for the mask bits, please refer to codec user guide */
/*
  tStaticParam.videoStaticParams.h264EncStaticParams.nalUnitControlParams.naluControlPreset = IH264_NALU_CONTROL_USERDEFINED;
  tStaticParam.videoStaticParams.h264EncStaticParams.nalUnitControlParams.naluPresentMaskStartOfSequence |= 0x2180;
  tStaticParam.videoStaticParams.h264EncStaticParams.nalUnitControlParams.naluPresentMaskIDRPicture |= 0x2180;
  tStaticParam.videoStaticParams.h264EncStaticParams.nalUnitControlParams.naluPresentMaskIntraPicture |= 0x2180;
  tStaticParam.videoStaticParams.h264EncStaticParams.nalUnitControlParams.naluPresentMaskNonIntraPicture |= 0x2180;
  tStaticParam.videoStaticParams.h264EncStaticParams.nalUnitControlParams.naluPresentMaskEndOfSequence |= 0x2180;
*/
  tStaticParam.videoStaticParams.h264EncStaticParams.vuiCodingParams.vuiCodingPreset = IH264_VUICODING_USERDEFINED;
  tStaticParam.videoStaticParams.h264EncStaticParams.vuiCodingParams.aspectRatioInfoPresentFlag = 0;
  tStaticParam.videoStaticParams.h264EncStaticParams.vuiCodingParams.aspectRatioIdc = 0;
  tStaticParam.videoStaticParams.h264EncStaticParams.vuiCodingParams.videoSignalTypePresentFlag = 0;
  tStaticParam.videoStaticParams.h264EncStaticParams.vuiCodingParams.videoFormat = IH264ENC_VIDEOFORMAT_NTSC;
  tStaticParam.videoStaticParams.h264EncStaticParams.vuiCodingParams.videoFullRangeFlag = 0;
  tStaticParam.videoStaticParams.h264EncStaticParams.vuiCodingParams.timingInfoPresentFlag = 0;
  tStaticParam.videoStaticParams.h264EncStaticParams.vuiCodingParams.hrdParamsPresentFlag = 1;
  tStaticParam.videoStaticParams.h264EncStaticParams.vuiCodingParams.numUnitsInTicks = 1000;

  eError = OMX_SetParameter (pHandle, OMX_TI_IndexParamVideoStaticParams,
                             &tStaticParam);
  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to Encoder OMX_SetParameter StaticParams \n");
  }
#endif 
  return eError;
}

/* ========================================================================== */
/**
* IL_ClientSetDeiParams() : Function to fill the port definition 
* structures and call the Set_Parameter function on to the DEI
* Component
*
* @param pAppData   : Pointer to the application data
*
*  @return      
*  OMX_ErrorNone = Successful 
*
*  Other_value = Failed (Error code is returned)
*
*/
/* ========================================================================== */

OMX_ERRORTYPE IL_ClientSetDeiParams (IL_Client *pAppData, unsigned int instId)
{
  OMX_ERRORTYPE eError = OMX_ErrorNone;
  OMX_PARAM_BUFFER_MEMORYTYPE memTypeCfg;
  OMX_PARAM_PORTDEFINITIONTYPE paramPort;
  OMX_PARAM_VFPC_NUMCHANNELPERHANDLE sNumChPerHandle;
  OMX_CONFIG_ALG_ENABLE algEnable;
  OMX_CONFIG_VIDCHANNEL_RESOLUTION chResolution;

  OMX_CONFIG_SUBSAMPLING_FACTOR sSubSamplinginfo = {0};
  
  OMX_INIT_PARAM(&sSubSamplinginfo);

  sSubSamplinginfo.nSubSamplingFactor = 1;
  eError = OMX_SetConfig ( pAppData->pDeiHandle[instId], ( OMX_INDEXTYPE )
                           ( OMX_TI_IndexConfigSubSamplingFactor ),
                             &sSubSamplinginfo );

  OMX_INIT_PARAM (&memTypeCfg);
  memTypeCfg.nPortIndex = OMX_VFPC_INPUT_PORT_START_INDEX;
  memTypeCfg.eBufMemoryType = OMX_BUFFER_MEMORY_DEFAULT;
  eError = OMX_SetParameter (pAppData->pDeiHandle[instId], OMX_TI_IndexParamBuffMemType,
                             &memTypeCfg);

  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set memory Type at input port\n");
  }

  /* Setting Memory type at output port to Raw Memory */
  OMX_INIT_PARAM (&memTypeCfg);
  memTypeCfg.nPortIndex = OMX_VFPC_OUTPUT_PORT_START_INDEX;
  memTypeCfg.eBufMemoryType = OMX_BUFFER_MEMORY_DEFAULT;
  eError = OMX_SetParameter (pAppData->pDeiHandle[instId], OMX_TI_IndexParamBuffMemType,
                             &memTypeCfg);

  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set memory Type at output port\n");
  }

  OMX_INIT_PARAM (&memTypeCfg);
  memTypeCfg.nPortIndex = OMX_VFPC_OUTPUT_PORT_START_INDEX + 1;
  memTypeCfg.eBufMemoryType = OMX_BUFFER_MEMORY_DEFAULT;
  eError = OMX_SetParameter (pAppData->pDeiHandle[instId], OMX_TI_IndexParamBuffMemType,
                             &memTypeCfg);

  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set memory Type at output port\n");
  }

  /* set input height/width and color format */
  OMX_INIT_PARAM (&paramPort);
  paramPort.nPortIndex = OMX_VFPC_INPUT_PORT_START_INDEX;

  OMX_GetParameter (pAppData->pDeiHandle[instId], OMX_IndexParamPortDefinition,
                    &paramPort);
  paramPort.nPortIndex = OMX_VFPC_INPUT_PORT_START_INDEX;
  paramPort.format.video.nFrameWidth = pAppData->nWidth;
  paramPort.format.video.nFrameHeight = pAppData->nHeight;

  paramPort.format.video.nStride = pAppData->nWidth;
  paramPort.format.video.eCompressionFormat = OMX_VIDEO_CodingUnused;
  paramPort.format.video.eColorFormat = OMX_COLOR_FormatYUV420SemiPlanar;
  paramPort.nBufferSize =
    (paramPort.format.video.nStride * pAppData->nHeight * 3) >> 1;

  if (strcmp ((char *) pAppData->mode, "1080i") == 0) {
    paramPort.format.video.nFrameHeight = pAppData->nHeight >> 1;
    paramPort.format.video.nStride = pAppData->nWidth << 1;
    paramPort.format.video.eColorFormat = OMX_COLOR_FormatYCbYCr;
    paramPort.nBufferSize =
      (paramPort.format.video.nStride * pAppData->nHeight) >> 1;
    
  }  
    
  paramPort.nBufferAlignment = 0;
  paramPort.bBuffersContiguous = 0;
  paramPort.nBufferCountActual = IL_CLIENT_DEI_INPUT_BUFFER_COUNT;
  printf ("set input port params (width = %d, height = %d) \n",
          (int) pAppData->nWidth, (int) pAppData->nHeight);
  OMX_SetParameter (pAppData->pDeiHandle[instId], OMX_IndexParamPortDefinition,
                    &paramPort);

  /* set output height/width and color format */
  OMX_INIT_PARAM (&paramPort);
  paramPort.nPortIndex = OMX_VFPC_OUTPUT_PORT_START_INDEX;
  OMX_GetParameter (pAppData->pDeiHandle[instId], OMX_IndexParamPortDefinition,
                    &paramPort);

  paramPort.nPortIndex = OMX_VFPC_OUTPUT_PORT_START_INDEX;
  paramPort.format.video.nFrameWidth = pAppData->nWidth;
  paramPort.format.video.nFrameHeight = pAppData->nHeight;
  paramPort.format.video.eCompressionFormat = OMX_VIDEO_CodingUnused;
  paramPort.format.video.eColorFormat = OMX_COLOR_FormatYCbYCr;
  paramPort.nBufferAlignment = 0;
  paramPort.nBufferCountActual = IL_CLIENT_DEI_OUTPUT_BUFFER_COUNT;
  /* This port is connected to display and provides 422 o/p */
  paramPort.format.video.nStride = pAppData->nWidth * 2;
  paramPort.nBufferSize = paramPort.format.video.nStride *
                          paramPort.format.video.nFrameHeight;

  if (1 == pAppData->displayId) {
    /*For the case of On-chip HDMI as display device*/
    paramPort.format.video.nFrameWidth = DISPLAY_WIDTH;
    paramPort.format.video.nFrameHeight = DISPLAY_HEIGHT;
    paramPort.format.video.nStride = DISPLAY_HEIGHT * 2;
  }

  if (0 == instId) {
    paramPort.format.video.nFrameWidth = RESIZER_WIDTH;//pAppData->nWidth;
    paramPort.format.video.nFrameHeight = RESIZER_HEIGHT;//pAppData->nHeight;
    paramPort.format.video.nStride = RESIZER_WIDTH * 2; //pAppData->nWidth * 2;
  } 
 
  paramPort.nBufferSize =
    paramPort.format.video.nStride * paramPort.format.video.nFrameHeight;
                          
  printf ("set output port params (width = %d, height = %d)",
          (int) pAppData->nWidth, (int) pAppData->nHeight);

  OMX_SetParameter (pAppData->pDeiHandle[instId], OMX_IndexParamPortDefinition,
                    &paramPort);

  OMX_INIT_PARAM (&paramPort);
  paramPort.nPortIndex = OMX_VFPC_OUTPUT_PORT_START_INDEX + 1;
  OMX_GetParameter (pAppData->pDeiHandle[instId], OMX_IndexParamPortDefinition,
                    &paramPort);

  paramPort.nPortIndex = OMX_VFPC_OUTPUT_PORT_START_INDEX + 1;
  paramPort.format.video.nFrameWidth = pAppData->nWidth; //IL_CLIENT_ENC_WIDTH;
  paramPort.format.video.nFrameHeight = pAppData->nHeight; //IL_CLIENT_ENC_HEIGHT;
  paramPort.format.video.eCompressionFormat = OMX_VIDEO_CodingUnused;
  paramPort.nBufferAlignment = 0;
  paramPort.nBufferCountActual = IL_CLIENT_ENC_INPUT_BUFFER_COUNT;
  paramPort.format.video.eColorFormat = OMX_COLOR_FormatYUV420SemiPlanar;
  paramPort.format.video.nStride = pAppData->nWidth; //IL_CLIENT_ENC_WIDTH;

  /* This port is connected to encoder and provides 420 o/p */
  paramPort.nBufferSize =
    (paramPort.format.video.nStride * paramPort.format.video.nFrameHeight *
     3) >> 1;

  printf ("set output port params (width = %d, height = %d)",
          (int) IL_CLIENT_ENC_WIDTH, (int) IL_CLIENT_ENC_HEIGHT);

  OMX_SetParameter (pAppData->pDeiHandle[instId], OMX_IndexParamPortDefinition,
                    &paramPort);

  /* set number of channles */
  printf ("set number of channels");

  OMX_INIT_PARAM (&sNumChPerHandle);
  sNumChPerHandle.nNumChannelsPerHandle = 1;
  eError = OMX_SetParameter (pAppData->pDeiHandle[instId],
                             (OMX_INDEXTYPE)
                               OMX_TI_IndexParamVFPCNumChPerHandle,
                             &sNumChPerHandle);
  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set num of channels\n");
  }

  /* set VFPC input and output resolution information */
  printf ("set input resolution");

  OMX_INIT_PARAM (&chResolution);
  chResolution.Frm0Width = pAppData->nWidth;
  chResolution.Frm0Height = pAppData->nHeight;

  chResolution.Frm0Pitch = pAppData->nWidth;;
  chResolution.Frm1Width = 0;
  chResolution.Frm1Height = 0;
  chResolution.Frm1Pitch = 0;
  chResolution.FrmStartX = 0;
  chResolution.FrmStartY = 0;
  chResolution.FrmCropWidth = pAppData->nWidth;
  chResolution.FrmCropHeight = pAppData->nHeight;

  if (strcmp ((char *) pAppData->mode, "1080i") == 0) {
   chResolution.Frm0Height = pAppData->nHeight >> 1;
   chResolution.FrmCropHeight = pAppData->nHeight >> 1;
   chResolution.Frm0Pitch = pAppData->nWidth << 1;
   }
  
  chResolution.eDir = OMX_DirInput;
  chResolution.nChId = 0;

  eError = OMX_SetConfig (pAppData->pDeiHandle[instId],
                          (OMX_INDEXTYPE) OMX_TI_IndexConfigVidChResolution,
                          &chResolution);
  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set input channel resolution\n");
  }

  printf ("set output resolution");
  OMX_INIT_PARAM (&chResolution);
  /* first output to display */
  chResolution.Frm0Width = pAppData->nWidth;
  chResolution.Frm0Height = pAppData->nHeight;
  chResolution.Frm0Pitch = pAppData->nWidth * 2;

   if (1 == pAppData->displayId) {
    /* on secondary display, it is scaled to display size */  
    chResolution.Frm0Width = DISPLAY_WIDTH;
    chResolution.Frm0Height = DISPLAY_HEIGHT;
    chResolution.Frm0Pitch = DISPLAY_WIDTH * 2;  
  }

   if (0 == instId) {
    /* on secondary display, it is scaled to display size */  
    chResolution.Frm0Width = RESIZER_WIDTH;
    chResolution.Frm0Height = RESIZER_HEIGHT;
    chResolution.Frm0Pitch = RESIZER_WIDTH * 2;  
  }  
  
  /* second output to encode */
  chResolution.Frm1Width  = pAppData->nWidth; //IL_CLIENT_ENC_WIDTH;
  chResolution.Frm1Height = pAppData->nHeight; //IL_CLIENT_ENC_HEIGHT;
  chResolution.Frm1Pitch  = pAppData->nWidth; //IL_CLIENT_ENC_WIDTH;
  chResolution.FrmStartX  = 0;
  chResolution.FrmStartY  = 0;
  chResolution.FrmCropWidth = 0;
  chResolution.FrmCropHeight = 0;
  chResolution.eDir = OMX_DirOutput;
  chResolution.nChId = 0;

  eError = OMX_SetConfig (pAppData->pDeiHandle[instId],
                          (OMX_INDEXTYPE) OMX_TI_IndexConfigVidChResolution,
                          &chResolution);
  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set output channel resolution\n");
  }

  /* disable algo bypass mode */
  OMX_INIT_PARAM (&algEnable);
  algEnable.nPortIndex = 0;
  algEnable.nChId = 0;
  /* capture providing progressive input, alg is bypassed */
  algEnable.bAlgBypass = 1;
  if (strcmp ((char *) pAppData->mode, "1080i") == 0) {
   algEnable.bAlgBypass = 0;
  }

  eError = OMX_SetConfig (pAppData->pDeiHandle[instId],
                          (OMX_INDEXTYPE) OMX_TI_IndexConfigAlgEnable,
                          &algEnable);
  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to disable algo by pass mode\n");
  }

  return (eError);
}


int dei0_input_width = 1920;
int dei0_input_height = 1080;

OMX_ERRORTYPE IL_ClientSetDei0Params (IL_Client *pAppData, unsigned int instId)
{
  OMX_ERRORTYPE eError = OMX_ErrorNone;
  OMX_PARAM_PORTDEFINITIONTYPE paramPort;
  OMX_CONFIG_ALG_ENABLE algEnable;
  OMX_CONFIG_VIDCHANNEL_RESOLUTION chResolution;

  instId = 0;
  /* set input height/width and color format */
  OMX_INIT_PARAM (&paramPort);
  paramPort.nPortIndex = OMX_VFPC_INPUT_PORT_START_INDEX;

  OMX_GetParameter (pAppData->pDeiHandle[instId], OMX_IndexParamPortDefinition,
                    &paramPort);
  paramPort.nPortIndex = OMX_VFPC_INPUT_PORT_START_INDEX;
  paramPort.format.video.nFrameWidth = dei0_input_width;
  paramPort.format.video.nFrameHeight = dei0_input_height;
  paramPort.format.video.nStride = dei0_input_width;
  paramPort.format.video.eCompressionFormat = OMX_VIDEO_CodingUnused;
  paramPort.format.video.eColorFormat = OMX_COLOR_FormatYUV420SemiPlanar;
  paramPort.nBufferSize =
    (paramPort.format.video.nStride * dei0_input_height * 3) >> 1;

  paramPort.nBufferAlignment = 0;
  paramPort.bBuffersContiguous = 0;
  paramPort.nBufferCountActual = IL_CLIENT_DEI_INPUT_BUFFER_COUNT;
  printf ("set input port params (width = %d, height = %d) \n",
         paramPort.format.video.nFrameWidth, paramPort.format.video.nFrameHeight);
  OMX_SetParameter (pAppData->pDeiHandle[instId], OMX_IndexParamPortDefinition,
                    &paramPort);

  /* set output height/width and color format */
  OMX_INIT_PARAM (&paramPort);
  paramPort.nPortIndex = OMX_VFPC_OUTPUT_PORT_START_INDEX;
  OMX_GetParameter (pAppData->pDeiHandle[instId], OMX_IndexParamPortDefinition,
                    &paramPort);

  paramPort.nPortIndex = OMX_VFPC_OUTPUT_PORT_START_INDEX;
  paramPort.format.video.nFrameWidth = pAppData->nWidth;
  paramPort.format.video.nFrameHeight = pAppData->nHeight;
  paramPort.format.video.eCompressionFormat = OMX_VIDEO_CodingUnused;
  paramPort.format.video.eColorFormat = OMX_COLOR_FormatYCbYCr;
  paramPort.nBufferAlignment = 0;
  paramPort.nBufferCountActual = IL_CLIENT_DEI_OUTPUT_BUFFER_COUNT;
  /* This port is connected to display and provides 422 o/p */
  paramPort.format.video.nStride = pAppData->nWidth * 2;
  paramPort.nBufferSize = paramPort.format.video.nStride *
                          paramPort.format.video.nFrameHeight;

  paramPort.nBufferSize =
    paramPort.format.video.nStride * paramPort.format.video.nFrameHeight;

  printf ("set output port params (width = %d, height = %d)",
          (int) pAppData->nWidth, (int) pAppData->nHeight);

  OMX_SetParameter (pAppData->pDeiHandle[instId], OMX_IndexParamPortDefinition,
                    &paramPort);

  OMX_INIT_PARAM (&paramPort);
  paramPort.nPortIndex = OMX_VFPC_OUTPUT_PORT_START_INDEX + 1;
  OMX_GetParameter (pAppData->pDeiHandle[instId], OMX_IndexParamPortDefinition,
                    &paramPort);

  paramPort.nPortIndex = OMX_VFPC_OUTPUT_PORT_START_INDEX + 1;
  paramPort.format.video.nFrameWidth = pAppData->nWidth; 
  paramPort.format.video.nFrameHeight = pAppData->nHeight; 
  paramPort.format.video.eCompressionFormat = OMX_VIDEO_CodingUnused;
  paramPort.nBufferAlignment = 0;
  paramPort.nBufferCountActual = IL_CLIENT_ENC_INPUT_BUFFER_COUNT;
  paramPort.format.video.eColorFormat = OMX_COLOR_FormatYUV420SemiPlanar;
  paramPort.format.video.nStride = pAppData->nWidth; 

  /* This port is connected to encoder and provides 420 o/p */
  paramPort.nBufferSize =
    (paramPort.format.video.nStride * paramPort.format.video.nFrameHeight *
     3) >> 1;

  printf ("set output port params (width = %d, height = %d)",
          (int) IL_CLIENT_ENC_WIDTH, (int) IL_CLIENT_ENC_HEIGHT);

  OMX_SetParameter (pAppData->pDeiHandle[instId], OMX_IndexParamPortDefinition,
                    &paramPort);

  /* set VFPC input and output resolution information */
  printf ("set input resolution");

  OMX_INIT_PARAM (&chResolution);
  chResolution.Frm0Width = dei0_input_width;
  chResolution.Frm0Height = dei0_input_height;
  chResolution.Frm0Pitch = dei0_input_width;
  chResolution.Frm1Width = 0;
  chResolution.Frm1Height = 0;
  chResolution.Frm1Pitch = 0;
  chResolution.FrmStartX = 0;
  chResolution.FrmStartY = 0;
  chResolution.FrmCropWidth = dei0_input_width;
  chResolution.FrmCropHeight = dei0_input_height;
  chResolution.eDir = OMX_DirInput;
  chResolution.nChId = 0;

  eError = OMX_SetConfig (pAppData->pDeiHandle[instId],
                          (OMX_INDEXTYPE) OMX_TI_IndexConfigVidChResolution,
                          &chResolution);
  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set input channel resolution\n");
  }

  printf ("set output resolution");
  OMX_INIT_PARAM (&chResolution);
  /* first output to display */
  chResolution.Frm0Width = pAppData->nWidth;
  chResolution.Frm0Height = pAppData->nHeight;
  chResolution.Frm0Pitch = pAppData->nWidth * 2;

  /* second output to encode */
  chResolution.Frm1Width  = pAppData->nWidth; 
  chResolution.Frm1Height = pAppData->nHeight;
  chResolution.Frm1Pitch  = pAppData->nWidth;
  chResolution.FrmStartX  = 0;
  chResolution.FrmStartY  = 0;
  chResolution.FrmCropWidth = 0;
  chResolution.FrmCropHeight = 0;
  chResolution.eDir = OMX_DirOutput;
  chResolution.nChId = 0;

  eError = OMX_SetConfig (pAppData->pDeiHandle[instId],
                          (OMX_INDEXTYPE) OMX_TI_IndexConfigVidChResolution,
                          &chResolution);
  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set output channel resolution\n");
  }

  /* disable algo bypass mode */
  OMX_INIT_PARAM (&algEnable);
  algEnable.nPortIndex = 0;
  algEnable.nChId = 0;
  /* capture providing progressive input, alg is bypassed */
  algEnable.bAlgBypass = 1;
  if (strcmp ((char *) pAppData->mode, "1080i") == 0) {
   algEnable.bAlgBypass = 0;
  }

  eError = OMX_SetConfig (pAppData->pDeiHandle[instId],
                          (OMX_INDEXTYPE) OMX_TI_IndexConfigAlgEnable,
                          &algEnable);
  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to disable algo by pass mode\n");
  }

  return (eError);
}

/* ========================================================================== */
/**
* IL_ClientSetScalarParams() : Function to fill the port definition 
* structures and call the Set_Parameter function on to the scalar
* Component
*
* @param pAppData   : Pointer to the application data
*
*  @return      
*  OMX_ErrorNone = Successful 
*
*  Other_value = Failed (Error code is returned)
*
*/
/* ========================================================================== */

OMX_ERRORTYPE IL_ClientSetScalarParams (IL_Client *pAppData, unsigned int instId)
{
  OMX_ERRORTYPE eError = OMX_ErrorNone;
  OMX_PARAM_BUFFER_MEMORYTYPE memTypeCfg;
  OMX_PARAM_PORTDEFINITIONTYPE paramPort;
  OMX_PARAM_VFPC_NUMCHANNELPERHANDLE sNumChPerHandle;
  OMX_CONFIG_ALG_ENABLE algEnable;
  OMX_CONFIG_VIDCHANNEL_RESOLUTION chResolution;

  OMX_INIT_PARAM (&memTypeCfg);
  memTypeCfg.nPortIndex = OMX_VFPC_INPUT_PORT_START_INDEX;
  memTypeCfg.eBufMemoryType = OMX_BUFFER_MEMORY_DEFAULT;
  eError =
    OMX_SetParameter (pAppData->pScHandle[instId], OMX_TI_IndexParamBuffMemType,
                      &memTypeCfg);

  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set memory Type at input port\n");
  }

  /* Setting Memory type at output port to Raw Memory */
  OMX_INIT_PARAM (&memTypeCfg);
  memTypeCfg.nPortIndex = OMX_VFPC_OUTPUT_PORT_START_INDEX;
  memTypeCfg.eBufMemoryType = OMX_BUFFER_MEMORY_DEFAULT;
  eError =
    OMX_SetParameter (pAppData->pScHandle[instId], OMX_TI_IndexParamBuffMemType,
                      &memTypeCfg);

  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set memory Type at output port\n");
  }

  /* set input height/width and color format */
  OMX_INIT_PARAM (&paramPort);
  paramPort.nPortIndex = OMX_VFPC_INPUT_PORT_START_INDEX;

  OMX_GetParameter (pAppData->pScHandle[instId], OMX_IndexParamPortDefinition,
                    &paramPort);
  paramPort.nPortIndex = OMX_VFPC_INPUT_PORT_START_INDEX;
  paramPort.format.video.nFrameWidth = SCALAR_IN_WIDTH;//pAppData->nWidth;
  paramPort.format.video.nFrameHeight = SCALAR_IN_HEIGHT;//pAppData->nHeight;

  /* Scalar is connceted to H264 decoder, whose stride is different than width*/
  paramPort.format.video.nStride = SCALAR_IN_WIDTH;//pAppData->nDecStride;
  paramPort.format.video.eCompressionFormat = OMX_VIDEO_CodingUnused;
  paramPort.format.video.eColorFormat = OMX_COLOR_FormatYUV420SemiPlanar;
  paramPort.nBufferSize = (paramPort.format.video.nStride *
                           SCALAR_IN_HEIGHT * 3) >> 1;
                           //pAppData->nHeight * 3) >> 1;

  paramPort.nBufferAlignment = 0;
  paramPort.bBuffersContiguous = 0;
  paramPort.nBufferCountActual = IL_CLIENT_SCALAR_INPUT_BUFFER_COUNT;
  printf ("set input port params (width = %u, height = %u) \n",
          (unsigned int) paramPort.format.video.nFrameWidth, (unsigned int) paramPort.format.video.nFrameHeight);
  OMX_SetParameter (pAppData->pScHandle[instId], OMX_IndexParamPortDefinition,
                    &paramPort);

  /* set output height/width and color format */
  OMX_INIT_PARAM (&paramPort);
  paramPort.nPortIndex = OMX_VFPC_OUTPUT_PORT_START_INDEX;
  OMX_GetParameter (pAppData->pScHandle[instId], OMX_IndexParamPortDefinition,
                    &paramPort);

  paramPort.nPortIndex = OMX_VFPC_OUTPUT_PORT_START_INDEX;
  paramPort.format.video.nFrameWidth = SCALAR_OUT_WIDTH; 
  paramPort.format.video.nFrameHeight = SCALAR_OUT_HEIGHT;
  paramPort.format.video.eCompressionFormat = OMX_VIDEO_CodingUnused;
  paramPort.format.video.eColorFormat = OMX_COLOR_FormatYCbYCr;
  paramPort.nBufferAlignment = 0;
  paramPort.bBuffersContiguous = 0;
  paramPort.nBufferCountActual = IL_CLIENT_SCALAR_OUTPUT_BUFFER_COUNT;
  paramPort.format.video.nStride = SCALAR_OUT_WIDTH*2;

    if (1 == pAppData->displayId) {
    /*For the case of On-chip HDMI as display device*/
    paramPort.format.video.nFrameWidth = DISPLAY_WIDTH / 2;
    paramPort.format.video.nFrameHeight = DISPLAY_HEIGHT / 2;
    paramPort.format.video.nStride = (DISPLAY_WIDTH / 2) * 2;
  }
  
  paramPort.nBufferSize =
    paramPort.format.video.nStride * paramPort.format.video.nFrameHeight;

  printf ("set output port params (width = %d, height = %d) \n",
          (int) paramPort.format.video.nFrameWidth, (int) paramPort.format.video.nFrameHeight);

  OMX_SetParameter (pAppData->pScHandle[instId], OMX_IndexParamPortDefinition,
                    &paramPort);

  /* set number of channles */
  printf ("set number of channels \n");

  OMX_INIT_PARAM (&sNumChPerHandle);
  sNumChPerHandle.nNumChannelsPerHandle = 1;
  eError =
    OMX_SetParameter (pAppData->pScHandle[instId],
                      (OMX_INDEXTYPE) OMX_TI_IndexParamVFPCNumChPerHandle,
                      &sNumChPerHandle);
  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set num of channels\n");
  }

  /* set VFPC input and output resolution information */
  printf ("set input resolution \n");

  OMX_INIT_PARAM (&chResolution);
  chResolution.Frm0Width = SCALAR_IN_WIDTH;//pAppData->nWidth;
  chResolution.Frm0Height = SCALAR_IN_HEIGHT;//pAppData->nHeight;
  chResolution.Frm0Pitch = SCALAR_IN_WIDTH;//pAppData->nDecStride;
  chResolution.Frm1Width = 0;
  chResolution.Frm1Height = 0;
  chResolution.Frm1Pitch = 0;
  chResolution.FrmStartX = 0;
  chResolution.FrmStartY = 0;
  chResolution.FrmCropWidth = SCALAR_IN_WIDTH;//pAppData->nWidth;
  chResolution.FrmCropHeight = SCALAR_IN_HEIGHT;//pAppData->nHeight;
  chResolution.eDir = OMX_DirInput;
  chResolution.nChId = 0;

  eError =
    OMX_SetConfig (pAppData->pScHandle[instId],
                   (OMX_INDEXTYPE) OMX_TI_IndexConfigVidChResolution,
                   &chResolution);
  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set input channel resolution\n");
  }

  printf ("set output resolution \n");
  OMX_INIT_PARAM (&chResolution);
  chResolution.Frm0Width = SCALAR_OUT_WIDTH;//SWMOSAIC_WINDOW_WIDTH;
  chResolution.Frm0Height = SCALAR_OUT_HEIGHT;//SWMOSAIC_WINDOW_HEIGHT;
  chResolution.Frm0Pitch = SCALAR_OUT_WIDTH * 2;
  chResolution.Frm1Width = 0;
  chResolution.Frm1Height = 0;
  chResolution.Frm1Pitch = 0;
  chResolution.FrmStartX = 0;
  chResolution.FrmStartY = 0;
  chResolution.FrmCropWidth = 0;
  chResolution.FrmCropHeight = 0;
  chResolution.eDir = OMX_DirOutput;
  chResolution.nChId = 0;

   if (1 == pAppData->displayId) {
    /* on secondary display, it is scaled to display size / 4 */  
    chResolution.Frm0Width = DISPLAY_WIDTH / 2;
    chResolution.Frm0Height = DISPLAY_HEIGHT / 2;
    chResolution.Frm0Pitch = (DISPLAY_WIDTH / 2) * 2;  
  }

  eError =
    OMX_SetConfig (pAppData->pScHandle[instId],
                   (OMX_INDEXTYPE) OMX_TI_IndexConfigVidChResolution,
                   &chResolution);
  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set output channel resolution\n");
  }

  /* disable algo bypass mode */
  OMX_INIT_PARAM (&algEnable);
  algEnable.nPortIndex = 0;
  algEnable.nChId = 0;
  algEnable.bAlgBypass = 0;

  eError =
    OMX_SetConfig (pAppData->pScHandle[instId],
                   (OMX_INDEXTYPE) OMX_TI_IndexConfigAlgEnable, &algEnable);
  if (eError != OMX_ErrorNone)
    ERROR ("failed to disable algo by pass mode\n");

  return (eError);
}

/* ========================================================================== */
/**
* IL_ClientSetSwMosaicParams() : Function to fill the port definition 
* structures and call the Set_Parameter function on to the scalar
* Component
*
* @param pAppData   : Pointer to the application data
*
*  @return      
*  OMX_ErrorNone = Successful 
*
*  Other_value = Failed (Error code is returned)
*
*/
/* ========================================================================== */

OMX_ERRORTYPE IL_ClientSetSwMosaicParams ( IL_Client *pAppData )
{
  int i;
  OMX_ERRORTYPE eError = OMX_ErrorNone;
  OMX_PARAM_BUFFER_MEMORYTYPE memTypeCfg;
  OMX_PARAM_PORTDEFINITIONTYPE paramPort;
  OMX_CONFIG_VSWMOSAIC_CREATEMOSAICLAYOUT  sMosaic;

  OMX_INIT_PARAM (&memTypeCfg);
  memTypeCfg.eBufMemoryType = OMX_BUFFER_MEMORY_DEFAULT;

  for ( i = 0; i < g_max_decode; i++) {
   memTypeCfg.nPortIndex = OMX_VSWMOSAIC_INPUT_PORT_START_INDEX + i;
   
   eError =
     OMX_SetParameter (pAppData->pVswmosaicHandle, OMX_TI_IndexParamBuffMemType,
                       &memTypeCfg);
   if (eError != OMX_ErrorNone)
   {
     ERROR ("failed to set memory Type at input port\n");
   }
 }

  /* Setting Memory type at output port to Raw Memory */
  OMX_INIT_PARAM (&memTypeCfg);
  memTypeCfg.nPortIndex = OMX_VSWMOSAIC_OUTPUT_PORT_START_INDEX;
  memTypeCfg.eBufMemoryType = OMX_BUFFER_MEMORY_DEFAULT;
  eError =
    OMX_SetParameter (pAppData->pVswmosaicHandle, OMX_TI_IndexParamBuffMemType,
                      &memTypeCfg);

  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set memory Type at output port\n");
  }

  for ( i = 0; i < g_max_decode; i++) {
   /* set input height/width and color format */
   OMX_INIT_PARAM (&paramPort);
   paramPort.nPortIndex = OMX_VSWMOSAIC_INPUT_PORT_START_INDEX + i;

   OMX_GetParameter (pAppData->pVswmosaicHandle, OMX_IndexParamPortDefinition,
                     &paramPort);
   paramPort.nPortIndex = OMX_VFPC_INPUT_PORT_START_INDEX + i;
   paramPort.format.video.nFrameWidth  = SWMOSAIC_WINDOW_WIDTH; 
   paramPort.format.video.nFrameHeight = SWMOSAIC_WINDOW_HEIGHT;
   /* swmosaic is connceted to scalar, whose stride is different than width*/
   paramPort.format.video.nStride = SWMOSAIC_WINDOW_WIDTH * 2;

   if (1 == pAppData->displayId) {
     /*For the case of On-chip HDMI as display device*/
     paramPort.format.video.nFrameWidth = DISPLAY_WIDTH / 2;
     paramPort.format.video.nFrameHeight = DISPLAY_HEIGHT / 2;
     paramPort.format.video.nStride = (DISPLAY_WIDTH / 2) * 2;
   }

   paramPort.format.video.eCompressionFormat = OMX_VIDEO_CodingUnused;
   paramPort.format.video.eColorFormat = OMX_COLOR_FormatYCbYCr;
   paramPort.nBufferSize = (paramPort.format.video.nStride *
                            paramPort.format.video.nFrameHeight);

   paramPort.nBufferAlignment = 0;
   paramPort.bBuffersContiguous = 0;
   paramPort.nBufferCountActual = IL_CLIENT_VSWMOSAIC_INPUT_BUFFER_COUNT;
   printf ("vswmosaic: set input port params (width = %u, height = %u) \n",
           (unsigned int)paramPort.format.video.nFrameWidth, 
           (unsigned int)paramPort.format.video.nFrameHeight);
   OMX_SetParameter (pAppData->pVswmosaicHandle, OMX_IndexParamPortDefinition,
                     &paramPort);
 }
  
  /* set output height/width and color format */
  OMX_INIT_PARAM (&paramPort);
  paramPort.nPortIndex = OMX_VSWMOSAIC_OUTPUT_PORT_START_INDEX;
  OMX_GetParameter (pAppData->pVswmosaicHandle, OMX_IndexParamPortDefinition,
                    &paramPort);

  paramPort.nPortIndex = OMX_VSWMOSAIC_OUTPUT_PORT_START_INDEX;
  paramPort.format.video.nFrameWidth  = HD_WIDTH;
  paramPort.format.video.nFrameHeight = HD_HEIGHT;
  paramPort.format.video.eCompressionFormat = OMX_VIDEO_CodingUnused;
  paramPort.format.video.eColorFormat = OMX_COLOR_FormatYCbYCr;
  paramPort.nBufferAlignment = 0;
  paramPort.bBuffersContiguous = 0;
  paramPort.nBufferCountActual = IL_CLIENT_SCALAR_OUTPUT_BUFFER_COUNT;
  paramPort.format.video.nStride = HD_WIDTH * 2;

  if (1 == pAppData->displayId) {
    /*For the case of On-chip HDMI as display device*/
    paramPort.format.video.nFrameWidth = DISPLAY_WIDTH;
    paramPort.format.video.nFrameHeight = DISPLAY_HEIGHT;
    paramPort.format.video.nStride = DISPLAY_WIDTH * 2;
  }

  paramPort.nBufferSize =
    paramPort.format.video.nStride * paramPort.format.video.nFrameHeight;

  printf ("vswmosaic: set output port params (width = %d, height = %d) \n",
          (int) paramPort.format.video.nFrameWidth, (int) paramPort.format.video.nFrameHeight);
      

  OMX_SetParameter (pAppData->pVswmosaicHandle, OMX_IndexParamPortDefinition,
                    &paramPort);

  OMX_INIT_PARAM (&sMosaic);
  sMosaic.nPortIndex  = OMX_VSWMOSAIC_OUTPUT_PORT_START_INDEX;
  
  sMosaic.nOpWidth    = HD_WIDTH;  /* Width in pixels  */
  sMosaic.nOpHeight   = HD_HEIGHT; /* Height in pixels */
  sMosaic.nOpPitch    = HD_WIDTH*2; /* Pitch in bytes   */

  if (1 == pAppData->displayId) {
    /* on secondary display, it is scaled to display size */  
    sMosaic.nOpWidth = DISPLAY_WIDTH;
    sMosaic.nOpHeight= DISPLAY_HEIGHT;
    sMosaic.nOpPitch = DISPLAY_WIDTH*2;  
  }
  printf ("vswmosaic: Width=%d, Height=%d, pitch=%d\n", (int) sMosaic.nOpWidth,
          (int) sMosaic.nOpHeight, (int) sMosaic.nOpPitch);

  sMosaic.nNumWindows = g_max_decode;
  
  for ( i = 0; i < g_max_decode; i++) {
    sMosaic.sMosaicWinFmt[i].dataFormat = OMX_COLOR_FormatYCbYCr;
    sMosaic.sMosaicWinFmt[i].nPortIndex = i;
    sMosaic.sMosaicWinFmt[i].pitch[0]   = SWMOSAIC_WINDOW_WIDTH*2;
    sMosaic.sMosaicWinFmt[i].winStartX  = (i%2) * SWMOSAIC_WINDOW_WIDTH;
    sMosaic.sMosaicWinFmt[i].winStartY  = (i/2) * SWMOSAIC_WINDOW_HEIGHT;
    sMosaic.sMosaicWinFmt[i].winWidth   = SWMOSAIC_WINDOW_WIDTH;
    sMosaic.sMosaicWinFmt[i].winHeight  = SWMOSAIC_WINDOW_HEIGHT;

     if (1 == pAppData->displayId) {
      /* on secondary display, it is scaled to display size */  
      sMosaic.sMosaicWinFmt[i].pitch[0]  = (DISPLAY_WIDTH/2) * 2;
      sMosaic.sMosaicWinFmt[i].winHeight = DISPLAY_HEIGHT / 2;
      sMosaic.sMosaicWinFmt[i].winWidth  = DISPLAY_WIDTH / 2;  
      sMosaic.sMosaicWinFmt[i].winStartX = (i%2) * (DISPLAY_WIDTH / 2);
      sMosaic.sMosaicWinFmt[i].winStartY = (i/2) * (DISPLAY_HEIGHT / 2);
      
    }
   }

  eError = OMX_SetConfig (pAppData->pVswmosaicHandle, 
                          OMX_TI_IndexConfigVSWMOSAICCreateMosaicLayout, 
                          &sMosaic);
  if (eError != OMX_ErrorNone)
  {
    ERROR ("Failed to set OMX_TI_IndexConfigVSWMOSAICCreateMosaicLayout for output \n");
  }
  else {
    printf ("Mosaic layout configuration:: Successful \n");
  }

  return (eError);
}

/* ========================================================================== */
/**
* IL_ClientSetScalarParams() : Function to fill the port definition 
* structures and call the Set_Parameter function on to the scalar
* Component
*
* @param pAppData   : Pointer to the application data
*
*  @return      
*  OMX_ErrorNone = Successful 
*
*  Other_value = Failed (Error code is returned)
*
*/
/* ========================================================================== */

OMX_ERRORTYPE IL_ClientSetNfParams (IL_Client *pAppData, unsigned int instId)
{
  OMX_ERRORTYPE eError = OMX_ErrorNone;
  OMX_PARAM_BUFFER_MEMORYTYPE memTypeCfg;
  OMX_PARAM_PORTDEFINITIONTYPE paramPort;
  OMX_PARAM_VFPC_NUMCHANNELPERHANDLE sNumChPerHandle;
  OMX_CONFIG_ALG_ENABLE algEnable;
  OMX_CONFIG_VIDCHANNEL_RESOLUTION chResolution;

  OMX_INIT_PARAM (&memTypeCfg);
  memTypeCfg.nPortIndex = OMX_VFPC_INPUT_PORT_START_INDEX;
  memTypeCfg.eBufMemoryType = OMX_BUFFER_MEMORY_DEFAULT;
  eError =
    OMX_SetParameter (pAppData->pNfHandle[instId], OMX_TI_IndexParamBuffMemType,
                      &memTypeCfg);

  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set memory Type at input port\n");
  }

  /* Setting Memory type at output port to Raw Memory */
  OMX_INIT_PARAM (&memTypeCfg);
  memTypeCfg.nPortIndex = OMX_VFPC_OUTPUT_PORT_START_INDEX;
  memTypeCfg.eBufMemoryType = OMX_BUFFER_MEMORY_DEFAULT;
  eError =
    OMX_SetParameter (pAppData->pNfHandle[instId], OMX_TI_IndexParamBuffMemType,
                      &memTypeCfg);

  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set memory Type at output port\n");
  }

  /* set input height/width and color format */
  OMX_INIT_PARAM (&paramPort);
  paramPort.nPortIndex = OMX_VFPC_INPUT_PORT_START_INDEX;

  OMX_GetParameter (pAppData->pNfHandle[instId], OMX_IndexParamPortDefinition,
                    &paramPort);
  paramPort.nPortIndex = OMX_VFPC_INPUT_PORT_START_INDEX;
  paramPort.format.video.nFrameWidth  = pAppData->nWidth;
  paramPort.format.video.nFrameHeight = pAppData->nHeight;

  /* Scalar is connceted to H264 decoder, whose stride is different than width*/
  paramPort.format.video.nStride = pAppData->nWidth * 2;
  paramPort.format.video.eCompressionFormat = OMX_VIDEO_CodingUnused;
  paramPort.format.video.eColorFormat = OMX_COLOR_FormatYCbYCr;
  paramPort.nBufferSize = (paramPort.format.video.nStride *
                           paramPort.format.video.nFrameHeight * 2);

  paramPort.nBufferAlignment = 0;
  paramPort.bBuffersContiguous = 0;
  paramPort.nBufferCountActual = IL_CLIENT_NF_INPUT_BUFFER_COUNT;
  printf ("set input port params (width = %u, height = %u) \n",
          (unsigned int) pAppData->nWidth, (unsigned int) pAppData->nHeight);
  OMX_SetParameter (pAppData->pNfHandle[instId], OMX_IndexParamPortDefinition,
                    &paramPort);

  /* set output height/width and color format */
  OMX_INIT_PARAM (&paramPort);
  paramPort.nPortIndex = OMX_VFPC_OUTPUT_PORT_START_INDEX;
  OMX_GetParameter (pAppData->pNfHandle[instId], OMX_IndexParamPortDefinition,
                    &paramPort);

  paramPort.nPortIndex = OMX_VFPC_OUTPUT_PORT_START_INDEX;
  paramPort.format.video.nFrameWidth  = pAppData->nWidth;
  paramPort.format.video.nFrameHeight = pAppData->nHeight;
  paramPort.format.video.eCompressionFormat = OMX_VIDEO_CodingUnused;
  paramPort.format.video.eColorFormat = OMX_COLOR_FormatYUV420SemiPlanar;
  paramPort.nBufferAlignment = 0;
  paramPort.bBuffersContiguous = 0;
  paramPort.nBufferCountActual = IL_CLIENT_NF_OUTPUT_BUFFER_COUNT;
  /* scalar buffer pitch should be multiple of 16 */
  paramPort.format.video.nStride = pAppData->nWidth;

  paramPort.nBufferSize =
   (paramPort.format.video.nStride * paramPort.format.video.nFrameHeight * 3 )>> 1;

  printf ("set output port params (width = %d, height = %d) \n",
          (int) paramPort.format.video.nFrameWidth,
          (int) paramPort.format.video.nFrameHeight);

  OMX_SetParameter (pAppData->pNfHandle[instId], OMX_IndexParamPortDefinition,
                    &paramPort);

  /* set number of channles */
  printf ("set number of channels \n");

  OMX_INIT_PARAM (&sNumChPerHandle);
  sNumChPerHandle.nNumChannelsPerHandle = 1;
  eError =
    OMX_SetParameter (pAppData->pNfHandle[instId],
                      (OMX_INDEXTYPE) OMX_TI_IndexParamVFPCNumChPerHandle,
                      &sNumChPerHandle);
  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set num of channels\n");
  }

  /* set VFPC input and output resolution information */
  printf ("set input resolution \n");

  OMX_INIT_PARAM (&chResolution);
  chResolution.Frm0Width =  pAppData->nWidth;
  chResolution.Frm0Height = pAppData->nHeight;
  chResolution.Frm0Pitch =  pAppData->nWidth * 2;
  chResolution.Frm1Width = 0;
  chResolution.Frm1Height = 0;
  chResolution.Frm1Pitch = 0;
  chResolution.FrmStartX = 0;
  chResolution.FrmStartY = 0;
  chResolution.FrmCropWidth = 0;
  chResolution.FrmCropHeight = 0;
  chResolution.eDir = OMX_DirInput;
  chResolution.nChId = 0;

  eError =
    OMX_SetConfig (pAppData->pNfHandle[instId],
                   (OMX_INDEXTYPE) OMX_TI_IndexConfigVidChResolution,
                   &chResolution);
  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set input channel resolution\n");
  }

  printf ("set output resolution \n");
  OMX_INIT_PARAM (&chResolution);
  chResolution.Frm0Width  = pAppData->nWidth;
  chResolution.Frm0Height = pAppData->nHeight;
  chResolution.Frm0Pitch  = pAppData->nWidth;
  chResolution.Frm1Width = 0;
  chResolution.Frm1Height = 0;
  chResolution.Frm1Pitch = 0;
  chResolution.FrmStartX = 0;
  chResolution.FrmStartY = 0;
  chResolution.FrmCropWidth = 0;
  chResolution.FrmCropHeight = 0;
  chResolution.eDir = OMX_DirOutput;
  chResolution.nChId = 0;

  eError =
    OMX_SetConfig (pAppData->pNfHandle[instId],
                   (OMX_INDEXTYPE) OMX_TI_IndexConfigVidChResolution,
                   &chResolution);
  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set output channel resolution\n");
  }

  /* disable algo bypass mode */
  OMX_INIT_PARAM (&algEnable);
  algEnable.nPortIndex = 0;
  algEnable.nChId = 0;
  algEnable.bAlgBypass = 0;

  eError =
    OMX_SetConfig (pAppData->pNfHandle[instId],
                   (OMX_INDEXTYPE) OMX_TI_IndexConfigAlgEnable, &algEnable);
  if (eError != OMX_ErrorNone)
    ERROR ("failed to disable algo by pass mode\n");

  return (eError);
}


/* ========================================================================== */
/**
* IL_ClientSetDisplayParams() : Function to fill the port definition 
* structures and call the Set_Parameter function on to the display
* Component
*
* @param pAppData   : Pointer to the application data
*
*  @return      
*  OMX_ErrorNone = Successful 
*
*  Other_value = Failed (Error code is returned)
*
*/
/* ========================================================================== */

OMX_ERRORTYPE IL_ClientSetDisplayParams (IL_Client *pAppData, unsigned int instId)
{
  OMX_ERRORTYPE eError = OMX_ErrorNone;
  OMX_PARAM_BUFFER_MEMORYTYPE memTypeCfg;
  OMX_PARAM_PORTDEFINITIONTYPE paramPort;
  //OMX_PARAM_VFPC_NUMCHANNELPERHANDLE sNumChPerHandle;
  OMX_PARAM_VFDC_DRIVERINSTID driverId;
  OMX_PARAM_VFDC_CREATEMOSAICLAYOUT mosaicLayout;
  OMX_CONFIG_VFDC_MOSAICLAYOUT_PORT2WINMAP port2Winmap;

  OMX_INIT_PARAM (&paramPort);

  /* set input height/width and color format */
  paramPort.nPortIndex = OMX_VFDC_INPUT_PORT_START_INDEX;
  OMX_GetParameter (pAppData->pDisHandle[instId], OMX_IndexParamPortDefinition,
                    &paramPort);
  paramPort.nPortIndex = OMX_VFDC_INPUT_PORT_START_INDEX;
  paramPort.format.video.nFrameWidth = pAppData->nWidth;
  paramPort.format.video.nFrameHeight = pAppData->nHeight;
  paramPort.format.video.nStride = pAppData->nWidth * 2;
  paramPort.nBufferCountActual = IL_CLIENT_DISPLAY_INPUT_BUFFER_COUNT;
  paramPort.format.video.eCompressionFormat = OMX_VIDEO_CodingUnused;
  paramPort.format.video.eColorFormat = OMX_COLOR_FormatYCbYCr;

  paramPort.nBufferSize = paramPort.format.video.nStride * pAppData->nHeight;

#if 0  
   if (1 == pAppData->displayId) {
    /* on secondary display, it is scaled to display size */  
    paramPort.format.video.nFrameWidth = DISPLAY_WIDTH;
    paramPort.format.video.nFrameHeight = DISPLAY_HEIGHT;
    paramPort.format.video.nStride = DISPLAY_WIDTH * 2;  
  }
#endif  
   if (1 == instId) {
    /* on secondary display, it is scaled to display size */  
    paramPort.format.video.nFrameWidth = DISPLAY_WIDTH;
    paramPort.format.video.nFrameHeight = DISPLAY_HEIGHT;
    paramPort.format.video.nStride = DISPLAY_WIDTH * 2;  
  }  
  
  paramPort.nBufferSize = paramPort.format.video.nStride * pAppData->nHeight;
  
  printf ("Buffer Size computed: %d\n", (int) paramPort.nBufferSize);
  printf ("set input port params (width = %d, height = %d)",
          (int) pAppData->nWidth, (int) pAppData->nHeight);
  OMX_SetParameter (pAppData->pDisHandle[instId], OMX_IndexParamPortDefinition,
                    &paramPort);
  /* --------------------------------------------------------------------------*
     Supported display IDs by VFDC and DC are below The names will be renamed in
     future releases as some of the driver names & interfaces will be changed in
     future @ param OMX_VIDEO_DISPLAY_ID_HD0: 422P On-chip HDMI @ param
     OMX_VIDEO_DISPLAY_ID_HD1: 422P HDDAC component output @ param
     OMX_VIDEO_DISPLAY_ID_SD0: 420T/422T SD display (NTSC): Not supported yet.
     ------------------------------------------------------------------------ */

  /* set the parameter to the disaply component to 1080P @60 mode */
  OMX_INIT_PARAM (&driverId);
  /* Configured to use on-chip HDMI */
#if 0
  if (0 == pAppData->displayId) {
    /* Configured to use on-chip HDMI */
     driverId.nDrvInstID = OMX_VIDEO_DISPLAY_ID_HD0;
     
    /* Depending on the mode parameter set via cmd line, set the mode*/
    if ((strcmp ((char *) pAppData->mode, "1080p") == 0) || (strcmp ((char *) pAppData->mode, "1080i") == 0)) 
    {
      driverId.eDispVencMode = OMX_DC_MODE_1080P_60;
    }
    else if (strcmp ((char *) pAppData->mode, "720p") == 0)
    {
      driverId.eDispVencMode = OMX_DC_MODE_720P_60;
    }
    else
    {
      ERROR ("Incorrect Display Mode configured!!\n");
    }
    
  } 
  else if (1 == pAppData->displayId) {
    /* Configured to use LCD Display */
    driverId.nDrvInstID = OMX_VIDEO_DISPLAY_ID_HD1;
    driverId.eDispVencMode = DISPLAY_VENC_MODE;
  } 
  else {
    ERROR ("Incorrect Display Id configured\n");
  }
#endif
  if (0 == instId) {
    /* Configured to use on-chip HDMI */
     driverId.nDrvInstID = OMX_VIDEO_DISPLAY_ID_HD0;
     
    /* Depending on the mode parameter set via cmd line, set the mode*/
    if ((strcmp ((char *) pAppData->mode, "1080p") == 0) || (strcmp ((char *) pAppData->mode, "1080i") == 0)) 
    {
      driverId.eDispVencMode = OMX_DC_MODE_1080P_60;
    }
    else if (strcmp ((char *) pAppData->mode, "720p") == 0)
    {
      driverId.eDispVencMode = OMX_DC_MODE_720P_60;
    }
    else
    {
      ERROR ("Incorrect Display Mode configured!!\n");
    }
    
  } 
  else if (1 == instId) {
    /* Configured to use LCD Display */
    driverId.nDrvInstID = OMX_VIDEO_DISPLAY_ID_HD1;
    driverId.eDispVencMode = DISPLAY_VENC_MODE;
  } 
  else {
    ERROR ("Incorrect Display Id configured\n");
  }
  
  eError = OMX_SetParameter (pAppData->pDisHandle[instId],
                             (OMX_INDEXTYPE) OMX_TI_IndexParamVFDCDriverInstId,
                             &driverId);
  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set driver mode to 1080P@60\n");
  }

  /* set the parameter to the disaply controller component to 1080P @60 mode */
  OMX_INIT_PARAM (&driverId);
  /* Configured to use on-chip HDMI */
#if 0
  if (0 == pAppData->displayId) {
    /* Configured to use on-chip HDMI */
     driverId.nDrvInstID = OMX_VIDEO_DISPLAY_ID_HD0;
     
    /* Depending on the mode parameter set via cmd line, set the mode*/
    if ((strcmp ((char *) pAppData->mode, "1080p") == 0) || (strcmp ((char *) pAppData->mode, "1080i") == 0)) 
    {
      driverId.eDispVencMode = OMX_DC_MODE_1080P_60;
    }
    else if (strcmp ((char *) pAppData->mode, "720p") == 0)
    {
      driverId.eDispVencMode = OMX_DC_MODE_720P_60;
    }
    else
    {
      ERROR ("Incorrect Display Mode configured!!\n");
    }
    
  } 
  else if (1 == pAppData->displayId) {
    /* Configured to use LCD Display */
    driverId.nDrvInstID = OMX_VIDEO_DISPLAY_ID_HD1;
    driverId.eDispVencMode = DISPLAY_VENC_MODE;
  } 
  else {
    ERROR ("Incorrect Display Id configured\n");
  }
#endif
  if (0 == instId) {
    /* Configured to use on-chip HDMI */
     driverId.nDrvInstID = OMX_VIDEO_DISPLAY_ID_HD0;
     
    /* Depending on the mode parameter set via cmd line, set the mode*/
    if ((strcmp ((char *) pAppData->mode, "1080p") == 0) || (strcmp ((char *) pAppData->mode, "1080i") == 0)) 
    {
      driverId.eDispVencMode = OMX_DC_MODE_1080P_60;
    }
    else if (strcmp ((char *) pAppData->mode, "720p") == 0)
    {
      driverId.eDispVencMode = OMX_DC_MODE_720P_60;
    }
    else
    {
      ERROR ("Incorrect Display Mode configured!!\n");
    }
    
  } 
  else if (1 == instId) {
    /* Configured to use LCD Display */
    driverId.nDrvInstID = OMX_VIDEO_DISPLAY_ID_HD1;
    driverId.eDispVencMode = DISPLAY_VENC_MODE;
  } 
  else {
    ERROR ("Incorrect Display Id configured\n");
  }

  eError = OMX_SetParameter (pAppData->pctrlHandle[instId],
                             (OMX_INDEXTYPE) OMX_TI_IndexParamVFDCDriverInstId,
                             &driverId);
  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set driver mode to 1080P@60\n");
  }
#if 0
  if (1 == pAppData->displayId) {
   IL_ClientSetSecondaryDisplayParams(pAppData);
   }
#endif
  if (1 == instId) {
   IL_ClientSetSecondaryDisplayParams(pAppData);
   }

  /* set mosaic layout info */

  OMX_INIT_PARAM (&mosaicLayout);
  /* Configuring the first (and only) window */
  mosaicLayout.sMosaicWinFmt[0].winStartX = 0;
  mosaicLayout.sMosaicWinFmt[0].winStartY = 0;
  mosaicLayout.sMosaicWinFmt[0].winWidth = pAppData->nWidth;
  mosaicLayout.sMosaicWinFmt[0].winHeight = pAppData->nHeight;
  mosaicLayout.sMosaicWinFmt[0].pitch[VFDC_YUV_INT_ADDR_IDX] =
    pAppData->nWidth * 2;
  mosaicLayout.sMosaicWinFmt[0].dataFormat = VFDC_DF_YUV422I_YVYU;
  mosaicLayout.sMosaicWinFmt[0].bpp = VFDC_BPP_BITS16;
  mosaicLayout.sMosaicWinFmt[0].priority = 0;
  mosaicLayout.nDisChannelNum = 0;
  /* Only one window in this layout, hence setting it to 1 */
  mosaicLayout.nNumWindows = 1;

#if 0
  if (1 == pAppData->displayId) {
    /* For secondary Display, start the window at (0,0), since it is 
       scaled to display device size */
    mosaicLayout.sMosaicWinFmt[0].winStartX = 0;
    mosaicLayout.sMosaicWinFmt[0].winStartY = 0;
    
    /*If LCD is chosen, fir the mosaic window to the size of the LCD display*/
    mosaicLayout.sMosaicWinFmt[0].winWidth = DISPLAY_WIDTH;
    mosaicLayout.sMosaicWinFmt[0].winHeight = DISPLAY_HEIGHT;
    mosaicLayout.sMosaicWinFmt[0].pitch[VFDC_YUV_INT_ADDR_IDX] = 
                                       DISPLAY_WIDTH * 2;  
  }
#endif
  if (1 == instId) {
    /* For secondary Display, start the window at (0,0), since it is 
       scaled to display device size */
    mosaicLayout.sMosaicWinFmt[0].winStartX = 0;
    mosaicLayout.sMosaicWinFmt[0].winStartY = 0;
    
    /*If LCD is chosen, fir the mosaic window to the size of the LCD display*/
    mosaicLayout.sMosaicWinFmt[0].winWidth = DISPLAY_WIDTH;
    mosaicLayout.sMosaicWinFmt[0].winHeight = DISPLAY_HEIGHT;
    mosaicLayout.sMosaicWinFmt[0].pitch[VFDC_YUV_INT_ADDR_IDX] = 
                                       DISPLAY_WIDTH * 2;  
  }

  eError = OMX_SetParameter (pAppData->pDisHandle[instId], (OMX_INDEXTYPE)
                             OMX_TI_IndexParamVFDCCreateMosaicLayout,
                             &mosaicLayout);
  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set mosaic window parameter\n");
  }

  /* map OMX port to window */
  OMX_INIT_PARAM (&port2Winmap);
  /* signifies the layout id this port2win mapping refers to */
  port2Winmap.nLayoutId = 0;
  /* Just one window in this layout, hence setting the value to 1 */
  port2Winmap.numWindows = 1;
  /* Only 1st input port used here */
  port2Winmap.omxPortList[0] = OMX_VFDC_INPUT_PORT_START_INDEX + 0;
  eError = OMX_SetConfig (pAppData->pDisHandle[instId],
                          (OMX_INDEXTYPE)
                            OMX_TI_IndexConfigVFDCMosaicPort2WinMap,
                          &port2Winmap);
  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to map port to windows\n");
  }

  /* Setting Memory type at input port to Raw Memory */
  printf ("setting input and output memory type to default");
  OMX_INIT_PARAM (&memTypeCfg);
  memTypeCfg.nPortIndex = OMX_VFPC_INPUT_PORT_START_INDEX;
  memTypeCfg.eBufMemoryType = OMX_BUFFER_MEMORY_DEFAULT;
  eError = OMX_SetParameter (pAppData->pDisHandle[instId], OMX_TI_IndexParamBuffMemType,
                             &memTypeCfg);

  if (eError != OMX_ErrorNone)
  {
    ERROR ("failed to set memory Type at input port\n");
  }

  return (eError);
}

/* Nothing beyond this point */

