#include <stdlib.h>
#include <stdio.h>
#include <memory.h>
#include <limits.h>

#include <pthread.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>

#include <sys/stat.h>
#include <fcntl.h> 
#include <termios.h>
#include <errno.h>
/*--------------------- system and platform files ----------------------------*/
#include <xdc/std.h>

/*-------------------------program files -------------------------------------*/
#include "ti/omx/interfaces/openMaxv11/OMX_Core.h"
#include "ti/omx/interfaces/openMaxv11/OMX_Component.h"
#include "OMX_TI_Common.h"
#include "OMX_Video.h"
#include "OMX_TI_Video.h"

#include <ti/omx/omxutils/omx_utils.h>
#include "timer.h"
#include "abm.h"
#include "common.h"

extern OMX_BOOL gILClientExit;
extern OMX_BOOL gILCVBSInit;

 enum APP_TRANS_FLAG
 {
    APP_TRANS_FRAME,
    APP_TRANS_INVALID
 };


void EventAUX(t_analyze* p_analyze, int *rect)
{
      t_cmd cmd;
      size_t size;

      int rectNum   = rect[0];
      int MaxTop    = rect[1];
      int MaxLeft   = rect[2];
      int MaxBottom = rect[3];
      int MaxRight  = rect[4];

      fill_cmd_header(&cmd, COMMAND_EVENT_AUX);

          add_attr_int(&cmd, "Channel", 0);
          add_attr_int(&cmd, "Targets", rectNum);
          add_attr_int(&cmd, "MaxTop", MaxTop);
          add_attr_int(&cmd, "MaxLeft", MaxLeft);
          add_attr_int(&cmd, "MaxBottom", MaxBottom);
          add_attr_int(&cmd, "MaxRight", MaxRight);

      rectNum   = rect[5];
      MaxTop    = rect[6];
      MaxLeft   = rect[7];
      MaxBottom = rect[8];
      MaxRight =  rect[9];

          add_attr_int(&cmd, "Channel", 1);
          add_attr_int(&cmd, "Targets", rectNum);
          add_attr_int(&cmd, "MaxTop", MaxTop);
          add_attr_int(&cmd, "MaxLeft", MaxLeft);
          add_attr_int(&cmd, "MaxBottom", MaxBottom);
          add_attr_int(&cmd, "MaxRight", MaxRight);

      debug_printf("Msg: %s\n", cmd.data);
      char2hex(cmd.data_len, &size, DATA_LEN_SIZE);
      size += PACKET_HEADER_SIZE;
      // send(sock, cmd.fullbuf, size, 0);

      int flags = FRAME_FLAG_NEWFRAME | FRAME_FLAG_FRAMEEND;
      datafifo_producer_data_add(&p_analyze->producer_fifo, (unsigned char *)cmd.fullbuf, (int)size, flags, 0);

      debug_printf("EventAUX msg sent\n");
}

void CVBS_Example(void *thread_args)
{
  t_analyze *pt_analyze = (t_analyze *)thread_args;

  static enum APP_TRANS_FLAG trans_flag = APP_TRANS_FRAME;
 
  int state_flag_stream = 0;
  int stream_id = 0;

  unsigned int width = 0;
  unsigned int height = 0;
  unsigned int datalen = 0;

  unsigned char *Frame_Buffer = NULL;
  static int rect[10] = {0};
  
  ParseArgs("StudentDetectArgs.txt");  
  ABM_Init();

  while(1){
  		if (gILClientExit == OMX_TRUE){
			break;
		}
		if(gILCVBSInit == OMX_TRUE) {
			ABM_Reset();
			gILCVBSInit = OMX_FALSE;
		}
		  if(datafifo_head(&pt_analyze->consumer_fifo)){
		        debug_printf(" thread_analysis receive message\n");

		        char *Msg = datafifo_head(&pt_analyze->consumer_fifo)->arg.data;

		        int *ptrInt = (int *)Msg;

		        width = ptrInt[1];
		        height = ptrInt[2];
		        datalen = width*height;
		        Frame_Buffer = &Msg[16];

		        stream_id = ptrInt[0];

		        if(stream_id == 0 || stream_id == 1) state_flag_stream = 1;

			if(state_flag_stream) {
				   state_flag_stream = 0;
		                   IMAGE* object = stream_id ? objectChannel1 : objectChannel0;

		                   int time1 = 0, time2 = 0;
		                   time1 = get_timestamp();
		                   ABM_test4(Frame_Buffer, object);
		                   time2 = get_timestamp();
		                   // printf("--------> Time :%f/frame\n", (double)(time2 - time1)/CLOCKS_PER_SEC);

				  int maxTop = height;
				  int maxLeft = width;
				  int maxBottom = 0;
				  int maxRight = 0;
				  int recNum = object->recNum;
				  int *ptrIntRect = object->coordinate;

		  	      	int i;
		  	      	for (i = 0; i < recNum; i=i+4)
		  	      	{
		  		        if(maxLeft > ptrIntRect[i]) maxLeft = ptrIntRect[i];
		  		        if(maxTop > ptrIntRect[i+1]) maxTop = ptrIntRect[i+1];
		  		        if(maxRight < ptrIntRect[i+2]) maxRight = ptrIntRect[i+2];
		  		        if(maxBottom < ptrIntRect[i+3]) maxBottom = ptrIntRect[i+3];
		  	      	}
		  		if(recNum)
		  			printf("ID:  %d, %d   CVBS Rect: (%d, %d), (%d, %d)\n", recNum/4, stream_id, maxTop, maxLeft, maxBottom, maxRight);
		  	     
		  	      	if(stream_id == 0) 
		  		{
		  			rect[0] = recNum/4;
		  			rect[1] = maxTop;
		  	 	   	rect[2] = maxLeft;
		  		   	rect[3] = maxBottom;
		  			rect[4] = maxRight;
		  		} else if(stream_id ==1){
		  			rect[5] = recNum/4;
		  			rect[6] = maxTop;
		  	   		rect[7] = maxLeft;
		  	   		rect[8] = maxBottom;
		  			rect[9] = maxRight;
		  	        	EventAUX(pt_analyze, rect);
		  		} 
			}
		        datafifo_consumer_remove_head(&pt_analyze->consumer_fifo);
		}
		usleep(1000);
	}
	
	ABM_Deinit();
	pthread_exit(0);
}
