#include "abm.h"

extern int  VERTICAL_THRESH = 500;
extern int  HORIZONAL_THRESH = 500;
extern int  PIXEL_DIFF_THRESH = 20;
extern int  PIXEL_DIFF_THRESH_DETECT = 15;
extern int  FIRST_FRAME_NUM = 50;
extern int  ROW_THRESH = 144;
extern int  BGD_THRESH = 100;
extern int  COUNTIN_THRESH = 50;
extern int  OBJECT_SIZE = 5;
extern int  UPDATE_RATE = 5;//must be in (0,100)
extern int  TOP_THRESH = 0;

IMAGE object0;
IMAGE object1;
extern IMAGE* objectChannel0 = NULL;
extern IMAGE* objectChannel1 = NULL;

void ParseArgs(const char *args_file)
{
	FILE *file = fopen(args_file, "r");
	if(!file) {
		printf("open args file failed.\n");
		return;
	}

	char item[128];
	int value = 0;
	while(!feof(file))
	{
		fscanf(file, "%s %d\n", item, &value);
		if(!strcmp(item, "VERTICAL_THRESH")) VERTICAL_THRESH = value;
		else if(!strcmp(item, "HORIZONAL_THRESH")) HORIZONAL_THRESH = value;
		else if(!strcmp(item, "PIXEL_DIFF_THRESH")) PIXEL_DIFF_THRESH = value;
		else if(!strcmp(item, "PIXEL_DIFF_THRESH_DETECT")) PIXEL_DIFF_THRESH_DETECT = value;
		else if(!strcmp(item, "FIRST_FRAME_NUM")) FIRST_FRAME_NUM = value;
		else if(!strcmp(item, "ROW_THRESH")) ROW_THRESH = value;
		else if(!strcmp(item, "BGD_THRESH")) BGD_THRESH = value;
		else if(!strcmp(item, "COUNTIN_THRESH")) COUNTIN_THRESH = value;
		else if(!strcmp(item, "OBJECT_SIZE")) OBJECT_SIZE = value;
		else if(!strcmp(item, "UPDATE_RATE")) UPDATE_RATE = value;
		else if(!strcmp(item, "TOP_THRESH")) TOP_THRESH = value;
	}

	fclose(file);

        printf("VERTICAL_THRESH: %d\n", VERTICAL_THRESH);	
        printf("HORIZONAL_THRESH: %d\n", HORIZONAL_THRESH);	
        printf("PIXEL_DIFF_THRESH: %d\n", PIXEL_DIFF_THRESH);	
        printf("PIXEL_DIFF_THRESH_DETECT: %d\n", PIXEL_DIFF_THRESH_DETECT);	
        printf("FIST_FRAME_NUM: %d\n", FIRST_FRAME_NUM);	
        printf("ROW_THRESH: %d\n", ROW_THRESH);	
        printf("BGD_THRESH: %d\n", BGD_THRESH);	
        printf("COUNTIN_THRESH: %d\n", COUNTIN_THRESH);	
        printf("OBJECT_SIZE: %d\n", OBJECT_SIZE);	
        printf("UPDATE_RATE: %d\n", UPDATE_RATE);
        printf("TOP_THRESH: %d\n", TOP_THRESH);	
}

unsigned char *imageDiff = NULL;
unsigned char *diffframe = NULL;
int horizontal[FRAME_HEIGHT];
int vertical[FRAME_WIDTH];
int coordinate[COOR_SIZE];
const int COL_START = 5;

//ÏÖÔÚµÄº¯Êý
void ABM_Init()
{
	printf("ABM Init.\n");
 	objectChannel0 = &object0;
 	objectChannel1 = &object1;

	objectChannel0->imageAverage = (unsigned char *) malloc(sizeof(unsigned char)*FRAME_WIDTH*FRAME_HEIGHT);
	objectChannel0->lastImage = (unsigned char *) malloc(sizeof(unsigned char)*FRAME_WIDTH*FRAME_HEIGHT);
	objectChannel1->imageAverage = (unsigned char *) malloc(sizeof(unsigned char)*FRAME_WIDTH*FRAME_HEIGHT);
	objectChannel1->lastImage = (unsigned char *) malloc(sizeof(unsigned char)*FRAME_WIDTH*FRAME_HEIGHT);
	if(imageDiff == NULL) imageDiff = (unsigned char *) malloc(sizeof(unsigned char)*FRAME_WIDTH*FRAME_HEIGHT);
	if(diffframe == NULL) diffframe = (unsigned char *) malloc(sizeof(unsigned char)*FRAME_WIDTH*FRAME_HEIGHT);

	if(imageDiff == NULL || diffframe == NULL
		|| objectChannel0->imageAverage == NULL || objectChannel0->lastImage == NULL
		|| objectChannel1->imageAverage == NULL || objectChannel1->lastImage == NULL)
	{
		printf("Malloc failed.\n");
		pthread_exit(0);
	}
}

void ABM_Reset()
{
	//objectChannel0 = Malloc(IMAGE, 1);
	objectChannel0->frame_num = 0;
	objectChannel0->recNum = 0;
	objectChannel0->coordinate = NULL;
	objectChannel0->row_thread = ROW_THRESH;
	objectChannel0->has_object = false;
	objectChannel0->channel = 0;
	objectChannel0->preNum = 1;
	objectChannel0->counter = 1;
	objectChannel0->updateFlag = false;
	objectChannel0->updateFlagBK = false;

	// objectChannel1 = Malloc(IMAGE, 1);
	objectChannel1->frame_num = 0;
	objectChannel1->recNum = 0;
	objectChannel1->coordinate = NULL;
	objectChannel1->row_thread = ROW_THRESH;
	objectChannel1->has_object = false;
	objectChannel1->channel = 1;
	objectChannel1->preNum = 1;
	objectChannel1->counter = 1;
	objectChannel1->updateFlag = false;
	objectChannel1->updateFlagBK = false;
}

void ABM_Deinit()
{
	printf("ABM Deinit.\n");
	if(imageDiff) free(imageDiff);
	if(diffframe) free(diffframe);
	if(objectChannel0->imageAverage) free(objectChannel0->imageAverage);
	if(objectChannel0->lastImage) free(objectChannel0->lastImage);
	if(objectChannel1->imageAverage) free(objectChannel1->imageAverage);
	if(objectChannel1->lastImage) free(objectChannel1->lastImage);
	imageDiff = NULL;
	diffframe = NULL;
	objectChannel0->lastImage = NULL;
	objectChannel0->imageAverage = NULL;
	objectChannel1->lastImage = NULL;
	objectChannel1->imageAverage = NULL;
}


void ABM_test4(unsigned char *Y_value, IMAGE* object)
{
	object->has_object = true;
	object->coordinate = coordinate;

	int rows = FRAME_HEIGHT, cols=FRAME_WIDTH;
	int tackle_rows = object->row_thread; 

	if(object->frame_num==0)
	{
		memset(object->imageAverage,0,tackle_rows*cols*sizeof(unsigned char));
		memset(object->lastImage,0,tackle_rows*cols*sizeof(unsigned char));
	}

    int coorsize=COOR_SIZE;
    int coorpos=0;              

	if (object->frame_num < 100 )
	{
		object->frame_num++;
	}

    	int i,j;
	bool contFlag = false;
	int sum = 0;

	if(object->frame_num >= 2){
		for( i=TOP_THRESH;i<tackle_rows;i++)
		{
			for( j=COL_START;j<cols;++j)
			{
				if(abs(Y_value[i*cols+j] - object->lastImage[i*cols+j]) > PIXEL_DIFF_THRESH)
					diffframe[i*cols+j] = 255;
				else diffframe[i*cols+j] = 0;
			}
		}
		
		// filter the noise pixels.
		int num = 0;
		for(i = COL_START+1; i < cols-1; i++)
                        for(j = TOP_THRESH+1; j < tackle_rows-1; j++)
                        {
                                num = 0;
                                if(diffframe[i-1+(j-1)*cols]) num++;
                                if(diffframe[i-1+(j)*cols]) num++;
                                if(diffframe[i-1+(j+1)*cols]) num++;
                                if(diffframe[i  +(j-1)*cols]) num++;
                                if(diffframe[i  +(j)*cols]) num++;
                                if(diffframe[i  +(j+1)*cols]) num++;
                                if(diffframe[i+1+(j-1)*cols]) num++;
                                if(diffframe[i+1+(j)*cols]) num++;
                                if(diffframe[i+1+(j+1)*cols]) num++;
                                if(num >= 9) sum++;
                        }
	}

	memcpy(object->lastImage, Y_value, tackle_rows*cols*sizeof(unsigned char));

	if(sum < BGD_THRESH) {
		object->counter++;
		contFlag = true;
	}else{
		object->updateFlag = false;
		object->updateFlagBK = false;
		object->counter = 1;
		printf("- - - - - - - - - - - - - - - - - - - - - > %d: frame diff sum: %d\n", (object == objectChannel0) ? 0 :1, sum);
	}

	if(object->counter >= COUNTIN_THRESH) {
		if((object->counter % COUNTIN_THRESH) == 0)
		{
			object->updateFlagBK = true;
			object->counter = COUNTIN_THRESH;
		}else
			object->updateFlagBK = false;

		object->updateFlag = true;
	}

	if(object->preNum <= FIRST_FRAME_NUM)
	{
		if(contFlag && object->updateFlag)
		{
			printf("-->preNum: %d\n", object->preNum);
			for( i=TOP_THRESH;i<tackle_rows;i++)
			{
				for( j=COL_START;j<cols;j++)
				{
					object->imageAverage[i*cols+j] = (Y_value[i*cols+j] + (object->preNum-1)*object->imageAverage[i*cols+j])/object->preNum;
				}
			}
			object->preNum++;
		}
		object->recNum=0;
		object->has_object=false;
		return;
	}

    for ( i=TOP_THRESH;i<tackle_rows;++i)
    {
        for ( j=COL_START;j<cols;++j)
        {
            imageDiff[i*cols+j]=abs(Y_value[i*cols+j]-object->imageAverage[i*cols+j]);
            imageDiff[i*cols+j]=imageDiff[i*cols+j]> PIXEL_DIFF_THRESH_DETECT ? 100 : 0;
        }
    }
   
    // vertical computation.
    memset(vertical,0,cols*sizeof(int));

    int flagVer=0, startVer[30]={0}, endVer[30]={0},temp=0,xVer=0;

	for( j=COL_START;j<cols;j++)
	{
	    for( i=TOP_THRESH;i<tackle_rows;i++)
	    {
	        vertical[j]+=imageDiff[j+i*cols];
	    }

	        if(vertical[j]>VERTICAL_THRESH && flagVer==0)
	        {
	            temp=j;
	            flagVer=1;
	        }
	
	        if((vertical[j]<=VERTICAL_THRESH && flagVer==1 && j<cols-1)||(j==cols-1 && flagVer==1))
	        {
	            if((j-temp)>OBJECT_SIZE && xVer < 30)
	            {
	                startVer[xVer]=temp;
	                endVer[xVer]=j;
	                xVer++;
	            }
	            flagVer=0;
	        }
	}

   // horizonal computation.
    memset(horizontal,0,tackle_rows*sizeof(int));

    int startHor[30]={0},endHor[30]={0},flagHor=0,xHor=0;

    int ver;
	for( ver=0;ver<xVer;ver++)
	{
		xHor = 0;
		for( i=TOP_THRESH;i<tackle_rows;i++)
		{
		    for( j=startVer[ver];j<endVer[ver];j++)
		    {
                	horizontal[i]+=imageDiff[i*cols+j];
		    }

			if((horizontal[i]>HORIZONAL_THRESH) && (flagHor==0))
			{
				temp=i;
				flagHor=1;
			}

			if(((horizontal[i]<=HORIZONAL_THRESH) && (flagHor==1) && (i<(tackle_rows-1)))||((i==(tackle_rows-1)) && (flagHor==1)))
			{

		                if((i-temp)>OBJECT_SIZE && xHor < 30)
		                {
		                    startHor[xHor]=temp;
		                    endHor[xHor]=i;
		
		                    xHor++;
		                }
		
				flagHor=0;
			}
		}

		if((xHor > 0) && (coorpos + 4) < coorsize) {
		    	coordinate[coorpos++]=startVer[ver];
		    	coordinate[coorpos++]=startHor[0];
		    	coordinate[coorpos++]=endVer[ver];
		    	coordinate[coorpos++]=endHor[xHor-1];
		}
        	memset(horizontal,0,tackle_rows*sizeof(int));
	}

    object->recNum=coorpos; 

    // update background model.
    if(object->recNum == 0 || object->updateFlagBK)
	{
		int update_rate = (object->updateFlagBK ? 8 : 1)*UPDATE_RATE;
		printf("-> update\n");
		object->has_object = false; 
		 for ( i=TOP_THRESH;i<tackle_rows;++i)
        	{
			for ( j=COL_START;j<cols;++j)
			{
				object->imageAverage[i*cols+j]=(object->imageAverage[i*cols+j]*(100-update_rate) + Y_value[i*cols+j]*update_rate)/100;
			}
        	}	
	}
}
