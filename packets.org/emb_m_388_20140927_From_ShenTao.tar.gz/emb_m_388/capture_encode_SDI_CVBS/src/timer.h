#ifndef _TIMER_H_
#define _TIMER_H_

#include <time.h>
#if defined(_TMS320C6X)
#elif defined(__GNUC__)
  #include <sys/time.h>
#endif

typedef int timestamp_t;

static int get_timestamp ()
{
  struct timeval now;
  gettimeofday (&now, NULL);
  return  now.tv_usec/1000 + (int)now.tv_sec * 1000;
}

#endif
