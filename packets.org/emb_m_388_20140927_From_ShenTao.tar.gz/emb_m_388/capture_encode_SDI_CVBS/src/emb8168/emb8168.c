/*
 * emb8168.c
 *
 *  Created on: Apr 26, 2013
 *      Author: spark
 */

#include <pthread.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>

#include <sys/stat.h>
#include <fcntl.h> 
#include <termios.h>
#include <errno.h>
/*--------------------- system and platform files ----------------------------*/
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <xdc/std.h>
#include <memory.h>
#include <getopt.h>

/*-------------------------program files -------------------------------------*/
#include "ti/omx/interfaces/openMaxv11/OMX_Core.h"
#include "ti/omx/interfaces/openMaxv11/OMX_Component.h"
#include "OMX_TI_Common.h"
#include "OMX_Video.h"
#include "OMX_TI_Video.h"
#include "ilclient.h"
#include "ilclient_utils.h"

#include "common.h"
#include "cmem.h"

#include <ti/omx/omxutils/omx_utils.h>

#define thread_analyze CVBS_Example
//#define thread_venc Capture_Encode_Example

#define debug_printf(x...) printf(x)

OMX_BOOL gILClientExit = OMX_FALSE;
OMX_BOOL gILCVBSInit = OMX_FALSE;
OMX_BOOL gILVencClientExit = OMX_FALSE;

t_cfg_param g_cfg_param;

extern void * CVBS_Example(void * arg);
extern void * Capture_Encode_Example(void * arg);

//This function is usually for debug purpose
void MsgDump(char *msg)
{
	char buf[CMD_BUFSIZE];
	unsigned int len;
	char *ptr, *version, *command, *data_len;

	debug_printf("\n");
	debug_printf("******************************************************************\n");
	//debug_printf("\n");
	version = msg;
	command = &msg[2];
	data_len = &msg[6];
	ptr = &msg[10];

	memcpy(buf, version, VERSION_SIZE);
	buf[VERSION_SIZE]='\0';
	if(strcmp(buf, "01")){
		debug_printf("Wrong msg format\n");
		return;
	}
	debug_printf("Msg version: %s\n", buf);

	memcpy(buf, command, CMD_SIZE);
	buf[CMD_SIZE] = '\0';
	debug_printf("Command: %s\n", buf);

	char2hex(data_len, &len, DATA_LEN_SIZE);
	debug_printf("Total length of attributes: %d(%x)\n", len, len);

	while(len){
		unsigned int name_len, value_len;

		char2hex(ptr, &name_len, 1);
		ptr++;

		char2hex(ptr, &value_len, 4);
		ptr += 4;

		memcpy(buf, ptr, name_len);
		buf[name_len] = '\0';
		debug_printf("%s(in length of %d): ", buf, name_len);
		ptr += name_len;

		memcpy(buf, ptr, value_len);
		buf[value_len] = '\0';
		ptr += value_len;
		debug_printf("%s(in length of %d)\n", buf, value_len);

		len -= (ARG_NAME_LEN_SIZE + ARG_LEN_SIZE + name_len + value_len);
	}
	//debug_printf("\n");
	debug_printf("******************************************************************\n");
	debug_printf("\n");
}

//Retrieve a complete message from sock and put it in the buffer
int getMsg(int sock, char* buf)
{
	int ret;
	unsigned len;

	ret = recv(sock, buf, 10, MSG_PEEK);

	if(ret<=0){
		return -1;
	}

	if(ret<10){
		return 0;
	}

	char2hex(&buf[6], &len, DATA_LEN_SIZE);
	len += PACKET_HEADER_SIZE;

	ret = recv(sock, buf, len, MSG_PEEK);

	if(ret<len){
		return 0;
	}

	recv(sock, buf, len, 0);

	return len;
}

/* packn send for datafifo */
// void SendImageFifo(char *buf, unsigned int width, unsigned int height, char* type, t_venc *p_venc)
// {
//     unsigned int len = width*height;

//     //build message
//     h_cmd Msg;

//     fill_cmd_header_h(&Msg, COMMAND_INTERNAL_CMD);

//     add_attr_char_h(&Msg,"UCImgType", type);
//     add_attr_int_h(&Msg, "Width", width);
//     add_attr_int_h(&Msg, "Height", height);
//     add_attr_bin_h(&Msg, "RawBytes", buf, len);

//     //send the message to socket
//     size_t size;
//     char2hex(Msg.data_len, &size, DATA_LEN_SIZE);
//     size += PACKET_HEADER_SIZE;
//     int flags = FRAME_FLAG_NEWFRAME | FRAME_FLAG_FRAMEEND;
//     datafifo_producer_data_add(&p_venc->uci_producer_fifo, (unsigned char *)Msg.fullbuf, (int)size, flags, 0);
//     //sleep(1);
// }

/* packn send for datafifo */
/* format : 
		typedef struct s_uci_packet
		{
		    int uci_type;
		    int width;
		    int height;
		    int reserve;
		    char uic_buf[1920*1080];
		}t_uci_packet;
*/
void SendImageFifo(unsigned char *buf, unsigned int width, unsigned int height, int type, t_venc *p_venc)
{
    unsigned int len = width*height;
    unsigned int size = 16 + len;
    //build message
    unsigned char* Msg = malloc(size);

    int *ptrInt = (int *)Msg;
    ptrInt[0] = type;
    ptrInt[1] = width;
    ptrInt[2] = height;
    ptrInt[3] = 0;

    memcpy(&Msg[16], buf, height*width);

    int flags = FRAME_FLAG_NEWFRAME | FRAME_FLAG_FRAMEEND;
    datafifo_producer_data_add(&p_venc->uci_producer_fifo, Msg, size, flags, 0);
    free(Msg);
    //sleep(1);
}

extern int frameCounter;
void * thread_venc(void * arg)
{
	t_venc *p_venc = (t_venc *)arg;
	int state_flag = 0;
	pthread_t pt_Capture_Encode_Example_id;

	int ret = -1;

 	while(1){
		if (gILClientExit == OMX_TRUE){
			break;
		}
 		if(datafifo_head(&p_venc->consumer_fifo)){
 			debug_printf("thread_venc receive message\n");

 			char *Msg = datafifo_head(&p_venc->consumer_fifo)->arg.data;
 			char cmd[CMD_SIZE+1];
 			unsigned int len;
 			char *ptr;

 			memcpy(cmd, &Msg[VERSION_SIZE], CMD_SIZE);
 			cmd[CMD_SIZE] = '\0';

            char2hex(&Msg[VERSION_SIZE+CMD_SIZE], &len, DATA_LEN_SIZE);
            //debug_printf("Total length of attributes: %d(%x)\n", len, len);

            ptr = &Msg[PACKET_HEADER_SIZE];

            if(!strcmp(cmd, COMMAND_GETDATA)){
            	while(len){
            		unsigned int name_len, value_len;
            		char attr_name[16];
            		char attr_value[1536];

            		char2hex(ptr, &name_len, 1);
            		ptr++;

            		char2hex(ptr, &value_len, 4);
            		ptr += 4;

            		memcpy(attr_name, ptr, name_len);
            		attr_name[name_len] = '\0';
            		ptr += name_len;

            		memcpy(attr_value, ptr, value_len);
            		attr_value[value_len] = '\0';
            		ptr += value_len;

            		len -= (ARG_NAME_LEN_SIZE + ARG_LEN_SIZE + name_len + value_len);

            		if(!strcmp(attr_name, "Type")){
            			state_flag = (!strcmp(attr_value, "All")) ? 1 : 0;
            			if(state_flag){
					frameCounter = 0;
            				ret = pthread_create(&pt_Capture_Encode_Example_id, NULL, Capture_Encode_Example, arg);
            				if(ret<0){
            					debug_printf("create thread_Capture_Encode_Example failed\n");
            					exit(0);
            				}
            			}
            			else{
            				if(ret>=0){
                				gILVencClientExit = OMX_TRUE;
                				pthread_join(pt_Capture_Encode_Example_id, NULL);
                				ret = -1;
            				}
            			}
            		}
            	}
            }

            datafifo_consumer_remove_head(&p_venc->consumer_fifo);
            continue;
 		}

 		usleep(1000);
	}
	if(ret >= 0){
		pthread_join(pt_Capture_Encode_Example_id, NULL);
		ret = -1;
	}
	pthread_exit(0);
}

// void * thread_aenc(void * arg)
// {
// 	t_aenc *p_aenc = (t_aenc *)arg;

// 	while(1){
// 		if(datafifo_head(&p_aenc->consumer_fifo)){
// 			debug_printf("thread_aenc receive message\n");
// 			datafifo_consumer_remove_head(&p_aenc->consumer_fifo);
// 			continue;
// 		}
// 		usleep(1000);
// 	}
// 	pthread_exit(0);
//}

// void * thread_analyze(void * arg)
// {
// 	t_analyze *p_analyze = (t_analyze *)arg;

// 	while(1){
// 		if(datafifo_head(&p_analyze->consumer_fifo)){
// 			debug_printf("thread_analyze receive message\n");
// 			datafifo_consumer_remove_head(&p_analyze->consumer_fifo);
// 			continue;
// 		}
// 		usleep(1000);
// 	}
// 	pthread_exit(0);
// }

void CamhldRsp(char *byte, unsigned int len, t_uart *p_uart)
{
	t_cmd cmd;
	size_t size;
	int flags;

	fill_cmd_header(&cmd, COMMAND_BYP_RSP);
	add_attr_int(&cmd, "Channel", 0);
	add_attr_bin(&cmd, "RawBytes", byte, len);
	debug_printf("Msg: %s\n", cmd.fullbuf);
	//debug_printf("Msg: %s\n", cmd.data);
	char2hex(cmd.data_len, &size, DATA_LEN_SIZE);
	size += PACKET_HEADER_SIZE;

	flags = FRAME_FLAG_NEWFRAME | FRAME_FLAG_FRAMEEND;
	datafifo_producer_data_add(&p_uart->producer_fifo, (unsigned char *)cmd.fullbuf, (int)size, flags, 0);
	//debug_printf("camholde bypass ack send\n");
}

void CamhldAck(t_uart *p_uart)
{
	char byte[] = {0x90, 0x41, 0xff};
	CamhldRsp(byte, 3, p_uart);
}

void CamhldCpl(t_uart *p_uart)
{
	char byte[] = {0x90, 0x51, 0xff};
	CamhldRsp(byte, 3, p_uart);
}

int OpenPort()
{
	int fd;
    struct termios opt; 
    
    fd = open("/dev/ttyO0", O_RDWR | O_NOCTTY);    //默认为阻塞读方式
    fcntl(fd, F_SETFL, FNDELAY);

    if(fd == -1)
    {
        perror("open serial 0\n");
        exit(0);
    }

    tcgetattr(fd, &opt);      
    cfsetispeed(&opt, B9600);
    cfsetospeed(&opt, B9600);
    
    if(tcsetattr(fd, TCSANOW, &opt) != 0 )
    {     
       perror("tcsetattr error");
       return -1;
    }
    
    /* data bits */
    opt.c_cflag &= ~CSIZE;  
    opt.c_cflag |= CS8;

    /* parity bits */
    opt.c_cflag &= ~PARENB; 
    opt.c_iflag &= ~INPCK;

    /* stop bits */
    opt.c_cflag &= ~CSTOPB; 

    opt.c_cflag |= (CLOCAL | CREAD);
    opt.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
    opt.c_oflag &= ~OPOST;
    opt.c_oflag &= ~(ONLCR | OCRNL);
 
    opt.c_iflag &= ~(ICRNL | INLCR);
    opt.c_iflag &= ~(IXON | IXOFF | IXANY);
    
    tcflush(fd, TCIOFLUSH);
 
    printf("configure complete\n");
    
    if(tcsetattr(fd, TCSANOW, &opt) != 0)
    {
        perror("serial error");
        return -1;
    }
    printf("port init complete\n");

    char *buffer = "test the port\n";
	write(fd, buffer, strlen(buffer));

	return fd;
}

int ReadPort(int fd, char *buf)
{
	int retval;
	fd_set rfds;
	struct timeval tv;

	int ret = 0;

	tv.tv_sec = 0;//set the rcv wait time
	tv.tv_usec = 500000;

    FD_ZERO(&rfds);
	FD_SET(fd,&rfds);

	retval = select(fd+1,&rfds,NULL,NULL,&tv);

    if(retval > 0)
    {
    	if(FD_ISSET(fd,&rfds))
    	{
    		ret = read(fd,buf,16);
    	}

    	return ret > 0 ? ret : 0;
	}
	else
		return -1;
}

void * thread_uart(void * arg)
{
	t_uart *p_uart = (t_uart *)arg;

	int fd = OpenPort();

 	while(1){
		if (gILClientExit == OMX_TRUE){
			break;
		}
		if(datafifo_head(&p_uart->consumer_fifo)){
			debug_printf("thread_uart receive message\n");

			char *Msg = datafifo_head(&p_uart->consumer_fifo)->arg.data;
	        char cmd[CMD_SIZE+1];
	        unsigned int len;
	        char *ptr;

	        memcpy(cmd, &Msg[VERSION_SIZE], CMD_SIZE);
	        cmd[CMD_SIZE] = '\0';

	        char2hex(&Msg[VERSION_SIZE+CMD_SIZE], &len, DATA_LEN_SIZE);
	        //debug_printf("Total length of attributes: %d(%x)\n", len, len);

	        ptr = &Msg[PACKET_HEADER_SIZE];

        	if(!strcmp(cmd, COMMAND_CAMHLD_BYPASS)){
	            while(len){
	                unsigned int name_len, value_len;
	                char attr_name[16];
	                char attr_value[1536];

	                char2hex(ptr, &name_len, 1);
	                ptr++;

	                char2hex(ptr, &value_len, 4);
	                ptr += 4;

	                memcpy(attr_name, ptr, name_len);
	                attr_name[name_len] = '\0';
	                ptr += name_len;

	                memcpy(attr_value, ptr, value_len);
	                attr_value[value_len] = '\0';
	                ptr += value_len;

	                len -= (ARG_NAME_LEN_SIZE + ARG_LEN_SIZE + name_len + value_len);

	                if(!strcmp(attr_name, "RawBytes")){
	                	write(fd, attr_value, value_len);
	                }
	            }
        	}

			datafifo_consumer_remove_head(&p_uart->consumer_fifo);
			//continue;
		}

		char cmd[16];
	    int len = 0;

		if((len = ReadPort(fd, cmd)) > 0)
		{
			debug_printf("get cmd (%d): %s\n",len, cmd);
			CamhldRsp(cmd, len, p_uart);
		}

		//usleep(10000);
	}
	pthread_exit(0);
}

void HandleMsg(t_hostctrl *p_hostctrl, char * Msg)
{
	MsgDump(Msg);//now just dump, test purpose

	char cmd[CMD_SIZE+1];
	unsigned int len;
	//char *ptr;

	memcpy(cmd, &Msg[VERSION_SIZE], CMD_SIZE);
	cmd[CMD_SIZE] = '\0';

	char2hex(&Msg[VERSION_SIZE+CMD_SIZE], &len, DATA_LEN_SIZE);
	//debug_printf("Total length of attributes: %d(%x)\n", len, len);

	int flags;

	len += PACKET_HEADER_SIZE;
	flags = FRAME_FLAG_NEWFRAME | FRAME_FLAG_FRAMEEND;
#if 0
	if(!strcmp(cmd, COMMAND_CAMHLD_BYPASS)){
		//debug_printf("COMMAND_CAMHLD_BYPASS received\n");
		datafifo_producer_data_add(&p_hostctrl->uart_producer_fifo, (unsigned char *)Msg, (int)len, flags, 0);
	}
#endif
	 if(!strcmp(cmd, COMMAND_GETDATA)){
		datafifo_producer_data_add(&p_hostctrl->ctrl_producer_fifo, (unsigned char *)Msg, (int)len, flags, 0);
	}
	
	if(!strcmp(cmd, COMMAND_CONFIG)){
                int body_len = len - PACKET_HEADER_SIZE;
        	char *ptr = &Msg[PACKET_HEADER_SIZE];
                while(body_len){
                unsigned int name_len, value_len;
                char attr_name[16];
                char attr_value[1536];

                char2hex(ptr, &name_len, 1);
                ptr++;

                char2hex(ptr, &value_len, 4);
                ptr += 4;

                memcpy(attr_name, ptr, name_len);
                attr_name[name_len] = '\0';
                ptr += name_len;

                memcpy(attr_value, ptr, value_len);
                attr_value[value_len] = '\0';
                ptr += value_len;

                body_len -= (ARG_NAME_LEN_SIZE + ARG_LEN_SIZE + name_len + value_len);

                if(!strcmp(attr_name, "FrameWidth")){
                        char2hex(attr_value, &g_cfg_param.frame_width, value_len);
                }

                if(!strcmp(attr_name, "FrameHeight")){
                        char2hex(attr_value, &g_cfg_param.frame_height, value_len);
                }

                if(!strcmp(attr_name, "FrameRate")){
                        char2hex(attr_value, &g_cfg_param.frame_rate, value_len);
                }

                if(!strcmp(attr_name, "BitRate")){
                        char2hex(attr_value, &g_cfg_param.bit_rate, value_len);
                }

                if(!strcmp(attr_name, "LBitRate")){
                        char2hex(attr_value, &g_cfg_param.lbit_rate, value_len);
                }
                }
        }

}

void helloA(int sock)
{
	t_cmd cmd;
	size_t size;
	fill_cmd_header(&cmd, COMMAND_HELLO);
	add_attr_int(&cmd, "BrdIdx", 0);
	add_attr_char(&cmd, "BrdId", "90b11c8f47e7");//To do: replace the "90b11c8f47e7" with the real one
	add_attr_char(&cmd, "DevCfg", "{1:000000000000}{2:000000000000}{3:000000000000}");
	debug_printf("Msg: %s\n", cmd.fullbuf);
	//debug_printf("Msg: %s\n", cmd.data);
	char2hex(cmd.data_len, &size, DATA_LEN_SIZE);
	size += PACKET_HEADER_SIZE;
	send(sock, cmd.fullbuf, size, 0);
	debug_printf("helloA msg sent\n");
}

t_cmem_buf_desc g_vgabuf[2];
t_cmem_buf_desc g_yuvbuf;

int main(int argc, char **argv)
{
	if(argc!=3){
		debug_printf("use: %s IP_addr Port\n", argv[0]);
		return -1;
	}

	t_venc venc;
	t_analyze analyze;
	t_uart uart;
	t_hostctrl hostctrl;

	pthread_t pt_venc_id;
	pthread_t pt_analyze_id;
	pthread_t pt_uart_id;

	//cmem init and memory allocation
    int version;
    CMEM_BlockAttrs attrs;

    if (CMEM_init() == -1) {
        fprintf(stderr, "Failed to initialize CMEM\n");
        exit(EXIT_FAILURE);
    }

    version = CMEM_getVersion();
    if (version == -1) {
        fprintf(stderr, "Failed to retrieve CMEM version\n");
    }
    printf("CMEM version = 0x%x\n", version);

    if (CMEM_getBlockAttrs(0, &attrs) == -1) {
        fprintf(stderr, "Failed to retrieve CMEM memory block 0 bounds\n");
    }
    printf("CMEM memory block 0: phys start = 0x%lx, size = 0x%x\n",
           attrs.phys_base, attrs.size);

    if (CMEM_getBlockAttrs(1, &attrs) == -1) {
        fprintf(stderr, "Failed to retrieve CMEM memory block 1 bounds\n");
    }
    printf("CMEM memory block 1: phys start = 0x%lx, size = 0x%x\n",
           attrs.phys_base, attrs.size);

    CMEM_AllocParams params;


    int i;
    for(i=0; i<2; i++){
        params = CMEM_DEFAULTPARAMS;
        params.flags = CMEM_CACHED;
        g_vgabuf[i].vir_addr = CMEM_alloc(0x400000, &params);
        if(!g_vgabuf[i].vir_addr){
        	printf("CMEM_alloc for g_vgabuf[%d] failed\n",i);
        	exit(0);
        }
        g_vgabuf[i].phy_addr = CMEM_getPhys(g_vgabuf[i].vir_addr);
        if(!g_vgabuf[i].phy_addr){
        	printf("CMEM_getPhys of g_vgabuf[%d] failed\n", i);
        	exit(0);
        }
    }

    params = CMEM_DEFAULTPARAMS;
    params.flags = CMEM_CACHED;
    g_yuvbuf.vir_addr = CMEM_alloc(0x400000, &params);
    if(!g_yuvbuf.vir_addr){
    	printf("CMEM_alloc for g_yuvbuf failed\n");
    	exit(0);
    }

    g_yuvbuf.phy_addr = CMEM_getPhys(g_yuvbuf.vir_addr);
    if(!g_yuvbuf.phy_addr){
    	printf("CMEM_getPhys of g_yuvbuf failed\n");
    	exit(0);
    }

    g_cfg_param.frame_width = 1920;
    g_cfg_param.frame_height = 1080;
    g_cfg_param.frame_rate = 30;
    g_cfg_param.bit_rate = 1024;
    g_cfg_param.lbit_rate = 1024;

	//create fifo graph
	datafifo_init(&hostctrl.ctrl_producer_fifo, CMD_BUFSIZE, 3);
	datafifo_init(&hostctrl.uart_producer_fifo, CMD_BUFSIZE, 3);
	datafifo_init(&venc.cvd_producer_fifo, CMD_BUFSIZE, 1000);
	datafifo_init(&venc.uci_producer_fifo, CMD_BUFSIZE, 100);
	datafifo_init(&venc.cvbs_producer_fifo,256*1024,3);//add for send uci data to host
	datafifo_init(&analyze.producer_fifo, CMD_BUFSIZE, 3);
	datafifo_init(&uart.producer_fifo, CMD_BUFSIZE, 10);

	datafifo_init(&hostctrl.consumer_fifo, 0, 2000);
	datafifo_connect(&venc.cvd_producer_fifo, &hostctrl.consumer_fifo);
	datafifo_connect(&venc.uci_producer_fifo, &hostctrl.consumer_fifo);//add for send uci data to host
	datafifo_connect(&analyze.producer_fifo, &hostctrl.consumer_fifo);
	datafifo_connect(&uart.producer_fifo, &hostctrl.consumer_fifo);

	datafifo_init(&venc.consumer_fifo, 0, 3);
	datafifo_connect(&hostctrl.ctrl_producer_fifo, &venc.consumer_fifo);

	datafifo_init(&analyze.consumer_fifo, 0, 9);
	datafifo_connect(&venc.cvbs_producer_fifo, &analyze.consumer_fifo);

	datafifo_init(&uart.consumer_fifo, 0, 3);
	datafifo_connect(&hostctrl.uart_producer_fifo, &uart.consumer_fifo);

	/* app init/deinit */
	AppInit();

	//create the threads
	int ret;

	ret = pthread_create(&pt_venc_id, NULL, thread_venc, (void *)&venc);
	if(ret<0){
		debug_printf("create thread_venc failed\n");
		exit(0);
	}

#if 1
	ret = pthread_create(&pt_analyze_id, NULL, thread_analyze, (void *)&analyze);
	if(ret<0){
		debug_printf("create thread_analyze failed\n");
		exit(0);
	}
#endif

#if 0
	ret = pthread_create(&pt_uart_id, NULL, thread_uart, (void *)&uart);
	if(ret<0){
		debug_printf("create thread_uart failed\n");
		exit(0);
	}
#endif

	//init the socket parameters
	int port = atoi(argv[2]);
	//int sock_host;
	struct sockaddr_in cli;
	fd_set fdsr;


	while(1){
		if (gILClientExit == OMX_TRUE) goto EXIT1;
		cli.sin_family = AF_INET;
		cli.sin_port = htons(port);
		cli.sin_addr.s_addr = inet_addr(argv[1]);

		hostctrl.sock_host = socket(AF_INET, SOCK_STREAM, 0);
		if(hostctrl.sock_host<0){
			debug_printf("open socket error\n");
			return -1;
		}

		debug_printf("connecting to server...");

		if(connect(hostctrl.sock_host, (struct sockaddr*)&cli, sizeof(cli))<0){
			debug_printf("connect error\n");
			close(hostctrl.sock_host);
			sleep(3);
			continue;
		}
		debug_printf("connected\n");
		//helloA(hostctrl.sock_host);//register to the host



		while(1){
			int busy;
			busy = 0;
			//send data
			if (gILClientExit == OMX_TRUE) goto EXIT;

			if(datafifo_head(&hostctrl.consumer_fifo)){
				send(hostctrl.sock_host, datafifo_head(&hostctrl.consumer_fifo)->arg.data, datafifo_head(&hostctrl.consumer_fifo)->arg.len, 0);
				datafifo_consumer_remove_head(&hostctrl.consumer_fifo);
			//	debug_printf("send data\n");
				//continue;
				busy++;
			}

			//receive data
			FD_ZERO(&fdsr);
			FD_SET(hostctrl.sock_host, &fdsr);

			struct timeval tv;

			tv.tv_sec = 0;
			tv.tv_usec = 0;

			ret = select(hostctrl.sock_host+1, &fdsr, NULL, NULL, &tv);

			if(ret<0){
				debug_printf("select error\n");
			}

			if(ret==0){
				//debug_printf("select timeout\n");
				//continue;
			}

			if(FD_ISSET(hostctrl.sock_host, &fdsr)){
				debug_printf("socket readable\n");
				char Msg[CMD_BUFSIZE];
				int MsgGot;

				MsgGot = getMsg(hostctrl.sock_host, Msg);

				if(MsgGot<0){
					debug_printf("disconnected with host\n");
					close(hostctrl.sock_host);
					printf("host socket closed.\n");
					//fake the stop message and put it to the control message producer fifo
					size_t size;
					t_cmd outmsg;
					int flags;

					fill_cmd_header(&outmsg, COMMAND_GETDATA);
					add_attr_char(&outmsg, "Type", "None");

					char2hex(outmsg.data_len, &size, DATA_LEN_SIZE);
					size += (VERSION_SIZE + CMD_SIZE + DATA_LEN_SIZE);

					flags = FRAME_FLAG_NEWFRAME | FRAME_FLAG_FRAMEEND;
					datafifo_producer_data_add(&hostctrl.ctrl_producer_fifo, (unsigned char *)outmsg.fullbuf, (int)size, flags, 0);

					printf("host socket closed.\n");
					//drain the consumer when waiting for reconnecting to host
					int i;
					for(i=0; i<3*1000; i++){
						if(datafifo_head(&hostctrl.consumer_fifo)){
							datafifo_consumer_remove_head(&hostctrl.consumer_fifo);
						}
						usleep(1000);
					}
					printf("host socket closed.\n");
					break;
				}

				if(MsgGot == 0){
					//debug_printf("uncompleted message\n");
					//usleep(1000);
					//continue;
				}

				//handle the message here
				if(MsgGot>0){
					HandleMsg(&hostctrl, Msg);
					//continue;
					busy++;
				}
			}
			//sleep(1);//test purpose
			//usleep(1000);
			if(!busy){
				usleep(1000);
			}
		}
	}

EXIT:
	close(hostctrl.sock_host);
EXIT1:
	pthread_join(pt_analyze_id, NULL);
	printf("analyze joined\n");
	pthread_join(pt_venc_id, NULL);
	printf("venc joined\n");
#if 0
	pthread_join(pt_uart_id, NULL);
	printf("uart joined\n");
#endif
	AppDeinit();

	//cmem memory free and deinit
	for(i=0; i<2; i++){
		CMEM_free(g_vgabuf[i].vir_addr, NULL);
	}
	CMEM_free(g_yuvbuf.vir_addr, NULL);

    if (CMEM_exit() < 0) {
        fprintf(stderr, "Failed to finalize the CMEM module\n");
    }
	return 0;
}
