#include <stdlib.h>
#include <stdio.h>
#include <memory.h>

//定义了一个结构体
typedef int bool;

#define true 1
#define false 0

#define FRAME_WIDTH 720
#define FRAME_HEIGHT 288
#define COOR_SIZE 200

extern int  VERTICAL_THRESH;
extern int  HORIZONAL_THRESH;
extern int  PIXEL_DIFF_THRESH;
extern int  PIXEL_DIFF_THRESH_DETECT;
extern int  FIRST_FRAME_NUM;
extern int  ROW_THRESH;
extern int  BGD_THRESH;
extern int  COUNTIN_THRESH;
extern int  OBJECT_SIZE;
extern int  UPDATE_RATE;//must be in (0,100)
extern int 	TOP_THRESH;

typedef struct
{
	int frame_num;    //ÕâžöÊÇÍ³ŒÆÖ¡ÊýµÄ£¬Ç°50£š¿ÉÖØÐÂÉè¶š£©œö×÷±³Ÿ°ŒÓÈš£¬ºóÃæÇóÈ¡Ä¿±ê
	int recNum;   //ÕâžöÎÒÒªŸÀÕýÒ»ÏÂ£¬²»ÊÇ¿òµÄžöÊý£¬¶øÊÇ×ø±êµÄ×ÜžöÊý£¬±ÈÈç1žö¿ò£¬recNumŸÍÊÇ4£¬Áœžö¿òrecNumŸÍÊÇ8
	unsigned char *imageAverage;//ŽæŽ¢±³Ÿ°ÍŒÆ¬
	unsigned char *lastImage;
	int *coordinate;   //ŽæŽ¢¿òµÄžöÊý£¬×óÉÏµÄx£¬×óÉÏµÄy,ÓÒÏÂµÄx£¬ÓÒÏÂµÄy
	int row_thread;   //ŸµÍ·µÄÃÅÏÞÖµ
	int has_object;   //ÊÇ·ñÓÐÄ¿±ê
    	int channel;       //ÍšµÀ
	int preNum;
	int counter;
	bool updateFlag;
	bool updateFlagBK;
//	IMAGE()
//	{
//		frame_num=0;
//		recNum=0;
//		coordinate=NULL;
//		imageAverage=NULL;
//		row_thread=0;
//		has_object=false;
//                channel=0;
//	}
} IMAGE;

extern IMAGE* objectChannel0;
extern IMAGE* objectChannel1;

extern void ParseArgs(const char *args_file);
extern void ABM_Init();
extern void ABM_Reset();
extern void ABM_Deinit();
extern void ABM_test4(unsigned char *Y_value, IMAGE* object);
