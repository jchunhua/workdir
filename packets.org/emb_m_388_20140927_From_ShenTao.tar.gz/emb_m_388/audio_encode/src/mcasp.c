/*
 * mcasp.h
 *
 * ============================================================================
 * Copyright (C) 2014 Seacean Electronics Ltd
 *
 * Auther: TONY SHEN <tony.shen@seacean.com.cn>
 *
 * Use of this software is controlled by the terms and conditions found in the
 * license agreement under which this software has been supplied or provided.
 * ============================================================================
*/

#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include "mcasp.h"

#define DEVICE_NAME	"/dev/mcasp_recv"
#define FIFO_DEPTH	1024*4

Mcasp_Handle mcasp_init()
{
	int fd, i;
	struct mcasp_reqbuf req;
	struct mcasp_querybuf bufinfo;
	mcasp_t* mcasp_data;
	void* buf_ptr;

	mcasp_data = (mcasp_t*)malloc(sizeof(mcasp_t));
	if (mcasp_data == NULL) {
		perror("Failed to allocate memory.\n");
		return NULL;
	}
	
	fd = open(DEVICE_NAME, O_RDWR);
	if (fd == -1) {
		perror("Failed to open device "DEVICE_NAME"\n");
		free(mcasp_data);
		return NULL;
	}
	mcasp_data->fd = fd;
	req.num = BUF_NUM;
	req.buf_size = FIFO_DEPTH;
	if (ioctl(fd, MCASPRECV_REQBUF, &req) < 0) {
		perror("Failed to request memory.\n");
		free(mcasp_data);
		close(fd);
		return NULL;
	}
	
	for (i = 0; i < BUF_NUM; i++) {
		bufinfo.id = i;
		if (ioctl(fd, MCASPRECV_QUERYBUF, &bufinfo) < 0) {
			perror("Failed to query buffer information.\n");
			free(mcasp_data);
			close(fd);
			return NULL;
		}
		buf_ptr = mmap(NULL,
				FIFO_DEPTH, PROT_READ | PROT_WRITE,
				MAP_SHARED, fd,
				bufinfo.dma_addr);
		if (buf_ptr == MAP_FAILED) {
			perror("Failed to mmap memory.\n");
			free(mcasp_data);
			close(fd);
			return NULL;
		}
		mcasp_data->buf_ptr[i] = buf_ptr;
	}

		
	ioctl(fd, MCASPRECV_STREAMON, NULL);

	return mcasp_data;
}

int mcasp_getdata(Mcasp_Handle mcaspHandle, unsigned int* data)
{
	struct mcasp_querybuf bufinfo;
	unsigned int *ptr=NULL, *dst=NULL;
	int ret;

	ret = ioctl(mcaspHandle->fd, MCASPRECV_DQBUF, &bufinfo);
	if (ret < 0) {
		fprintf(stderr, "no data.\n");
		return 0;
	}

	ptr = mcaspHandle->buf_ptr[bufinfo.id];

	memcpy(data, ptr, FIFO_DEPTH);

	ioctl(mcaspHandle->fd, MCASPRECV_QBUF, &bufinfo);

	return ptr[0];
}

void mcasp_close(Mcasp_Handle mcaspHandle)
{
	int i;

	ioctl(mcaspHandle->fd, MCASPRECV_STREAMOFF, NULL);
	for (i = 0; i < BUF_NUM; i++) {
		munmap(mcaspHandle->buf_ptr[i], FIFO_DEPTH);
	}
	close(mcaspHandle->fd);
	free(mcaspHandle);
}
