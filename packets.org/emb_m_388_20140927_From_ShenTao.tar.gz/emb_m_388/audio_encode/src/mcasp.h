/*
 * mcasp.h
 *
 * ============================================================================
 * Copyright (C) 2014 Seacean Electronics Ltd
 *
 * Auther: TONY SHEN <tony.shen@seacean.com.cn>
 *
 * Use of this software is controlled by the terms and conditions found in the
 * license agreement under which this software has been supplied or provided.
 * ============================================================================
 */

#ifndef __MCASP_H
#define __MCASP_H

#define BUF_NUM         1024

#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>


#define MCASPRECV_IOC_BASE              'I'
#define MCASPRECV_IOC_MAXNR             7

#define MCASPRECV_REQBUF                _IOWR(MCASPRECV_IOC_BASE, 1, struct mcasp_reqbuf)
#define MCASPRECV_QUERYBUF              _IOWR(MCASPRECV_IOC_BASE, 2, struct mcasp_querybuf)
#define MCASPRECV_QBUF                  _IOWR(MCASPRECV_IOC_BASE, 3, struct mcasp_querybuf)
#define MCASPRECV_DQBUF                 _IOWR(MCASPRECV_IOC_BASE, 4, struct mcasp_querybuf)
#define MCASPRECV_STREAMON              _IOWR(MCASPRECV_IOC_BASE, 5, int)
#define MCASPRECV_STREAMOFF             _IOWR(MCASPRECV_IOC_BASE, 6, int)


typedef struct __mcasp_t {
        int fd;
        void* buf_ptr[BUF_NUM];
} mcasp_t;

typedef mcasp_t* Mcasp_Handle;

/* buffer information for request */
struct mcasp_reqbuf {
        int num;
        int buf_size;
};

/* buffer information for query */
struct mcasp_querybuf {
        int used;
        int id;
        unsigned int dma_addr;
        ssize_t data_size;
};

Mcasp_Handle mcasp_init();
int mcasp_getdata(Mcasp_Handle, unsigned int*);
void mcasp_close(Mcasp_Handle);
#endif
