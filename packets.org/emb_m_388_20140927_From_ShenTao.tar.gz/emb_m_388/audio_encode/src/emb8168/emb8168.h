/*
 * emb8168.h
 *
 *  Created on: Apr 26, 2013
 *      Author: spark
 */

#ifndef EMB8168_H_
#define EMB8168_H_

#include "recbc_srv.h"

typedef struct s_venc
{
	//t_datafifo uci_producer_fifo; //unCompressed image
	t_datafifo cvd_store_producer_fifo;
	t_datafifo cvd_live_producer_fifo;
	t_datafifo hostuci_producer_fifo; //add for send uci data to host
	t_datafifo event_producer_fifo;
	t_datafifo consumer_fifo;
	t_datafifo pip_consumer_fifo;
	void *priv;
}t_venc;

typedef struct s_aenc
{
	t_datafifo producer_fifo;
	t_datafifo consumer_fifo;
	void *priv;
}t_aenc;

typedef struct s_analyze
{
	t_datafifo producer_fifo;
	t_datafifo consumer_fifo;
	void *priv;
}t_analyze;

typedef struct s_uart
{
	t_datafifo producer_fifo;
	t_datafifo consumer_fifo;
	void *priv;
}t_uart;

typedef struct s_switch
{
	t_datafifo consumer_fifo;
}t_switch;

typedef struct s_cfg_param
{
	int frame_width;
	int frame_height;
	int frame_rate;
	int bit_rate;
	int lbit_rate;
}t_cfg_param;

typedef struct s_switch_contrl
{
	int cap_id;
	int pip;
}t_switch_ctrl;

typedef struct s_hostctrl
{
	t_datafifo ctrl_producer_fifo;
	t_datafifo uart_producer_fifo;
	t_datafifo switch_producer_fifo;
	t_datafifo pip_producer_fifo;
	t_datafifo consumer_fifo;
	int sock_host;
	void *priv;
}t_hostctrl;

typedef struct s_cmem_buf_desc
{
	void *vir_addr;
	void *phy_addr;
	unsigned int size;
}t_cmem_buf_desc;

#define CMD_BUFSIZE 1536
#define VERSION_SIZE 2
#define CMD_SIZE 4
#define DATA_LEN_SIZE 4
#define ARG_NAME_LEN_SIZE 1
#define ARG_LEN_SIZE 4
#define PACKET_HEADER_SIZE (VERSION_SIZE + CMD_SIZE + DATA_LEN_SIZE)
#define COMMAND_VERSION "01"

// typedef struct w_cmd
// {
// 	char fullbuf[CMD_BUFSIZE];
// 	char *version;
// 	char *cmd;
// 	char *data_len;
// 	char *data;

// 	char *cmd_p;
// }t_cmd;

/* app init/deinit */
extern int AppInit();
extern int AppDeinit();

#endif /* EMB8168_H_ */

