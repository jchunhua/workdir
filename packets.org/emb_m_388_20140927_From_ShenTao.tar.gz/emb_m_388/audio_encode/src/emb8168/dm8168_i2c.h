/*
 * ============================================================================
 * Copyright (C) 2013 Seacean Electronics Ltd
 *
 * Auther: TONY SHEN <tony.shen@seacean.com.cn>
 *
 * Use of this software is controlled by the terms and conditions found in the
 * license agreement under which this software has been supplied or provided.
 * ============================================================================
 */
#ifndef _DM8168_I2C_H_
#define _DM8168_I2C_H_

#define I2C_TRANSFER_SIZE_MAX   (254)

typedef struct {

  int fd;

} DM8168_I2cHndl;

int DM8168_i2cOpen(DM8168_I2cHndl *hndl, unsigned char instId);
int DM8168_i2cRead8(DM8168_I2cHndl *hndl, unsigned short devAddr, unsigned char *reg, unsigned char *value, unsigned int count);
int DM8168_i2cWrite8(DM8168_I2cHndl *hndl, unsigned short devAddr, unsigned char *reg, unsigned char *value, unsigned int count);
int DM8168_i2cClose(DM8168_I2cHndl *hndl);
void* dm8168_i2c();

#endif

