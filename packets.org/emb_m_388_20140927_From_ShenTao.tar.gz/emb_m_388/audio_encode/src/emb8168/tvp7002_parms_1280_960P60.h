/*
 * ============================================================================
 * Copyright (C) 2013 Seacean Electronics Ltd
 *
 * Auther: TONY SHEN <tony.shen@seacean.com.cn>
 *
 * Use of this software is controlled by the terms and conditions found in the
 * license agreement under which this software has been supplied or provided.
 * ============================================================================
 */
#ifndef __TVP7002_PARMS_1280_960P60_H__ 
#define __TVP7002_PARMS_1280_960P60_H__

#include "tvp7002_reg.h"

//struct i2c_reg_value {
//        unsigned char reg;
//        unsigned char value;
//};

static const struct i2c_reg_value tvp7002_parms_1280_960P60[] = {
	{TVP7002_PWR_CTL, 0xff},	
	{TVP7002_PWR_CTL, 0x00},
	{TVP7002_HPLL_FDBK_DIV_MSBS, 0x67},
	{TVP7002_HPLL_FDBK_DIV_LSBS, 0x20}, 
	{TVP7002_HPLL_CRTL, 0xa0},
	{TVP7002_HPLL_PHASE_SEL, 0x80},
	{TVP7002_CLAMP_START, 0x32},
	{TVP7002_CLAMP_W, 0x20},
	{TVP7002_HSYNC_OUT_W, 0x20},
	{TVP7002_B_FINE_GAIN, 0x00},
	{TVP7002_G_FINE_GAIN, 0x00},
	{TVP7002_R_FINE_GAIN, 0x00},
	{TVP7002_B_FINE_OFF_MSBS, 0x80},
	{TVP7002_G_FINE_OFF_MSBS, 0x80},
	{TVP7002_R_FINE_OFF_MSBS, 0x80},
	{TVP7002_SYNC_CTL_1, 0x40},
	{TVP7002_HPLL_AND_CLAMP_CTL, 0x2a},
	{TVP7002_SYNC_ON_G_THRS, 0x58},
	{TVP7002_SYNC_SEPARATOR_THRS, 0x47},
	{TVP7002_HPLL_PRE_COAST, 0x00},
	{TVP7002_HPLL_POST_COAST, 0x00},
        {TVP7002_OUT_FORMATTER, 0x23},
        {TVP7002_MISC_CTL_1, 0x11},
        {TVP7002_MISC_CTL_2, 0x00},
        {TVP7002_MISC_CTL_3, 0x11},
        {TVP7002_IN_MUX_SEL_1, 0x00},
        {TVP7002_IN_MUX_SEL_2, 0xca},
        {TVP7002_B_AND_G_COARSE_GAIN, 0x77},
        {TVP7002_R_COARSE_GAIN, 0x07},
        {TVP7002_FINE_OFF_LSBS, 0x00},
        {TVP7002_B_COARSE_OFF, 0x10},
        {TVP7002_G_COARSE_OFF, 0x10},
        {TVP7002_R_COARSE_OFF, 0x10},
        {TVP7002_HSOUT_OUT_START, 0x0d},
        {TVP7002_MISC_CTL_4, 0x04},
        {TVP7002_AUTO_LVL_CTL_ENABLE, 0x00},
        {TVP7002_AUTO_LVL_CTL_FILTER, 0x53},
        {TVP7002_FINE_CLAMP_CTL, 0x87},
        {TVP7002_ADC_SETUP, 0x50},
        {TVP7002_COARSE_CLAMP_CTL, 0x00},
        {TVP7002_SOG_CLAMP, 0x80},
        {TVP7002_RGB_COARSE_CLAMP_CTL, 0x8c},
        {TVP7002_SOG_COARSE_CLAMP_CTL, 0x04},
        {TVP7002_ALC_PLACEMENT, 0x5a},
        {TVP7002_VSYNC_ALGN, 0x10},
        {TVP7002_SYNC_BYPASS, 0x00},
        {TVP7002_L_LENGTH_TOL, 0x03},
        {TVP7002_VIDEO_BWTH_CTL, 0x00},
        {TVP7002_AVID_START_PIXEL_LSBS, 0x01},
        {TVP7002_AVID_START_PIXEL_MSBS, 0x2c},
        {TVP7002_AVID_STOP_PIXEL_LSBS, 0x06},
        {TVP7002_AVID_STOP_PIXEL_MSBS, 0x2c},
        {TVP7002_VBLK_F_0_START_L_OFF, 0x05},
        {TVP7002_VBLK_F_1_START_L_OFF, 0x00},
        {TVP7002_VBLK_F_0_DURATION, 0x1e},
        {TVP7002_VBLK_F_1_DURATION, 0x00}, 
        {TVP7002_FBIT_F_0_START_L_OFF, 0x00},
        {TVP7002_FBIT_F_1_START_L_OFF, 0x00},
        {TVP7002_YUV_Y_G_COEF_LSBS, 0xe3},
        {TVP7002_YUV_Y_G_COEF_MSBS, 0x16},
        {TVP7002_YUV_Y_B_COEF_LSBS, 0x4f},
        {TVP7002_YUV_Y_B_COEF_MSBS, 0x02},
        {TVP7002_YUV_Y_R_COEF_LSBS, 0xce},
        {TVP7002_YUV_Y_R_COEF_MSBS, 0x06},
        {TVP7002_YUV_U_G_COEF_LSBS, 0xab},
        {TVP7002_YUV_U_G_COEF_MSBS, 0xf3},
        {TVP7002_YUV_U_B_COEF_LSBS, 0x00},
        {TVP7002_YUV_U_B_COEF_MSBS, 0x10},
        {TVP7002_YUV_U_R_COEF_LSBS, 0x55},
        {TVP7002_YUV_U_R_COEF_MSBS, 0xfc},
        {TVP7002_YUV_V_G_COEF_LSBS, 0x78},
        {TVP7002_YUV_V_G_COEF_MSBS, 0xf1},
        {TVP7002_YUV_V_B_COEF_LSBS, 0x88},
        {TVP7002_YUV_V_B_COEF_MSBS, 0xfe},
        {TVP7002_YUV_V_R_COEF_LSBS, 0x00},
        {TVP7002_YUV_V_R_COEF_MSBS, 0x10},
        {TVP7002_HPLL_FDBK_DIV_MSBS, 0x70},
        {TVP7002_HPLL_FDBK_DIV_LSBS, 0x80},
        {TVP7002_HPLL_CRTL, 0x98},
        {TVP7002_HPLL_PHASE_SEL, 0x80},
        {TVP7002_AVID_START_PIXEL_LSBS, 0xc0},
        {TVP7002_AVID_START_PIXEL_MSBS, 0x01},
        {TVP7002_AVID_STOP_PIXEL_LSBS, 0xc4},
        {TVP7002_AVID_STOP_PIXEL_MSBS, 0x06},
        {TVP7002_VBLK_F_0_START_L_OFF, 0x01},
        {TVP7002_VBLK_F_1_START_L_OFF, 0x01},
        {TVP7002_VBLK_F_0_DURATION, 0x28},
        {TVP7002_VBLK_F_1_DURATION, 0x28},
        {TVP7002_ALC_PLACEMENT, 0x18},
        {TVP7002_CLAMP_START, 0x06},
        {TVP7002_CLAMP_W, 0x10},
        {TVP7002_HPLL_PRE_COAST, 0x01},
        {TVP7002_HPLL_POST_COAST, 0x00},
	{0, 0}
};

#endif
