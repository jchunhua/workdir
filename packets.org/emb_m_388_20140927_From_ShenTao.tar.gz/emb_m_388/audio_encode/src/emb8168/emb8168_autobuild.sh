gcc -Wall datafifo.c emb8168.c -o emb8168 -lpthread
