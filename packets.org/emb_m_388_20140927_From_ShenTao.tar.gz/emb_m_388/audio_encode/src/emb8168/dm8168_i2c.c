/*
 * ============================================================================
 * Copyright (C) 2013 Seacean Electronics Ltd
 *
 * Auther: TONY SHEN <tony.shen@seacean.com.cn>
 *
 * Use of this software is controlled by the terms and conditions found in the
 * license agreement under which this software has been supplied or provided.
 * ============================================================================
 */
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>
#include "dm8168_i2c.h"
#include "tvp7002_reg.h"
#include "tvp7002_parms_1080P60.h"
#include "tvp7002_parms_1280_1024P60.h"
#include "tvp7002_parms_1280_960P60.h"
#include "tvp7002_parms_1280_720P60.h"
#include "tvp7002_parms_1366_768P60.h"
#include "tvp7002_parms_1024_768P60.h"
#include "tvp7002_parms_1680_1050P60.h"
#include "tvp7002_parms_1600_900P60.h"
#include "ti/omx/interfaces/openMaxv11/OMX_Core.h"
#include "ti/omx/interfaces/openMaxv11/OMX_Component.h"

//#define DM8168_I2C_DEBUG
extern OMX_BOOL gILClientExit;

#define I2C_RDWR        0x0707  /* Combined R/W transfer (one STOP only) */

struct i2c_msg {
        unsigned short addr;     /* slave address                        */
        unsigned short flags;
#define I2C_M_TEN               0x0010  /* this is a ten bit chip address */
#define I2C_M_RD                0x0001  /* read data, from slave to master */
#define I2C_M_NOSTART           0x4000  /* if I2C_FUNC_PROTOCOL_MANGLING */
#define I2C_M_REV_DIR_ADDR      0x2000  /* if I2C_FUNC_PROTOCOL_MANGLING */
#define I2C_M_IGNORE_NAK        0x1000  /* if I2C_FUNC_PROTOCOL_MANGLING */
#define I2C_M_NO_RD_ACK         0x0800  /* if I2C_FUNC_PROTOCOL_MANGLING */
#define I2C_M_RECV_LEN          0x0400  /* length will be first received byte */
        unsigned short len;             /* msg length                           */
        unsigned char *buf;             /* pointer to msg data                  */
};

struct i2c_rdwr_ioctl_data {
        struct i2c_msg *msgs;            /* pointers to i2c_msgs */
        unsigned int nmsgs;              /* number of i2c_msgs */
};


int DM8168_i2cOpen(DM8168_I2cHndl *hndl, unsigned char instId)
{
    char deviceName[20];
    int status = 0;

    sprintf(deviceName, "/dev/i2c-%d", instId);

    hndl->fd = open(deviceName, O_RDWR);

    if(hndl->fd<0)
        return -1;

    return status;
}

int DM8168_i2cRead8(DM8168_I2cHndl *hndl, unsigned short devAddr, unsigned char *reg, unsigned char *value, unsigned int count)
{
    int i, j;
    int status = 0;
    struct i2c_msg * msgs = NULL;
    struct i2c_rdwr_ioctl_data data;

    msgs = (struct i2c_msg *) malloc(sizeof(struct i2c_msg) * count * 2);

    if(msgs==NULL)
    {
        printf(" I2C (0x%02x): Malloc ERROR during Read !!! (reg[0x%02x], count = %d)\n", devAddr, reg[0], count);
        return -1;
    }

    for (i = 0, j = 0; i < count * 2; i+=2, j++)
    {
        msgs[i].addr  = devAddr;
        msgs[i].flags = 0;
        msgs[i].len   = 1;
        msgs[i].buf   = &reg[j];

        msgs[i+1].addr  = devAddr;
        msgs[i+1].flags = I2C_M_RD /* | I2C_M_REV_DIR_ADDR */;
        msgs[i+1].len   = 1;
        msgs[i+1].buf   = &value[j];
    }

    data.msgs = msgs;
    data.nmsgs = count * 2;

    status = ioctl(hndl->fd, I2C_RDWR, &data);
    if(status < 0)
    {
        status = -1;
        #ifdef DM8168_I2C_DEBUG
        printf(" I2C (0x%02x): Read ERROR !!! (reg[0x%02x], count = %d)\n", devAddr, reg[0], count);
        #endif
    }
    else
        status = 0;

    free(msgs);

    return status;
}

int DM8168_i2cWrite8(DM8168_I2cHndl *hndl, unsigned short devAddr,  unsigned char *reg, unsigned char *value, unsigned int count)
{
    int i,j;
    unsigned char * bufAddr;
    int status = 0;

    struct i2c_msg * msgs = NULL;
    struct i2c_rdwr_ioctl_data data;

    msgs = (struct i2c_msg *) malloc(sizeof(struct i2c_msg) * count);

    if(msgs==NULL)
    {
        printf(" I2C (0x%02x): Malloc ERROR during Write !!! (reg[0x%02x], count = %d)\n", devAddr, reg[0], count);
        return -1;
    }

    bufAddr = (unsigned char *) malloc(sizeof(unsigned char) * count * 2);

    if(bufAddr == NULL)
    {
        free(msgs);

        printf(" I2C (0x%02x): Malloc ERROR during Write !!! (reg[0x%02x], count = %d)\n", devAddr, reg[0], count);
        return -1;

    }

    for (i = 0, j = 0; i < count; i++, j+=2)
    {
        bufAddr[j] = reg[i];
        bufAddr[j + 1] = value[i];

        msgs[i].addr  = devAddr;
        msgs[i].flags = 0;
        msgs[i].len   = 2;
        msgs[i].buf   = &bufAddr[j];
    }
    data.msgs = msgs;
    data.nmsgs = count;

    status = ioctl(hndl->fd, I2C_RDWR, &data);
    if(status < 0)
    {
        status = -1;
        #ifdef DM8168_I2C_DEBUG
        printf(" I2C (0x%02x): Write ERROR !!! (reg[0x%02x], count = %d)\n", devAddr, reg[0], count);
        #endif
    }
    else
        status = 0;

    free(msgs);
    free(bufAddr);

    return status;
}

int DM8168_i2cClose(DM8168_I2cHndl *hndl)
{
    return close(hndl->fd);
}


