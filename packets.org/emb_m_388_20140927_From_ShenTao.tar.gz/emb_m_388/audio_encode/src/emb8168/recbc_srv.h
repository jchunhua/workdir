/*
 * recbc_srv.h
 *
 *  Created on: Mar 18, 2013
 *      Author: spark
 */

#ifndef RECBC_SRV_H_
#define RECBC_SRV_H_

#include "datafifo.h"
#define MAXDEVNUM 100

enum e_VideoSrc
{
	VIDEO_SRC_NONE = -1,
	VIDEO_SRC_MUX,
	VIDEO_SRC_VGA,
	VIDEO_SRC_V1,
	VIDEO_SRC_V2,
	VIDEO_SRC_V3,
	VIDEO_SRC_V4,
	VIDEO_SRC_V5,
	VIDEO_SRC_VAUX1,
	VIDEO_SRC_VAUX2,
};

enum e_CaptureIf
{
	CAPTURE_IF_NONE = -1,
	CAPTURE_IF_VGA,
	CAPTURE_IF_HDSDI,
	CAPTURE_IF_HDMI,
	CAPTURE_IF_CVBS,
};

enum e_AnalyzingMode
{
	ANALYZING_MODE_NONE = -1,
	ANALYZING_MODE_VIDEO,
	ANALYZING_MODE_VGA,
	ANALYZING_MODE_AUX,
};
typedef struct s_videoconfig
{
	enum e_VideoSrc vsrc;
	int Present;
	int CaptureId;
	enum e_CaptureIf capif;
	int CoreId;
	int PortId;
	enum e_AnalyzingMode analymode;
	int UartId;
	int sockfd;
} t_videoconfig;

typedef struct s_idx_id_map
{
	int BrdIdx;
	char BrdId[13];
}t_idx_id_map;

typedef struct s_sock_id_map
{
	int socket;
	char BrdId[13];
}t_sock_id_map;

typedef struct s_dev_cfg
{
	int valid;
	t_sock_id_map BrdTbl[4];
}t_dev_cfg;

typedef struct s_hello_attr
{
	char AttrName[8];
	char AttrValue[64];
}t_hello_attr;


typedef struct s_hello_attrs
{
	int NumofAttr;
	t_hello_attr attrs[3];
}t_hello_attrs;

#define CMD_BUFSIZE 1536
#define VERSION_SIZE 2
#define CMD_SIZE 4
#define DATA_LEN_SIZE 4
#define ARG_NAME_LEN_SIZE 1
#define ARG_LEN_SIZE 4
#define PACKET_HEADER_SIZE (VERSION_SIZE + CMD_SIZE + DATA_LEN_SIZE)
#define COMMAND_VERSION "01"
typedef struct w_cmd
{
	char fullbuf[CMD_BUFSIZE];
	char *version;
	char *cmd;
	char *data_len;
	char *data;

	char *cmd_p;
}t_cmd;

typedef struct h_cmd
{
	char fullbuf[1920*1080 + CMD_BUFSIZE];
	char *version;
	char *cmd;
	char *data_len;
	char *data;

	char *cmd_p;
}h_cmd;

typedef struct s_localsave
{
	int thread_canceled;
	t_datafifo av_fifo;
	t_datafifo *df_a;
	t_datafifo *df_v;
	int status;
	int sock;
}t_localsave;

typedef struct s_camholderctrl
{
	int thread_canceled;
	t_datafifo req_fifo;
	t_datafifo ctrl_fifo;
	t_datafifo rsp_fifo;
	int init;
}t_camholderctrl;


typedef struct s_rundevice
{
	t_datafifo mux_fifo;
	t_datafifo audio_fifo;
	t_datafifo camhldRsp_fifo;
	t_datafifo camhldReq_fifo;
	t_datafifo consumer_fifo;
	int sock_dev;
	int sock_srv;
	struct timeval tv;
	int switched;
	t_camholderctrl *p_camhldctrl;
}t_rundevice;

typedef struct s_DetectResult
{
	unsigned int detected;
	unsigned int avg_top;
	unsigned int avg_left;
	unsigned int avg_bottom;
	unsigned int avg_right;
	unsigned int max_top;
	unsigned int max_left;
	unsigned int max_bottom;
	unsigned int max_right;
}t_DetectResult;

#define VINBUF_SIZE 1024*1024
#define VINBUF_CNT 3

#define AINBUF_SIZE 1024
#define AINBUF_CNT 10

#define EINBUF_SIZE 1536
#define EINBUF_CNT 10

#define BYPBUF_SIZE 8
#define	BYPBUF_CNT 200

typedef enum
{
	FRMTYPE_VIDEO_IDR,
	FRMTYPE_VIDEO_I,
	FRMTYPE_VIDEO_P,
	FRMTYPE_AUDIO
}e_frame_type;

typedef struct s_frame_info
{
	unsigned int frame_type;
	unsigned int frame_length;
	unsigned int frame_num;
	unsigned int packet_num;
	unsigned int frame_rate;
	unsigned int time_stamp;
	unsigned int pkts_in_frame;
}t_frame_info;

#define MAX_AVPKT_SIZE 1024

typedef enum
{
	LOCALSAVE_IDLE = 0,
	LOCALSAVE_WORKING,
}e_localsave_status;

typedef struct s_mp4format
{
	char filename[256];
	char fps[8];
}t_mp4format;

#endif /* RECBC_SRV_H_ */
