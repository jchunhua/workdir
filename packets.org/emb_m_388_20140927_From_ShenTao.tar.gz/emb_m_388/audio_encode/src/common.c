#include "common.h"

int createsem(key_t key, int op)
{
	int sid;
	union semun sem_arg;
	
	sid = semget(key, 1, 0666|IPC_CREAT);
	if(sid == -1)
	{
		printf("semget error: %s\n", strerror(errno));
		return -1;
	}

	sem_arg.val = op;
	if(semctl(sid, 0, SETVAL, sem_arg)==-1)
	{
		printf("semctl error: %s\n", strerror(errno));
		return -1;
	}

	return sid;
}

void Wait(int sid)
{
	semcall(sid, -1);
}

void Signal(int sid)
{
	semcall(sid, 1);
}

void semcall(int sid, int op)
{
	struct sembuf sembuffer;
	sembuffer.sem_num = 0;
	sembuffer.sem_op = op;
	sembuffer.sem_flg = 0;

	if(semop(sid, &sembuffer, 1) == -1)
		printf("semop error: %s\n", strerror(errno));			
}
