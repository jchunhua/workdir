/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-v49
 */

#ifndef c674x_aaclcenc_01_00_01_00_elf__
#define c674x_aaclcenc_01_00_01_00_elf__



#endif /* c674x_aaclcenc_01_00_01_00_elf__ */ 
