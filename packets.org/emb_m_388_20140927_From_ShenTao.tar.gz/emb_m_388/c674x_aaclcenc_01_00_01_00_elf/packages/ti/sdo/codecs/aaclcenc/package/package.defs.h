/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-v49
 */

#ifndef ti_sdo_codecs_aaclcenc__
#define ti_sdo_codecs_aaclcenc__



#endif /* ti_sdo_codecs_aaclcenc__ */ 
