
/* Includes ******************************************************************/
#include <std.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ialg.h"
#include "alg.h"
#include "imp4aacenc.h"
#include "TestAppEncoder.h"
#include "wav_reader.h"

#define CACHE_ENABLE
#ifdef CACHE_ENABLE
#include "cache_c674x.h"
#endif

#define IN_BUF_SIZE  4096
#define MAX_CHANNELS 6
#define OUT_BUF_SIZE 4608

XDAS_Int16 inputData[IN_BUF_SIZE * MAX_CHANNELS];
XDAS_UInt8  outputData[OUT_BUF_SIZE];

void set_default_parameters(IAUDENC1_Params *params);

XDAS_Int8 channMap[7] = {-1, IAUDIO_1_0, IAUDIO_2_0, -1, -1, IAUDIO_3_2, IAUDIO_3_2};

//=======================================================================================//
// user API expample
//=======================================================================================//
int main()
 {
	// MP4AACENC related staffs
	IAUDENC1_Fxns   *mp4AacEncFxns;
	IAUDENC1_Handle  handle;
	IAUDENC1_Params params = {0};
	IAUDENC1_Status status = {0};
    IAUDENC1_DynamicParams  dynamicParams
                             = {0};       /*! Dynamic parameter variable     */
    IAUDENC1_InArgs         inArgs
                             = {0};       /*! Input Argument for each frame  */
    IAUDENC1_OutArgs        outArgs
                             = {0};       /*! Output Argument for each frame */
    XDM1_BufDesc           inBufDesc
                             = {0};       /*! Input Buffer Descriptor        */
    XDM1_BufDesc           outBufDesc
                             = {0};       /*! Output Buffer Descriptor       */
    FILE                   *cfgFp;        /*! Configuration File Pointer     */
    XDAS_UInt8      outFileName[150];     /*! Array for output file name     */
    XDAS_UInt8      inFileName[150];      /*! Array for input file name      */

    FILE            *inFp, *outFp;        /*! input output File pointer      */
    XDAS_Int32      frameCnt = 0;         /*! Frame counter                  */

    SWavInfo        fileInfo;             /*! File Info structure for wave   */
    XDAS_Int32      nbChannels = 2;        /* Number of channels */
	XDAS_Int32      nbBytesPerSample;      /* Bytes per samples        */

	int nBitRate = 0;

	int testCompliance;
	int outBytes;
	XDAS_Int8 error = XDM_EOK;

#ifdef CACHE_ENABLE
	#define L2CFG()  (*(volatile unsigned int *)0x01840000)
	#define L1PCFG() (*(volatile unsigned int *)0x01840020)
	#define L1DCFG() (*(volatile unsigned int *)0x01840040)
    #define MAR128() (*(volatile unsigned int *)0x01848200)
    #define MAR129() (*(volatile unsigned int *)0x01848204)
    Cache_setSize();
#endif

    /*! Open Config File for reading */
    cfgFp
#ifdef WIN32
		= fopen("..\\..\\..\\Client\\Test\\TestVecs\\Config\\config.txt", "rb");
#else
        = fopen("..\\..\\Test\\TestVecs\\Config\\TestVecs_lc.txt", "rb");
#endif

    if (cfgFp == NULL)
    {
#ifdef WIN32
        printf("Error opening config file config.txt\n");
#else
		printf("Error opening config file TestVecs.txt\n");
#endif
        return XDM_EFAIL;
    }

    while (!feof(cfgFp))
    {

        /*! Read from Config file */
        fscanf(cfgFp, "%d %s %s %d \n", &testCompliance,&inFileName, &outFileName, &nBitRate);
        printf("%s %s %d \n", inFileName, outFileName, nBitRate);

        /*! Open input File for reading */
        inFp = fopen((const char *)inFileName, "rb");
        if (inFp == NULL)
        {
            printf("Error opening input file %s\n", inFileName);
            continue;
        }

		if(testCompliance)
		{
			outFp = fopen((const char *)outFileName, "rb");
			printf("\nRunning in Compliance Mode\n");
		}
        else
		{
			outFp = fopen((const char *)outFileName, "wb");
			printf("\nRunning in Output Dump Mode\n");
		}

        /*! Open Output file for writing */
        if (outFp == NULL)
        {
            printf("Error opening output file %s\n", outFileName);
            continue;
        }

		/*! Set sizes of AAC Encoder Objects */
		/* Yet to be done here */
		status.size    = sizeof(IAUDENC1_Status);
		params.size = sizeof(IAUDENC1_Params);
		dynamicParams.size = sizeof(IAUDENC1_DynamicParams);
		inArgs.size    = sizeof(IAUDENC1_InArgs);
		outArgs.size  = sizeof(IAUDENC1_OutArgs);
		/* Currently no Ancillary Data is given */
		inArgs.ancData.bufSize = 0L;
		inArgs.ancData.buf     = (XDAS_Int8 *) NULL;

	    /*! Set values for creation time parameter */
        set_default_parameters((IAUDENC1_Params *)&params);

		/*! parse WAVE-header and move pointer to raw sampling-data */
        if (read_wave_header(inFp, &fileInfo) )
        {
            printf("Error Reading WAVE header\n");
            return XDM_EFAIL;
        }
        nbChannels  = fileInfo.numberOfChannels;
		params.lfeFlag = FALSE;
		params.channelMode = channMap[nbChannels];
		if (nbChannels == 6)
		{
			params.lfeFlag = TRUE;
		}
        params.inputBitsPerSample = fileInfo.bitsPerSample;
        params.sampleRate = fileInfo.sampleRate;
		params.bitRate = nBitRate;

		dynamicParams.channelMode = params.channelMode;
        dynamicParams.lfeFlag    = params.lfeFlag;
		dynamicParams.sampleRate = params.sampleRate;
        dynamicParams.bitRate = params.bitRate;
		dynamicParams.dualMonoMode = params.dualMonoMode;
        dynamicParams. inputBitsPerSample = params.inputBitsPerSample;

		nbBytesPerSample = fileInfo.bitsPerSample >> 3;

		/* create */
		if ((handle = (IAUDENC1_Handle) ALG_create((IALG_Fxns *)&MP4AACENC_TIJ_IMP4AACENC, NULL, (IALG_Params *)&params)) != NULL)
		{
			/*! Assign Algorithm functions handle to aacEncFxns variable */
            mp4AacEncFxns = (IAUDENC1_Fxns *)handle->fxns;

			/*! Set Dynamic params */
        	error = mp4AacEncFxns->control((IAUDENC1_Handle)handle, XDM_SETPARAMS,
          		          				  (IAUDENC1_DynamicParams *)&dynamicParams,
          	                            (IAUDENC1_Status *)&status);
			if (error != NULL)
			{
				printf("Problem in XDM_SETPARAMS\n");
			}

			/*! Get Buffer Information */
			error = mp4AacEncFxns->control((IAUDENC1_Handle)handle, XDM_GETBUFINFO,
										  (IAUDENC1_DynamicParams *)&dynamicParams,
        	                              (IAUDENC1_Status *)&status);
			if (error != NULL)
			{
				printf("Problem in XDM_GETBUFINFO\n");
			}

			if (error == NULL)
			{
				/* Input and output buffer information for process API*/
				inBufDesc.numBufs = status.bufInfo.minNumInBufs;
				inBufDesc.descs[0].bufSize = status.bufInfo.minInBufSize[0];
				inBufDesc.descs[0].buf = (XDAS_Int8 *)&inputData;

				outBufDesc.numBufs = status.bufInfo.minNumOutBufs;
				outBufDesc.descs[0].bufSize = status.bufInfo.minOutBufSize[0];
				outBufDesc.descs[0].buf = (XDAS_Int8 *)&outputData;

				frameCnt = 0;
				// encoder main loop
				do {

					inArgs.numInSamples = fread(inBufDesc.descs[0].buf, sizeof(XDAS_Int8),
           	      	           inBufDesc.descs[0].bufSize, inFp);

					/*! calcullate Num of Samples per Channel */
					inArgs.numInSamples /= nbBytesPerSample;
					inArgs.numInSamples /= nbChannels;
#ifdef CACHE_ENABLE
		 Cache_wbInv(inputData, IN_BUF_SIZE*2, 3, TRUE);

		 Cache_inv(inBufDesc.descs[0].buf, inBufDesc.descs[0].bufSize, 3, TRUE);
#endif
					error = mp4AacEncFxns->process((IAUDENC1_Handle)handle, &inBufDesc,
									&outBufDesc, (IAUDENC1_InArgs *)&inArgs,
									(IAUDENC1_OutArgs *)&outArgs);
#ifdef CACHE_ENABLE
         Cache_wbInv(outBufDesc.descs[0].buf,outBufDesc.descs[0].bufSize, 3, TRUE);
#endif

					outBytes = outArgs.bytesGenerated;

					if (error != 0)
					{
						fprintf(stderr, "encoder failed at frame %d due to error %d\n", frameCnt, error);
						break;
					}
					else
					{
						/*! Get Buffer Information */
						error = mp4AacEncFxns->control((IAUDENC1_Handle)handle, XDM_GETSTATUS,
										  				(IAUDENC1_DynamicParams *)&dynamicParams,
        	                              				(IAUDENC1_Status *)&status);
						if (error != NULL)
						{
							printf("Problem in XDM_GETSTATUS\n");
							break;
						}
					}

					fwrite(outputData, 1, outBytes, outFp);

		   	 		++frameCnt;
				} while (outBytes > 0);
			}
			/////////////////////////
			// delete instance object
			ALG_delete((ALG_Handle)handle);

			/*! Close input and output files */
        	if (inFp != NULL)
        	{
        	  	fclose(inFp);
        	}
        	if (outFp != NULL)
        	{
           		fclose(outFp);
       	 	}
		}
		else
		{
			printf("problem in encoder handle creation\n");
		}

    } /* End of file cfgFp */
    /*! Close configuration file */
    if (cfgFp != NULL)
    {
        fclose(cfgFp);
    }
	return error;
}

/*!
 * \fn set_default_parameters
 * param0 encParams : pointer to Parameter structure of AAC Encoder
 * Description      : This function sets the default values for the creation
 *                    time parameters of the AAC Encoder.
 */
void set_default_parameters(IAUDENC1_Params *params)
{
	params->bitRate        = 88000;
	params->ancFlag = 0;
	params->channelMode = IAUDIO_2_0;
	params->dataEndianness = (XDAS_Int32)(XDM_LE_16);
    params->crcFlag        = 0;
	params->dualMonoMode = 0;
	params->encMode = IAUDIO_CBR;
	params->inputBitsPerSample = 16;
	params->inputFormat = IAUDIO_INTERLEAVED;
	params->lfeFlag = 0;
	params->maxBitRate = 192000;// 800000 is the maximum bitrate for CBR but
								// as we are not supporting VBR we need not
								// assign its value.
	params->sampleRate = 44100;
}
