/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-v49
 */

#ifndef ti_sdo_codecs_aaclcenc_ce__
#define ti_sdo_codecs_aaclcenc_ce__



#endif /* ti_sdo_codecs_aaclcenc_ce__ */ 
