#ifndef _WAV_READER_H
#define _WAV_READER_H

#include <stdio.h>

typedef short  SHORT;
typedef int    LONG;
typedef int    INT;
typedef char   CHAR;
typedef unsigned char UCHAR;


typedef struct
{
    SHORT compressionCode;
    SHORT numberOfChannels ;
    LONG  sampleRate ;
    LONG  averageBytesPerSecond ;
    SHORT blockAlign ;
    SHORT bitsPerSample ;
    SHORT extraFormatBytes ;

    /* extra stuff */
    LONG mainChunkSize ;
} SWavInfo;

typedef struct
{
  CHAR chunkID[4] ;
  LONG chunkSize ;
  LONG dataOffset ;
} SChunk;

extern INT IsLittleEndian(void);
extern INT fread_EL(void *dst, INT size, INT nmemb, FILE *fp);
extern INT read_wave_header (FILE *fp, SWavInfo *wavInfo);


#endif /* _WAV_READER_H */

