/*
//============================================================================
//
//    FILE NAME : IMP4AACENC.h
//
//    ALGORITHM : MP4AACENC
//
//    VENDOR    : TIJ
//
//    TARGET DSP: C67x
//
//    PURPOSE   : IMP4AACENC Interface Header
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Wed - 16 November 2005
//    Creation Time: 02:29 PM
//
//============================================================================
*/

#ifndef _IMP4AACENC_H_
#define _IMP4AACENC_H_

#include <ti/xdais/ialg.h>
#include <ti/xdais/dm/iaudenc1.h>


/*! Control Commands for AAC Encoder */
#define IMP4AACENC_GETSTATUS   XDM_GETSTATUS
#define IMP4AACENC_SETPARAMS   XDM_SETPARAMS
#define IMP4AACENC_RESET       XDM_RESET
#define IMP4AACENC_SETDEFAULT  XDM_SETDEFAULT
#define IMP4AACENC_FLUSH       XDM_FLUSH
#define IMP4AACENC_GETBUFINFO  XDM_GETBUFINFO
#define IMP4AACENC_GETVERSION  XDM_GETVERSION

typedef enum {
	MPEG4ENC_NO_ERROR = 0,
	MPEG4ENC_UNKNOWN_ERROR,
	MPEG4ENC_PARAM_ERROR,
	MPEG4ENC_MEMORY_ERROR,
	MPEG4ENC_INIT_ERROR,
	MPEG4ENC_FATAL_ERROR
} MPEG4ENC_ERROR;

/*
// ===========================================================================
// MPEG4ENC related types
*/
typedef enum {
	IMP4AACENC_AOT_LC           = 2,   /* AAC LC                                 */
	IMP4AACENC_AOT_HEAAC        = 5,   /* AAC LC + SBR                           */
	IMP4AACENC_AOT_PS           = 29,  /* AAC LC + SBR + PS                      */
	IMP4AACENC_AOT_MP2_LC       = 129  /* virtual AOT MP2 Low Complexity Profile */
} IMP4AACENC_AUDIO_OBJ_TYPE;

typedef enum {
	IMP4AACENC_QUAL_FAST=0,
	IMP4AACENC_QUAL_MEDIUM,
	IMP4AACENC_QUAL_HIGH
} IMP4AACENC_ENCODE_QUALITY;

typedef enum {
	IMP4AACENC_TT_RAW    = 0,
	IMP4AACENC_TT_ADIF   = 1,
	IMP4AACENC_TT_ADTS   = 2
} IMP4AACENC_TRANSPORT_TYPE;

/*
// ===========================================================================
// IMP4AACENC_Handle
//
// This handle is used to reference all MP4AACENC instance objects
*/
typedef struct IMP4AACENC_Obj *IMP4AACENC_Handle;


/*
// ===========================================================================
// IMP4AACENC_Obj
//
// This structure must be the first field of all MP4AACENC instance objects
*/
typedef struct IMP4AACENC_Obj {
    struct IMP4AACENC_Fxns *fxns;
} IMP4AACENC_Obj;

/*
// ===========================================================================
// IMP4AACENC_Status
//
// Status structure defines the parameters that can be changed or read
// during real-time operation of the alogrithm.
*/
typedef struct IMP4AACENC_Status {
	IAUDENC1_Status  audenc_status;   			/*!< Basic audio encoder status struct */
	IMP4AACENC_AUDIO_OBJ_TYPE aot;   			/*!< Status of the Audio Object Type */
	IMP4AACENC_TRANSPORT_TYPE outputFileFormat; /*!< Status of Output File Format */

} IMP4AACENC_Status;





/*
// ===========================================================================
// IMP4AACENC_Params
//
// This structure defines the creation parameters for all MP4AACENC objects
*/
typedef struct IMP4AACENC_Params {
	IAUDENC1_Params audenc_params;   /*!< Generic encoder creation parameters */

	IMP4AACENC_AUDIO_OBJ_TYPE	aot;				/* audio object type */
	IMP4AACENC_ENCODE_QUALITY	quality;			/* quality */
	IMP4AACENC_TRANSPORT_TYPE	transMode;			/* 0: RAW, 1: ADIF, 2: ADTS */
} IMP4AACENC_Params;

/*
// ===========================================================================
// IMP4AACENC_PARAMS
//
// Default parameter values for MP4AACENC instance objects
*/
extern IMP4AACENC_Params IMP4AACENC_PARAMS;



/*!
 * \struct IAACENC_DynamicParams
 * \brief  This structure defines run time parameters for AAC Encoder object
*/
typedef struct IMP4AACENC_DynamicParams
{
    IAUDENC1_DynamicParams audenc_dynamicparams;
                                   /*!< generic encoder dynamic parameters  */



} IMP4AACENC_DynamicParams;

/*!
 * \struct IAACENC_InArgs
 * \brief  This structure gives the input parameters to the AAC Encoder
 * \brief  This will be passed to the encoder for each frame of input
 */
typedef struct IMP4AACENC_InArgs
{
    IAUDENC1_InArgs audenc_inArgs;  /*!< Generic Audio Encoder input Params */

} IMP4AACENC_InArgs;

/*!
 * \struct IAACENC_OutArgs
 * \brief  This structure gives the output parameters of the AAC Encoder
 * \brief  This will be output by the encoder for each frame
 */
typedef struct IMP4AACENC_OutArgs
{
    IAUDENC1_OutArgs audenc_outArgs; /*!< Generic Audio Encoder output param */
}IMP4AACENC_OutArgs;

/*
// ===========================================================================
// IMP4AACENC_Fxns
//
// This structure defines all of the operations on MP4AACENC objects
*/
typedef struct IMP4AACENC_Fxns {
	IAUDENC1_Fxns iaudenc;              /*!< must be first element of objects */

} IMP4AACENC_Fxns;

typedef  IAUDENC1_Cmd  IMP4AACENC_Cmd;

/*
 *  ======== MP4AACENC_TIJ_IMP4AACENC ========
 *  This structure defines TI's implementation of the IENCODE  interface
 *  for the AAC_TNI module.
 */
extern const IMP4AACENC_Fxns MP4AACENC_TIJ_IMP4AACENC;

#endif	/* _IMP4AACENC_H_ */
