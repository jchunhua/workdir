/*! *************************************************************************
 * \file:     wav_reader.c
 * \brief     File for reading Wav file header
 * \date  :   19-Jan-2006
 * purpose:   This file contains functions for reading wave file header 
 ***************************************************************************/

#include "wav_reader.h"
#include <string.h>

INT IsLittleEndian(void);
INT fread_EL(void *dst, INT size, INT nmemb, FILE *fp);
INT read_wave_header (FILE *fp, SWavInfo *wavInfo);


INT IsLittleEndian(void) 
{
    SHORT s = 0x01 ;
    /* return *((CHAR *) &s) ? true : false ; */
    return *((CHAR *) &s) ? 1 : 0;
}

/*!
 *
 *  \brief Read variable of size "size" as little endian.
 *    Convert automatically to host endianess.
 *    4 byte alignment is enforced for 24 bit data.
 *  \dst Pointer to memory where to store data into.
 *  \size Size of each item to be read.
 *  \nmemb Number of items to be read.
 *  \fp filepointer of type FILE*.
 *  \return number of items read on success and fread() error on failure.
 *
 */
INT fread_EL(void *dst, INT size, INT nmemb, FILE *fp) 
{
    INT n, s0, s1, err;
    UCHAR tmp, *ptr;
    UCHAR tmp24[3];

    /* Enforce alignment of 24 bit data. */
    if (size == 3) 
    {
        ptr = (UCHAR*)dst;
        err = 0;
        for (n=0; n<nmemb; n++) 
        {
            if ((err = fread(tmp24, 1, 3, fp)) != 3) 
            {
                return err;
            }
            *ptr++ = 0;
            *ptr++ = tmp24[0];
            *ptr++ = tmp24[1];
            *ptr++ = tmp24[2];
        }
        err = nmemb;
        size = sizeof(LONG);
    } 
    else 
    {
        if ((err = fread(dst, size, nmemb, fp)) != nmemb) 
        {
            return err;
        }

    }
    if (!IsLittleEndian() && size > 1) 
    {
        ptr = (UCHAR*)dst;
        for (n=0; n<nmemb; n++) 
        {
            for (s0=0, s1=size-1; s0 < s1; s0++, s1--) 
            {
                tmp = ptr[s0];
                ptr[s0] = ptr[s1];
                ptr[s1] = tmp;
            }
            ptr += size;
        }
    }
    return err;
}


INT read_wave_header (FILE *fp, SWavInfo *wavInfo)
{
    SChunk fmt_chunk, data_chunk ;

    LONG tmpSize ;
    CHAR tmpFormat[4] ;

    /* read RIFF-chunk */
    if(fread(tmpFormat, 1, 4, fp)!= 4)
    {
        return 2;  /* bad error "couldn't read RIFF_ID" */
    }
    if (strncmp("RIFF", tmpFormat, 4))
    {
        printf("RIFF Descriptor not found\n");
        return 2;
    }

    /* Read RIFF size. Ignored. */
    fmt_chunk.dataOffset = ftell(fp) ;
    fread_EL(&tmpSize, sizeof(LONG), 1, fp);

    /********** From Here *************/ 
    /*! read WAVE-chunk */
    fmt_chunk.dataOffset = ftell(fp) ;
    if (fread(tmpFormat, sizeof(CHAR), 4, fp) !=4)
    {
        return 2;  /* bad error "couldn't read format" */
    }

    if (strncmp("WAVE", tmpFormat, 4)) 
    {
        printf("WAVE chunk ID not found.\n") ;
        return 2;
    }

    /* read format-chunk */
    fmt_chunk.dataOffset = ftell(fp) ;
    if (fread(fmt_chunk.chunkID, sizeof(CHAR), 4, fp) != 4)
    {
        return 3;  /* bad error "couldn't read format_ID" */
    }

    if (strncmp("fmt", fmt_chunk.chunkID, 3)) 
    {
        printf("fmt chunk format not found.\n") ;
        return 3;
    }

    /* should be 16 for PCM-format (uncompressed) */
    fmt_chunk.dataOffset = ftell(fp) ;
    fread_EL(&fmt_chunk.chunkSize, sizeof(LONG), 1, fp);   
    fmt_chunk.dataOffset = ftell(fp) ;
    fseek (fp,fmt_chunk.chunkSize, SEEK_CUR) ;

    /* Search for "data" type chunk. Skip over other chunks. */
    do 
    {
        if (fread(data_chunk.chunkID, sizeof(CHAR), 4, fp) != 4) 
        {
            return 1;
        }
        fread_EL(&data_chunk.chunkSize, sizeof(LONG), 1, fp);
        data_chunk.dataOffset = ftell(fp) ;
        // fseek (fp,data_chunk.chunkSize, SEEK_CUR) ;
    } while(!feof(fp) && (strncmp("data", data_chunk.chunkID, 4)) );

    fseek(fp,fmt_chunk.dataOffset, SEEK_SET) ;

    /* read  info */
    fread_EL(&(wavInfo->compressionCode), sizeof(SHORT), 1, fp);
    fread_EL(&(wavInfo->numberOfChannels), sizeof(SHORT), 1, fp);
    fread_EL(&(wavInfo->sampleRate), sizeof(LONG), 1, fp);
    fread_EL(&(wavInfo->averageBytesPerSecond), sizeof(LONG), 1, fp);
    fread_EL(&(wavInfo->blockAlign), sizeof(SHORT), 1, fp);
    fread_EL(&(wavInfo->bitsPerSample), sizeof(SHORT), 1, fp);

    /* Only for compressed audio, read extraFormatBytes */
    if (wavInfo->compressionCode > 0x07) 
    {
        fread_EL(&(wavInfo->extraFormatBytes), sizeof(SHORT), 1, fp);
    }

    /* now, file-pointer (fp) is set on beginning of sample data */
    fseek(fp,data_chunk.dataOffset, SEEK_SET) ;

    return 0 ;
}    

