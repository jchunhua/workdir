gcc -I../ -Wall server_emulator.c -o server_emulator
