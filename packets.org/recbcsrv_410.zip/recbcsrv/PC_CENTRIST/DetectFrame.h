#include "CtImage.h"
#include "svm.h"
extern void DetectFrame(unsigned char* buffer, int frame_num);