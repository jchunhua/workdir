/*
 * xmlparser.h
 *
 *  Created on: Mar 18, 2014
 *      Author: spark
 */

#ifndef XMLPARSER_H_
#define XMLPARSER_H_

int vmap_table_load(char * filename, t_video_map *vmap_table);
int config_load(char * filename, t_recbc_cfg *cfg);
int cam_param_load(char *filename, char *vendor, char *model, t_camera_holder *camera_holder);
int teacher_pt_speed_load(char *filename, t_camera_holder *camera_holder);
int teacher_exclude_load(char *filename, int *IsExclude);
int student_pt_speed_load(char *filename, t_camera_holder *camera_holder);
int student_tracking_geometry_load(char *filename, t_student_tracking_geometry *student_tracking_geometry);
int screen_geometry_load(char *filename, t_screen_geometry *screen_geometry);
int switch_policy_load(char *filename, t_finite_state_machine *fsm);
int forward_table_load(char *filename, t_forward_table *forward_table);
#endif /* XMLPARSER_H_ */
