gcc -Wall -I../ client_emulator.c -o client_emulator
